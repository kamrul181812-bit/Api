package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.browser.BrowserManager
import com.example.classifier.AutoHighlightSettings
import com.example.data.db.CaptureSessionEntity
import com.example.data.db.DcsDatabase
import com.example.data.db.TrafficFilterCriteria
import com.example.data.db.TrafficRecordEntity
import com.example.data.repository.TrafficSortOption
import com.example.export.ExportFormat
import com.example.export.ExportManager
import com.example.ui.screens.RequestInspectorScreen
import com.example.ui.screens.TrafficScreen
import com.example.ui.theme.DcsInspectorTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var db: DcsDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, DcsDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name matches DCS API Inspector`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("DCS API Inspector", appName)
    }

    @Test
    fun `room stores session and traffic and export redacts secrets in JSON CSV TXT`() = runBlocking {
        val session = CaptureSessionEntity(
            sessionId = "sess-1",
            title = "Test Session",
            mode = "VPN",
            selectedBrowserPackage = "com.android.chrome",
            selectedBrowserName = "Chrome",
            appScopeMode = "SELECTED_APPS",
            startedAt = 1000L
        )
        db.sessionDao().insertSession(session)

        val record = TrafficRecordEntity(
            requestId = "req-1",
            sessionId = "sess-1",
            sequenceNumber = 1,
            timestamp = 2000L,
            durationMs = 140L,
            method = "POST",
            protocol = "HTTP",
            httpVersion = "HTTP/1.1",
            url = "https://example.com/auth/v1/send-otp?otp=999999",
            domain = "example.com",
            host = "example.com",
            path = "/auth/v1/send-otp",
            statusCode = 200,
            statusMessage = "OK",
            remoteAddress = "93.184.216.34",
            remotePort = 443,
            connectionType = "VPN TUN",
            appName = "Chrome",
            packageName = "com.android.chrome",
            requestSize = 180,
            responseSize = 420,
            contentType = "application/json",
            requestHeadersJson = """{"Authorization":"Bearer secret-jwt"}""",
            responseHeadersJson = """{"Set-Cookie":"session=topsecret; HttpOnly"}""",
            requestBody = """{"phone":"1234567890","purpose":"verification"}""",
            responseBody = """{"sent":true}"""
        )
        db.trafficDao().upsertRecord(record)

        val loaded = db.trafficDao().observeRecentRecords(10).first()
        assertEquals(1, loaded.size)

        val exporter = ExportManager(context)
        val jsonOut = exporter.generateExportContent(loaded, ExportFormat.JSON)
        val txtOut = exporter.generateExportContent(loaded, ExportFormat.TXT)
        val csvOut = exporter.generateExportContent(loaded, ExportFormat.CSV)

        assertFalse(jsonOut.contains("999999"))
        assertFalse(jsonOut.contains("1234567890"))
        assertTrue(jsonOut.contains("[REDACTED]"))
        assertTrue(txtOut.contains("POST"))
        assertTrue(csvOut.contains("example.com"))
    }

    @Test
    fun `traffic screen and inspector screen render captured record`() {
        val sample = TrafficRecordEntity(
            requestId = "req-ui-1",
            sessionId = "sess-ui",
            sequenceNumber = 7,
            timestamp = System.currentTimeMillis(),
            durationMs = 85L,
            method = "POST",
            protocol = "HTTP",
            httpVersion = "HTTP/1.1",
            url = "https://example.com/api/user/check",
            domain = "example.com",
            host = "example.com",
            path = "/api/user/check",
            statusCode = 200,
            statusMessage = "OK",
            remoteAddress = "93.184.216.34",
            remotePort = 443,
            connectionType = "VPN TUN",
            appName = "Chrome",
            packageName = "com.android.chrome",
            isSelectedBrowser = true,
            requestSize = 512,
            responseSize = 1720,
            contentType = "application/json",
            requestBody = """{"purpose":"verification","phone":"[REDACTED]"}""",
            responseBody = """{"status":"valid"}"""
        )

        composeRule.setContent {
            DcsInspectorTheme {
                TrafficScreen(
                    records = listOf(sample),
                    totalFilteredCount = 1,
                    isMonitoring = true,
                    searchQuery = "",
                    filterCriteria = TrafficFilterCriteria(),
                    sortOption = TrafficSortOption.NEWEST_FIRST,
                    highlightSettings = AutoHighlightSettings(),
                    selectedSessionFilterId = null,
                    browserManager = BrowserManager(context),
                    onOpenMenu = {},
                    onSearchQueryChange = {},
                    onClearTraffic = {},
                    onOpenFilter = {},
                    onResetFilter = {},
                    onSelectSort = {},
                    onOpenGroupByHost = {},
                    onOpenExport = {},
                    onClearSessionFilter = {},
                    onStartMonitoring = {},
                    onLoadMore = {},
                    onRecordClick = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("traffic_item_7").assertIsDisplayed()
        composeRule.onNodeWithText("POST").assertIsDisplayed()
    }

    @Test
    fun `inspector screen displays summary and tabs`() {
        val sample = TrafficRecordEntity(
            requestId = "req-ui-2",
            sessionId = "sess-ui",
            sequenceNumber = 1,
            timestamp = System.currentTimeMillis(),
            durationMs = 45L,
            method = "GET",
            protocol = "HTTPS",
            httpVersion = "h2",
            url = "https://api.example.com/v1/profile",
            domain = "api.example.com",
            host = "api.example.com",
            path = "/v1/profile",
            statusCode = 200,
            statusMessage = "OK",
            remoteAddress = "104.21.10.2",
            remotePort = 443,
            connectionType = "VPN TUN",
            appName = "Firefox",
            packageName = "org.mozilla.firefox",
            isTlsMetadataOnly = true,
            limitationNote = "Encrypted TLS metadata-only"
        )

        composeRule.setContent {
            DcsInspectorTheme {
                RequestInspectorScreen(
                    record = sample,
                    onBack = {},
                    onExportRequest = {}
                )
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("inspector_tab_summary").assertIsDisplayed()
        composeRule.onNodeWithTag("inspector_tab_raw").assertIsDisplayed()
        composeRule.onNodeWithTag("inspector_tab_headers").assertIsDisplayed()
        composeRule.onNodeWithTag("inspector_tab_body").assertIsDisplayed()
    }
}
