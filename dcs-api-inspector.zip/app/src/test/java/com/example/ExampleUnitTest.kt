package com.example

import com.example.capture.HttpParser
import com.example.capture.LocalCaManager
import com.example.capture.PacketCodec
import com.example.data.db.TrafficFilterCriteria
import com.example.data.db.TrafficRecordEntity
import com.example.data.repository.TrafficRepository
import com.example.data.repository.TrafficSortOption
import com.example.privacy.PrivacyRedactionEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.net.InetAddress

class ExampleUnitTest {

    @Test
    fun `privacy redaction masks OTP, password, tokens, cookies, and query secrets`() {
        val rawUrl = "https://api.example.com/auth/verify?otp=482910&redirect=home"
        val (safeUrl, urlCount) = PrivacyRedactionEngine.redactUrl(rawUrl)
        assertEquals(1, urlCount)
        assertFalse(safeUrl.contains("482910"))
        assertTrue(safeUrl.contains("otp=[REDACTED]"))
        assertTrue(safeUrl.contains("redirect=home"))

        val headers = mapOf(
            "Host" to "api.example.com",
            "Authorization" to "Bearer super-secret-token-xyz",
            "Set-Cookie" to "sid=abcdef123456; Path=/; HttpOnly"
        )
        val (safeHeaders, hCount) = PrivacyRedactionEngine.redactHeaders(headers)
        assertEquals(2, hCount)
        assertEquals("[REDACTED]", safeHeaders["Authorization"])
        assertFalse(safeHeaders["Set-Cookie"]!!.contains("abcdef123456"))
        assertTrue(safeHeaders["Set-Cookie"]!!.contains("sid=[REDACTED]"))

        val jsonBody = """{"phone":"+15551234567","otp":"998811","password":"MyPassword123","purpose":"verification"}"""
        val (safeBody, bCount) = PrivacyRedactionEngine.redactBody(jsonBody, "application/json")
        assertNotNull(safeBody)
        assertEquals(3, bCount)
        assertFalse(safeBody!!.contains("998811"))
        assertFalse(safeBody.contains("MyPassword123"))
        assertFalse(safeBody.contains("15551234567"))
        assertTrue(safeBody.contains("\"purpose\": \"verification\""))
    }

    @Test
    fun `packet codec builds and parses valid IPv4 TCP and UDP packets`() {
        val src = InetAddress.getByName("10.10.0.1").address
        val dst = InetAddress.getByName("93.184.216.34").address
        val payload = "GET / HTTP/1.1\r\nHost: example.com\r\n\r\n".toByteArray()
        val rawTcp = PacketCodec.buildIpv4TcpPacket(
            srcIpBytes = src,
            dstIpBytes = dst,
            srcPort = 51234,
            dstPort = 80,
            seqNumber = 1000L,
            ackNumber = 2000L,
            flags = PacketCodec.TCP_PSH or PacketCodec.TCP_ACK,
            payload = payload
        )

        val ip = PacketCodec.parseIpPacket(rawTcp, rawTcp.size)
        assertNotNull(ip)
        assertEquals(PacketCodec.PROTO_TCP, ip!!.protocol)
        assertEquals("10.10.0.1", ip.srcIp)
        assertEquals("93.184.216.34", ip.dstIp)

        val tcp = PacketCodec.parseTcpHeader(rawTcp, ip)
        assertNotNull(tcp)
        assertEquals(51234, tcp!!.srcPort)
        assertEquals(80, tcp.dstPort)
        assertEquals(payload.size, tcp.payloadLength)
        assertTrue(tcp.isPsh && tcp.isAck)
    }

    @Test
    fun `packet codec parses TLS ClientHello SNI and ALPN`() {
        val host = "api.github.com".toByteArray(Charsets.UTF_8)
        // Build minimal TLS ClientHello with SNI extension
        val sniEntry = ByteArrayOutputStream().apply {
            write(0x00) // name_type = host_name
            write((host.size ushr 8) and 0xFF)
            write(host.size and 0xFF)
            write(host)
        }.toByteArray()
        val sniList = ByteArrayOutputStream().apply {
            write((sniEntry.size ushr 8) and 0xFF)
            write(sniEntry.size and 0xFF)
            write(sniEntry)
        }.toByteArray()
        val sniExt = ByteArrayOutputStream().apply {
            write(0x00); write(0x00) // extType = 0x0000
            write((sniList.size ushr 8) and 0xFF)
            write(sniList.size and 0xFF)
            write(sniList)
        }.toByteArray()

        val clientHelloBody = ByteArrayOutputStream().apply {
            write(0x03); write(0x03) // TLS 1.2
            write(ByteArray(32)) // Random
            write(0x00) // Session ID len
            write(0x00); write(0x02); write(0x13); write(0x01) // 1 cipher suite
            write(0x01); write(0x00) // 1 compression method
            write((sniExt.size ushr 8) and 0xFF)
            write(sniExt.size and 0xFF)
            write(sniExt)
        }.toByteArray()

        val bodyBytes = clientHelloBody
        val handshake = ByteArrayOutputStream().apply {
            write(0x01) // ClientHello
            write(0x00)
            write((bodyBytes.size ushr 8) and 0xFF)
            write(bodyBytes.size and 0xFF)
            write(bodyBytes)
        }.toByteArray()

        val record = ByteArrayOutputStream().apply {
            write(0x16); write(0x03); write(0x01)
            write((handshake.size ushr 8) and 0xFF)
            write(handshake.size and 0xFF)
            write(handshake)
        }.toByteArray()

        val parsed = PacketCodec.parseTlsClientHello(record)
        assertNotNull(parsed)
        assertEquals("api.github.com", parsed!!.sniHost)
    }

    @Test
    fun `http parser parses real HTTP request and chunked response`() {
        val rawReq = (
            "POST /api/user/check?source=mobile HTTP/1.1\r\n" +
                "Host: example.com\r\n" +
                "Content-Type: application/json\r\n" +
                "Content-Length: 16\r\n\r\n" +
                "{\"check\":\"ping\"}"
            ).toByteArray()
        val req = HttpParser.parseHttpRequest(rawReq, "example.com")
        assertNotNull(req)
        assertEquals("POST", req!!.method)
        assertEquals("example.com", req.host)
        assertEquals("/api/user/check?source=mobile", req.path)
        assertEquals("mobile", req.queryParams["source"])
        assertEquals("{\"check\":\"ping\"}", req.bodyText)

        val rawResp = (
            "HTTP/1.1 200 OK\r\n" +
                "Content-Type: application/json\r\n" +
                "Transfer-Encoding: chunked\r\n\r\n" +
                "d\r\n{\"ok\":true}\n\n\r\n0\r\n\r\n"
            ).toByteArray()
        val resp = HttpParser.parseHttpResponse(rawResp)
        assertNotNull(resp)
        assertEquals(200, resp!!.statusCode)
        assertTrue(resp.isComplete)
        assertTrue(resp.bodyText!!.contains("\"ok\":true"))
    }

    @Test
    fun `local ca manager generates valid X509 root CA and leaf cert`() {
        val (caCert, caKeyPair) = LocalCaManager.generateSelfSignedRootCa()
        caCert.verify(caKeyPair.public)
        val leafPair = java.security.KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val leafCert = LocalCaManager.generateLeafCertificate("staging.example.local", leafPair, caCert, caKeyPair.private)
        leafCert.verify(caCert.publicKey)
        assertTrue(leafCert.subjectX500Principal.name.contains("staging.example.local"))
    }

    @Test
    fun `repository filter search sort and host grouping operate accurately`() {
        val r1 = sampleRecord("1", 1, "POST", "api.example.com", 200, 120L, 1000L)
        val r2 = sampleRecord("2", 2, "GET", "cdn.example.net", 404, 450L, 2000L)
        val r3 = sampleRecord("3", 3, "GET", "api.example.com", 200, 90L, 3000L)

        val filtered = TrafficRepository.applyFilterSearchAndSort(
            records = listOf(r1, r2, r3),
            filter = TrafficFilterCriteria(methods = setOf("GET"), domainQuery = "example.com"),
            searchQuery = "",
            sort = TrafficSortOption.NEWEST_FIRST
        )
        assertEquals(1, filtered.size)
        assertEquals("3", filtered.first().requestId)

        val sortedByDuration = TrafficRepository.applyFilterSearchAndSort(
            records = listOf(r1, r2, r3),
            filter = TrafficFilterCriteria(),
            searchQuery = "",
            sort = TrafficSortOption.DURATION
        )
        assertEquals("2", sortedByDuration.first().requestId)

        val groups = TrafficRepository.groupByHost(listOf(r1, r2, r3))
        assertEquals(2, groups.size)
        val apiGroup = groups.first { it.domain == "api.example.com" }
        assertEquals(2, apiGroup.totalRequests)
        assertEquals(2, apiGroup.successfulRequests)
    }

    private fun sampleRecord(
        id: String,
        seq: Int,
        method: String,
        domain: String,
        status: Int,
        durationMs: Long,
        ts: Long
    ) = TrafficRecordEntity(
        requestId = id,
        sessionId = "s1",
        sequenceNumber = seq,
        timestamp = ts,
        durationMs = durationMs,
        method = method,
        protocol = "HTTP",
        httpVersion = "HTTP/1.1",
        url = "http://$domain/v1/test",
        domain = domain,
        host = domain,
        path = "/v1/test",
        statusCode = status,
        statusMessage = if (status == 200) "OK" else "Not Found",
        remoteAddress = "93.184.216.34",
        remotePort = 80,
        connectionType = "VPN TUN",
        appName = "Chrome",
        packageName = "com.android.chrome",
        requestSize = 256,
        responseSize = 512,
        isFailed = status >= 500
    )
}
