package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.browser.BrowserManager
import com.example.capture.CaptureEngine
import com.example.data.db.DcsDatabase
import com.example.data.repository.TrafficRepository
import com.example.data.settings.SettingsManager
import com.example.export.ExportManager

class DcsInspectorApp : Application() {

    lateinit var database: DcsDatabase
        private set
    lateinit var settingsManager: SettingsManager
        private set
    lateinit var repository: TrafficRepository
        private set
    lateinit var browserManager: BrowserManager
        private set
    lateinit var captureEngine: CaptureEngine
        private set
    lateinit var exportManager: ExportManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        database = DcsDatabase.getInstance(this)
        settingsManager = SettingsManager(this)
        repository = TrafficRepository(this, database)
        browserManager = BrowserManager(this)
        captureEngine = CaptureEngine(repository)
        exportManager = ExportManager(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val vpnChannel = NotificationChannel(
                CHANNEL_VPN,
                getString(R.string.vpn_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.vpn_channel_desc)
                setShowBadge(false)
            }
            val proxyChannel = NotificationChannel(
                CHANNEL_PROXY,
                getString(R.string.proxy_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
            }
            nm.createNotificationChannel(vpnChannel)
            nm.createNotificationChannel(proxyChannel)
        }
    }

    companion object {
        const val CHANNEL_VPN = "dcs_vpn_channel"
        const val CHANNEL_PROXY = "dcs_proxy_channel"

        lateinit var instance: DcsInspectorApp
            private set
    }
}
