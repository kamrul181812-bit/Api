package com.example.capture

import java.net.InetAddress
import java.nio.ByteBuffer

object PacketCodec {

    const val PROTO_ICMP = 1
    const val PROTO_TCP = 6
    const val PROTO_UDP = 17

    const val TCP_FIN = 0x01
    const val TCP_SYN = 0x02
    const val TCP_RST = 0x04
    const val TCP_PSH = 0x08
    const val TCP_ACK = 0x10

    data class IpPacket(
        val version: Int,
        val headerLength: Int,
        val protocol: Int,
        val totalLength: Int,
        val srcIpBytes: ByteArray,
        val dstIpBytes: ByteArray,
        val srcIp: String,
        val dstIp: String,
        val payloadOffset: Int,
        val payloadLength: Int
    )

    data class TcpHeader(
        val srcPort: Int,
        val dstPort: Int,
        val seqNumber: Long,
        val ackNumber: Long,
        val headerLength: Int,
        val flags: Int,
        val windowSize: Int,
        val payloadOffset: Int,
        val payloadLength: Int
    ) {
        val isSyn: Boolean get() = (flags and TCP_SYN) != 0
        val isAck: Boolean get() = (flags and TCP_ACK) != 0
        val isFin: Boolean get() = (flags and TCP_FIN) != 0
        val isRst: Boolean get() = (flags and TCP_RST) != 0
        val isPsh: Boolean get() = (flags and TCP_PSH) != 0
    }

    data class UdpHeader(
        val srcPort: Int,
        val dstPort: Int,
        val length: Int,
        val payloadOffset: Int,
        val payloadLength: Int
    )

    data class TlsClientHelloInfo(
        val sniHost: String?,
        val alpnProtocols: List<String>
    )

    data class DnsParsedPacket(
        val queryDomain: String?,
        val resolvedARecords: Map<String, String>
    )

    fun parseIpPacket(buffer: ByteArray, length: Int): IpPacket? {
        if (length < 20) return null
        val version = (buffer[0].toInt() ushr 4) and 0x0F
        if (version != 4) return null
        val ihl = (buffer[0].toInt() and 0x0F) * 4
        if (ihl < 20 || length < ihl) return null
        val totalLen = ((buffer[2].toInt() and 0xFF) shl 8) or (buffer[3].toInt() and 0xFF)
        val effectiveLen = minOf(length, totalLen)
        if (effectiveLen < ihl) return null
        val proto = buffer[9].toInt() and 0xFF
        val srcBytes = buffer.copyOfRange(12, 16)
        val dstBytes = buffer.copyOfRange(16, 20)
        return IpPacket(
            version = version,
            headerLength = ihl,
            protocol = proto,
            totalLength = effectiveLen,
            srcIpBytes = srcBytes,
            dstIpBytes = dstBytes,
            srcIp = InetAddress.getByAddress(srcBytes).hostAddress ?: "0.0.0.0",
            dstIp = InetAddress.getByAddress(dstBytes).hostAddress ?: "0.0.0.0",
            payloadOffset = ihl,
            payloadLength = effectiveLen - ihl
        )
    }

    fun parseTcpHeader(buffer: ByteArray, ip: IpPacket): TcpHeader? {
        val off = ip.payloadOffset
        if (ip.payloadLength < 20 || off + 20 > buffer.size) return null
        val srcPort = ((buffer[off].toInt() and 0xFF) shl 8) or (buffer[off + 1].toInt() and 0xFF)
        val dstPort = ((buffer[off + 2].toInt() and 0xFF) shl 8) or (buffer[off + 3].toInt() and 0xFF)
        val seq = readUInt32(buffer, off + 4)
        val ack = readUInt32(buffer, off + 8)
        val dataOffset = ((buffer[off + 12].toInt() ushr 4) and 0x0F) * 4
        if (dataOffset < 20 || dataOffset > ip.payloadLength) return null
        val flags = buffer[off + 13].toInt() and 0x3F
        val window = ((buffer[off + 14].toInt() and 0xFF) shl 8) or (buffer[off + 15].toInt() and 0xFF)
        return TcpHeader(
            srcPort = srcPort,
            dstPort = dstPort,
            seqNumber = seq,
            ackNumber = ack,
            headerLength = dataOffset,
            flags = flags,
            windowSize = window,
            payloadOffset = off + dataOffset,
            payloadLength = ip.payloadLength - dataOffset
        )
    }

    fun parseUdpHeader(buffer: ByteArray, ip: IpPacket): UdpHeader? {
        val off = ip.payloadOffset
        if (ip.payloadLength < 8 || off + 8 > buffer.size) return null
        val srcPort = ((buffer[off].toInt() and 0xFF) shl 8) or (buffer[off + 1].toInt() and 0xFF)
        val dstPort = ((buffer[off + 2].toInt() and 0xFF) shl 8) or (buffer[off + 3].toInt() and 0xFF)
        val udpLen = ((buffer[off + 4].toInt() and 0xFF) shl 8) or (buffer[off + 5].toInt() and 0xFF)
        val payloadLen = (minOf(ip.payloadLength, udpLen) - 8).coerceAtLeast(0)
        return UdpHeader(
            srcPort = srcPort,
            dstPort = dstPort,
            length = udpLen,
            payloadOffset = off + 8,
            payloadLength = payloadLen
        )
    }

    fun buildIpv4TcpPacket(
        srcIpBytes: ByteArray,
        dstIpBytes: ByteArray,
        srcPort: Int,
        dstPort: Int,
        seqNumber: Long,
        ackNumber: Long,
        flags: Int,
        windowSize: Int = 65535,
        ipId: Int = 0,
        payload: ByteArray = ByteArray(0)
    ): ByteArray {
        val ipHeaderLen = 20
        val tcpHeaderLen = 20
        val totalLen = ipHeaderLen + tcpHeaderLen + payload.size
        val pkt = ByteArray(totalLen)

        // IPv4 Header
        pkt[0] = 0x45.toByte()
        pkt[1] = 0x00
        writeUInt16(pkt, 2, totalLen)
        writeUInt16(pkt, 4, ipId and 0xFFFF)
        pkt[6] = 0x40.toByte() // Don't Fragment
        pkt[7] = 0x00
        pkt[8] = 64.toByte() // TTL
        pkt[9] = PROTO_TCP.toByte()
        System.arraycopy(srcIpBytes, 0, pkt, 12, 4)
        System.arraycopy(dstIpBytes, 0, pkt, 16, 4)
        writeUInt16(pkt, 10, computeIpChecksum(pkt, 0, ipHeaderLen))

        // TCP Header
        val tcpOff = ipHeaderLen
        writeUInt16(pkt, tcpOff, srcPort)
        writeUInt16(pkt, tcpOff + 2, dstPort)
        writeUInt32(pkt, tcpOff + 4, seqNumber)
        writeUInt32(pkt, tcpOff + 8, ackNumber)
        pkt[tcpOff + 12] = ((tcpHeaderLen / 4) shl 4).toByte()
        pkt[tcpOff + 13] = (flags and 0x3F).toByte()
        writeUInt16(pkt, tcpOff + 14, windowSize.coerceIn(1024, 65535))
        if (payload.isNotEmpty()) {
            System.arraycopy(payload, 0, pkt, tcpOff + tcpHeaderLen, payload.size)
        }
        val tcpChecksum = computeTransportChecksum(
            srcIpBytes = srcIpBytes,
            dstIpBytes = dstIpBytes,
            protocol = PROTO_TCP,
            segment = pkt,
            offset = tcpOff,
            length = tcpHeaderLen + payload.size
        )
        writeUInt16(pkt, tcpOff + 16, tcpChecksum)
        return pkt
    }

    fun buildIpv4UdpPacket(
        srcIpBytes: ByteArray,
        dstIpBytes: ByteArray,
        srcPort: Int,
        dstPort: Int,
        ipId: Int = 0,
        payload: ByteArray
    ): ByteArray {
        val ipHeaderLen = 20
        val udpLen = 8 + payload.size
        val totalLen = ipHeaderLen + udpLen
        val pkt = ByteArray(totalLen)

        pkt[0] = 0x45.toByte()
        writeUInt16(pkt, 2, totalLen)
        writeUInt16(pkt, 4, ipId and 0xFFFF)
        pkt[8] = 64.toByte()
        pkt[9] = PROTO_UDP.toByte()
        System.arraycopy(srcIpBytes, 0, pkt, 12, 4)
        System.arraycopy(dstIpBytes, 0, pkt, 16, 4)
        writeUInt16(pkt, 10, computeIpChecksum(pkt, 0, ipHeaderLen))

        val udpOff = ipHeaderLen
        writeUInt16(pkt, udpOff, srcPort)
        writeUInt16(pkt, udpOff + 2, dstPort)
        writeUInt16(pkt, udpOff + 4, udpLen)
        System.arraycopy(payload, 0, pkt, udpOff + 8, payload.size)
        val udpChecksum = computeTransportChecksum(
            srcIpBytes = srcIpBytes,
            dstIpBytes = dstIpBytes,
            protocol = PROTO_UDP,
            segment = pkt,
            offset = udpOff,
            length = udpLen
        )
        writeUInt16(pkt, udpOff + 6, if (udpChecksum == 0) 0xFFFF else udpChecksum)
        return pkt
    }

    fun parseTlsClientHello(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): TlsClientHelloInfo? {
        if (length < 44 || offset + length > data.size) return null
        if (data[offset].toInt() and 0xFF != 0x16) return null // TLS Handshake
        if (data[offset + 5].toInt() and 0xFF != 0x01) return null // ClientHello

        var pos = offset + 5 + 4 // skip record + handshake header
        val end = offset + length
        if (pos + 2 + 32 + 1 > end) return null
        pos += 2 + 32 // skip version + random

        val sessionIdLen = data[pos].toInt() and 0xFF
        pos += 1 + sessionIdLen
        if (pos + 2 > end) return null

        val cipherSuitesLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
        pos += 2 + cipherSuitesLen
        if (pos + 1 > end) return null

        val compMethodsLen = data[pos].toInt() and 0xFF
        pos += 1 + compMethodsLen
        if (pos + 2 > end) return null

        val extensionsLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
        pos += 2
        val extEnd = minOf(end, pos + extensionsLen)

        var sniHost: String? = null
        val alpn = mutableListOf<String>()

        while (pos + 4 <= extEnd) {
            val extType = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
            val extLen = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
            pos += 4
            if (pos + extLen > extEnd) break

            when (extType) {
                0x0000 -> { // SNI
                    if (extLen >= 5) {
                        val listLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                        var p = pos + 2
                        val sniEnd = minOf(pos + extLen, p + listLen)
                        while (p + 3 <= sniEnd) {
                            val nameType = data[p].toInt() and 0xFF
                            val nameLen = ((data[p + 1].toInt() and 0xFF) shl 8) or (data[p + 2].toInt() and 0xFF)
                            p += 3
                            if (p + nameLen <= sniEnd && nameType == 0) {
                                sniHost = String(data, p, nameLen, Charsets.UTF_8)
                                break
                            }
                            p += nameLen
                        }
                    }
                }
                0x0010 -> { // ALPN
                    if (extLen >= 3) {
                        val listLen = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                        var p = pos + 2
                        val alpnEnd = minOf(pos + extLen, p + listLen)
                        while (p + 1 <= alpnEnd) {
                            val protoLen = data[p].toInt() and 0xFF
                            p += 1
                            if (p + protoLen <= alpnEnd && protoLen > 0) {
                                alpn.add(String(data, p, protoLen, Charsets.UTF_8))
                            }
                            p += protoLen
                        }
                    }
                }
            }
            pos += extLen
        }
        return TlsClientHelloInfo(sniHost = sniHost, alpnProtocols = alpn)
    }

    fun parseDnsMessage(data: ByteArray, offset: Int = 0, length: Int = data.size - offset): DnsParsedPacket {
        if (length < 12 || offset + length > data.size) return DnsParsedPacket(null, emptyMap())
        val qdCount = ((data[offset + 4].toInt() and 0xFF) shl 8) or (data[offset + 5].toInt() and 0xFF)
        val anCount = ((data[offset + 6].toInt() and 0xFF) shl 8) or (data[offset + 7].toInt() and 0xFF)
        var pos = offset + 12
        val end = offset + length
        var firstDomain: String? = null

        for (i in 0 until qdCount) {
            val (name, nextPos) = readDnsName(data, offset, end, pos)
            if (firstDomain == null && name.isNotBlank()) firstDomain = name
            pos = nextPos + 4 // QTYPE + QCLASS
            if (pos > end) return DnsParsedPacket(firstDomain, emptyMap())
        }

        val aRecords = mutableMapOf<String, String>()
        for (i in 0 until anCount) {
            if (pos >= end) break
            val (rrName, afterName) = readDnsName(data, offset, end, pos)
            if (afterName + 10 > end) break
            val type = ((data[afterName].toInt() and 0xFF) shl 8) or (data[afterName + 1].toInt() and 0xFF)
            val rdLength = ((data[afterName + 8].toInt() and 0xFF) shl 8) or (data[afterName + 9].toInt() and 0xFF)
            val rdataPos = afterName + 10
            if (rdataPos + rdLength > end) break
            if (type == 1 && rdLength == 4) { // A record
                val ip = "${data[rdataPos].toInt() and 0xFF}.${data[rdataPos + 1].toInt() and 0xFF}.${data[rdataPos + 2].toInt() and 0xFF}.${data[rdataPos + 3].toInt() and 0xFF}"
                val domain = rrName.ifBlank { firstDomain.orEmpty() }
                if (domain.isNotBlank()) {
                    aRecords[ip] = domain
                }
            }
            pos = rdataPos + rdLength
        }
        return DnsParsedPacket(firstDomain, aRecords)
    }

    private fun readDnsName(data: ByteArray, baseOffset: Int, end: Int, startPos: Int): Pair<String, Int> {
        val sb = StringBuilder()
        var pos = startPos
        var jumped = false
        var returnPos = startPos
        var safety = 0

        while (pos < end && safety++ < 64) {
            val len = data[pos].toInt() and 0xFF
            if (len == 0) {
                if (!jumped) returnPos = pos + 1
                break
            }
            if ((len and 0xC0) == 0xC0) {
                if (pos + 1 >= end) break
                val pointer = ((len and 0x3F) shl 8) or (data[pos + 1].toInt() and 0xFF)
                if (!jumped) returnPos = pos + 2
                jumped = true
                pos = baseOffset + pointer
            } else {
                pos++
                if (pos + len > end) break
                if (sb.isNotEmpty()) sb.append('.')
                sb.append(String(data, pos, len, Charsets.UTF_8))
                pos += len
                if (!jumped) returnPos = pos
            }
        }
        return sb.toString() to returnPos
    }

    fun computeIpChecksum(buf: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += ((buf[i].toInt() and 0xFF) shl 8) or (buf[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) {
            sum += (buf[i].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    fun computeTransportChecksum(
        srcIpBytes: ByteArray,
        dstIpBytes: ByteArray,
        protocol: Int,
        segment: ByteArray,
        offset: Int,
        length: Int
    ): Int {
        var sum = 0L
        // Pseudo header
        sum += ((srcIpBytes[0].toInt() and 0xFF) shl 8) or (srcIpBytes[1].toInt() and 0xFF)
        sum += ((srcIpBytes[2].toInt() and 0xFF) shl 8) or (srcIpBytes[3].toInt() and 0xFF)
        sum += ((dstIpBytes[0].toInt() and 0xFF) shl 8) or (dstIpBytes[1].toInt() and 0xFF)
        sum += ((dstIpBytes[2].toInt() and 0xFF) shl 8) or (dstIpBytes[3].toInt() and 0xFF)
        sum += protocol.toLong()
        sum += length.toLong()

        var i = offset
        val end = offset + length
        while (i + 1 < end) {
            sum += ((segment[i].toInt() and 0xFF) shl 8) or (segment[i + 1].toInt() and 0xFF)
            i += 2
        }
        if (i < end) {
            sum += (segment[i].toInt() and 0xFF) shl 8
        }
        while ((sum ushr 16) != 0L) {
            sum = (sum and 0xFFFF) + (sum ushr 16)
        }
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun readUInt32(buf: ByteArray, off: Int): Long =
        ((buf[off].toLong() and 0xFF) shl 24) or
            ((buf[off + 1].toLong() and 0xFF) shl 16) or
            ((buf[off + 2].toLong() and 0xFF) shl 8) or
            (buf[off + 3].toLong() and 0xFF)

    private fun writeUInt16(buf: ByteArray, off: Int, value: Int) {
        buf[off] = ((value ushr 8) and 0xFF).toByte()
        buf[off + 1] = (value and 0xFF).toByte()
    }

    private fun writeUInt32(buf: ByteArray, off: Int, value: Long) {
        buf[off] = ((value ushr 24) and 0xFF).toByte()
        buf[off + 1] = ((value ushr 16) and 0xFF).toByte()
        buf[off + 2] = ((value ushr 8) and 0xFF).toByte()
        buf[off + 3] = (value and 0xFF).toByte()
    }
}
