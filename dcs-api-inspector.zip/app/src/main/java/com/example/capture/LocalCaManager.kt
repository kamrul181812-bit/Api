package com.example.capture

import android.content.Context
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory

data class CaCertStatus(
    val isGenerated: Boolean,
    val subject: String,
    val sha256Fingerprint: String,
    val validUntil: String,
    val pemFilePath: String?
)

/**
 * Generates and manages a local developer-testing Root CA & leaf X.509 certificates using pure ASN.1 DER encoding.
 * Intended strictly for authorized testing environments where the developer explicitly installs the CA for their own test apps.
 */
object LocalCaManager {

    private const val CA_DIR = "certs"
    private const val CA_CERT_FILE = "dcs_inspector_root_ca.crt"
    private const val CA_KEY_FILE = "dcs_inspector_root_ca.key"

    fun getOrCreateRootCa(context: Context): Pair<X509Certificate, PrivateKey> {
        val dir = File(context.filesDir, CA_DIR).apply { mkdirs() }
        val certFile = File(dir, CA_CERT_FILE)
        val keyFile = File(dir, CA_KEY_FILE)

        if (certFile.exists() && keyFile.exists()) {
            val loaded = runCatching {
                val cf = CertificateFactory.getInstance("X.509")
                val cert = certFile.inputStream().use { cf.generateCertificate(it) as X509Certificate }
                val keyBytes = keyFile.readBytes()
                val priv = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
                cert to priv
            }.getOrNull()
            if (loaded != null) return loaded
        }

        val (cert, keyPair) = generateSelfSignedRootCa()
        val pem = encodePem(cert.encoded)
        certFile.writeText(pem)
        keyFile.writeBytes(keyPair.private.encoded)
        return cert to keyPair.private
    }

    fun getCaStatus(context: Context): CaCertStatus {
        val dir = File(context.filesDir, CA_DIR)
        val certFile = File(dir, CA_CERT_FILE)
        if (!certFile.exists()) {
            return CaCertStatus(
                isGenerated = false,
                subject = "Not generated yet",
                sha256Fingerprint = "-",
                validUntil = "-",
                pemFilePath = null
            )
        }
        return runCatching {
            val cf = CertificateFactory.getInstance("X.509")
            val cert = certFile.inputStream().use { cf.generateCertificate(it) as X509Certificate }
            val md = java.security.MessageDigest.getInstance("SHA-256").digest(cert.encoded)
            val fp = md.joinToString(":") { "%02X".format(it) }
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            CaCertStatus(
                isGenerated = true,
                subject = cert.subjectX500Principal.name,
                sha256Fingerprint = fp,
                validUntil = df.format(cert.notAfter),
                pemFilePath = certFile.absolutePath
            )
        }.getOrElse {
            CaCertStatus(false, "Invalid certificate", "-", "-", null)
        }
    }

    fun exportPemContent(context: Context): String {
        val (cert, _) = getOrCreateRootCa(context)
        return encodePem(cert.encoded)
    }

    fun buildLeafSslContextForDomain(context: Context, domain: String): SSLContext {
        val (caCert, caKey) = getOrCreateRootCa(context)
        val leafPair = generateRsa2048KeyPair()
        val leafCert = generateLeafCertificate(domain, leafPair, caCert, caKey)

        val ks = KeyStore.getInstance(KeyStore.getDefaultType())
        ks.load(null, null)
        val pwd = "dcs".toCharArray()
        ks.setKeyEntry("leaf", leafPair.private, pwd, arrayOf(leafCert, caCert))

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, pwd)
        return SSLContext.getInstance("TLS").apply {
            init(kmf.keyManagers, null, SecureRandom())
        }
    }

    fun generateSelfSignedRootCa(): Pair<X509Certificate, KeyPair> {
        val keyPair = generateRsa2048KeyPair()
        val now = System.currentTimeMillis()
        val notBefore = Date(now - 24 * 3600_000L)
        val notAfter = Date(now + 3650L * 24 * 3600_000L)

        val subject = encodeName("DCS API Inspector Local Test CA", "Dark Cyber Security")
        val spki = keyPair.public.encoded
        val serial = BigInteger(63, SecureRandom()).abs().max(BigInteger.ONE)

        val basicConstraintsExt = encodeExtension(
            oid = byteArrayOf(0x55, 0x1D, 0x13), // 2.5.29.19 BasicConstraints
            critical = true,
            value = derSequence(derBoolean(true))
        )
        val keyUsageExt = encodeExtension(
            oid = byteArrayOf(0x55, 0x1D, 0x0F), // 2.5.29.15 KeyUsage
            critical = true,
            value = derBitString(byteArrayOf(0x06.toByte()), unusedBits = 1) // keyCertSign + cRLSign
        )

        val tbsCert = derSequence(
            derContextExplicit(0, derInteger(BigInteger.valueOf(2))), // v3
            derInteger(serial),
            sha256WithRsaAlgId(),
            subject,
            derSequence(derUtcTime(notBefore), derUtcTime(notAfter)),
            subject,
            spki,
            derContextExplicit(3, derSequence(basicConstraintsExt, keyUsageExt))
        )

        val sig = Signature.getInstance("SHA256withRSA").apply {
            initSign(keyPair.private)
            update(tbsCert)
        }.sign()

        val certBytes = derSequence(tbsCert, sha256WithRsaAlgId(), derBitString(sig, 0))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
        return cert to keyPair
    }

    fun generateLeafCertificate(
        domain: String,
        leafKeyPair: KeyPair,
        caCert: X509Certificate,
        caPrivateKey: PrivateKey
    ): X509Certificate {
        val now = System.currentTimeMillis()
        val notBefore = Date(now - 24 * 3600_000L)
        val notAfter = Date(now + 90L * 24 * 3600_000L)
        val issuer = encodeName("DCS API Inspector Local Test CA", "Dark Cyber Security")
        val subject = encodeName(domain, "DCS Authorized Test")
        val serial = BigInteger(63, SecureRandom()).abs().max(BigInteger.ONE)

        // SubjectAltName dNSName [2]
        val sanValue = derSequence(derContextPrimitive(2, domain.toByteArray(Charsets.UTF_8)))
        val sanExt = encodeExtension(
            oid = byteArrayOf(0x55, 0x1D, 0x11), // 2.5.29.17
            critical = false,
            value = sanValue
        )

        val tbsCert = derSequence(
            derContextExplicit(0, derInteger(BigInteger.valueOf(2))),
            derInteger(serial),
            sha256WithRsaAlgId(),
            issuer,
            derSequence(derUtcTime(notBefore), derUtcTime(notAfter)),
            subject,
            leafKeyPair.public.encoded,
            derContextExplicit(3, derSequence(sanExt))
        )

        val sig = Signature.getInstance("SHA256withRSA").apply {
            initSign(caPrivateKey)
            update(tbsCert)
        }.sign()

        val certBytes = derSequence(tbsCert, sha256WithRsaAlgId(), derBitString(sig, 0))
        return CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
    }

    private fun generateRsa2048KeyPair(): KeyPair {
        return KeyPairGenerator.getInstance("RSA").apply {
            initialize(2048, SecureRandom())
        }.generateKeyPair()
    }

    private fun encodePem(der: ByteArray): String {
        val b64 = Base64.encodeToString(der, Base64.NO_WRAP).chunked(64).joinToString("\n")
        return "-----BEGIN CERTIFICATE-----\n$b64\n-----END CERTIFICATE-----\n"
    }

    private fun encodeName(cn: String, org: String): ByteArray {
        val orgRdn = derSet(derSequence(derOid(byteArrayOf(0x55, 0x04, 0x0A)), derUtf8String(org)))
        val cnRdn = derSet(derSequence(derOid(byteArrayOf(0x55, 0x04, 0x03)), derUtf8String(cn)))
        return derSequence(orgRdn, cnRdn)
    }

    private fun sha256WithRsaAlgId(): ByteArray {
        // 1.2.840.113549.1.1.11 sha256WithRSAEncryption
        val oid = byteArrayOf(0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x01, 0x0B)
        return derSequence(derOid(oid), byteArrayOf(0x05, 0x00))
    }

    private fun encodeExtension(oid: ByteArray, critical: Boolean, value: ByteArray): ByteArray {
        return if (critical) {
            derSequence(derOid(oid), derBoolean(true), derOctetString(value))
        } else {
            derSequence(derOid(oid), derOctetString(value))
        }
    }

    private fun derSequence(vararg items: ByteArray): ByteArray = derWrap(0x30, concat(*items))
    private fun derSet(vararg items: ByteArray): ByteArray = derWrap(0x31, concat(*items))
    private fun derOid(bytes: ByteArray): ByteArray = derWrap(0x06, bytes)
    private fun derOctetString(bytes: ByteArray): ByteArray = derWrap(0x04, bytes)
    private fun derUtf8String(text: String): ByteArray = derWrap(0x0C, text.toByteArray(Charsets.UTF_8))
    private fun derBoolean(v: Boolean): ByteArray = byteArrayOf(0x01, 0x01, if (v) 0xFF.toByte() else 0x00)
    private fun derInteger(v: BigInteger): ByteArray = derWrap(0x02, v.toByteArray())
    private fun derContextExplicit(tag: Int, inner: ByteArray): ByteArray = derWrap(0xA0 or tag, inner)
    private fun derContextPrimitive(tag: Int, inner: ByteArray): ByteArray = derWrap(0x80 or tag, inner)

    private fun derBitString(bytes: ByteArray, unusedBits: Int): ByteArray {
        val body = ByteArray(bytes.size + 1)
        body[0] = unusedBits.toByte()
        System.arraycopy(bytes, 0, body, 1, bytes.size)
        return derWrap(0x03, body)
    }

    private fun derUtcTime(date: Date): ByteArray {
        val fmt = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        return derWrap(0x17, fmt.format(date).toByteArray(Charsets.US_ASCII))
    }

    private fun derWrap(tag: Int, content: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(tag)
        val len = content.size
        when {
            len < 128 -> out.write(len)
            len <= 0xFF -> {
                out.write(0x81)
                out.write(len)
            }
            len <= 0xFFFF -> {
                out.write(0x82)
                out.write((len ushr 8) and 0xFF)
                out.write(len and 0xFF)
            }
            else -> {
                out.write(0x83)
                out.write((len ushr 16) and 0xFF)
                out.write((len ushr 8) and 0xFF)
                out.write(len and 0xFF)
            }
        }
        out.write(content)
        return out.toByteArray()
    }

    private fun concat(vararg items: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        items.forEach { out.write(it) }
        return out.toByteArray()
    }
}
