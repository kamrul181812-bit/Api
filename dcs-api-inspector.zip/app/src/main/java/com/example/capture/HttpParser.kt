package com.example.capture

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.URLDecoder
import java.util.zip.GZIPInputStream

object HttpParser {

    private val httpMethods = setOf(
        "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS", "CONNECT", "TRACE"
    )

    data class ParsedHttpRequest(
        val method: String,
        val rawTarget: String,
        val httpVersion: String,
        val host: String,
        val path: String,
        val queryParams: Map<String, String>,
        val headers: Map<String, String>,
        val bodyText: String?,
        val contentType: String?,
        val isComplete: Boolean,
        val rawHeaderBlock: String
    )

    data class ParsedHttpResponse(
        val httpVersion: String,
        val statusCode: Int,
        val statusMessage: String,
        val headers: Map<String, String>,
        val bodyText: String?,
        val contentType: String?,
        val isComplete: Boolean,
        val rawHeaderBlock: String
    )

    fun looksLikeHttpRequest(bytes: ByteArray, length: Int = bytes.size): Boolean {
        if (length < 12) return false
        val preview = String(bytes, 0, minOf(length, 24), Charsets.ISO_8859_1)
        val firstWord = preview.substringBefore(' ').uppercase()
        return firstWord in httpMethods && preview.contains(' ')
    }

    fun parseHttpRequest(bytes: ByteArray, defaultHost: String, scheme: String = "http"): ParsedHttpRequest? {
        val headerEnd = findHeaderEnd(bytes)
        val headerBytesLen = if (headerEnd >= 0) headerEnd else minOf(bytes.size, 8192)
        val headerBlock = String(bytes, 0, headerBytesLen, Charsets.ISO_8859_1)
        val lines = headerBlock.split("\r\n", "\n")
        if (lines.isEmpty()) return null

        val requestLineParts = lines[0].trim().split(" ")
        if (requestLineParts.size < 2) return null
        val method = requestLineParts[0].uppercase()
        if (method !in httpMethods) return null

        val rawTarget = requestLineParts[1]
        val version = requestLineParts.getOrNull(2) ?: "HTTP/1.1"
        val headers = linkedMapOf<String, String>()
        for (i in 1 until lines.size) {
            val line = lines[i]
            val colon = line.indexOf(':')
            if (colon > 0) {
                val key = line.substring(0, colon).trim()
                val value = line.substring(colon + 1).trim()
                headers[key] = value
            }
        }

        val hostHeader = headers.entries.firstOrNull { it.key.equals("Host", ignoreCase = true) }?.value
        val host = hostHeader ?: extractHostFromTarget(rawTarget) ?: defaultHost
        val path = extractPathFromTarget(rawTarget)
        val queryParams = extractQueryParams(rawTarget)
        val contentType = headers.entries.firstOrNull { it.key.equals("Content-Type", ignoreCase = true) }?.value

        var bodyText: String? = null
        var complete = headerEnd >= 0
        if (headerEnd >= 0) {
            val bodyOffset = headerEnd + separatorLength(bytes, headerEnd)
            val rawBody = if (bodyOffset < bytes.size) {
                bytes.copyOfRange(bodyOffset, bytes.size)
            } else {
                ByteArray(0)
            }
            val contentLength = headers.entries.firstOrNull { it.key.equals("Content-Length", ignoreCase = true) }?.value?.toIntOrNull()
            val isChunked = headers.entries.firstOrNull { it.key.equals("Transfer-Encoding", ignoreCase = true) }?.value?.contains("chunked", true) == true
            val isGzip = headers.entries.firstOrNull { it.key.equals("Content-Encoding", ignoreCase = true) }?.value?.contains("gzip", true) == true

            if (contentLength != null) {
                complete = rawBody.size >= contentLength
                val slice = rawBody.copyOfRange(0, minOf(rawBody.size, contentLength))
                bodyText = decodeBodyBytes(slice, contentType, isGzip)
            } else if (isChunked) {
                val (decoded, chunkDone) = decodeChunkedBody(rawBody)
                complete = chunkDone
                bodyText = decodeBodyBytes(decoded, contentType, isGzip)
            } else if (rawBody.isNotEmpty()) {
                bodyText = decodeBodyBytes(rawBody, contentType, isGzip)
            }
        }

        return ParsedHttpRequest(
            method = method,
            rawTarget = rawTarget,
            httpVersion = version,
            host = host,
            path = path,
            queryParams = queryParams,
            headers = headers,
            bodyText = bodyText,
            contentType = contentType,
            isComplete = complete,
            rawHeaderBlock = headerBlock
        )
    }

    fun parseHttpResponse(bytes: ByteArray): ParsedHttpResponse? {
        if (bytes.size < 12) return null
        val headerEnd = findHeaderEnd(bytes)
        val headerBytesLen = if (headerEnd >= 0) headerEnd else minOf(bytes.size, 8192)
        val headerBlock = String(bytes, 0, headerBytesLen, Charsets.ISO_8859_1)
        val lines = headerBlock.split("\r\n", "\n")
        if (lines.isEmpty()) return null

        val statusLine = lines[0].trim()
        if (!statusLine.startsWith("HTTP/")) return null
        val parts = statusLine.split(" ", limit = 3)
        val version = parts.getOrNull(0) ?: "HTTP/1.1"
        val statusCode = parts.getOrNull(1)?.toIntOrNull() ?: return null
        val statusMsg = parts.getOrNull(2).orEmpty()

        val headers = linkedMapOf<String, String>()
        for (i in 1 until lines.size) {
            val line = lines[i]
            val colon = line.indexOf(':')
            if (colon > 0) {
                headers[line.substring(0, colon).trim()] = line.substring(colon + 1).trim()
            }
        }

        val contentType = headers.entries.firstOrNull { it.key.equals("Content-Type", ignoreCase = true) }?.value
        val contentLength = headers.entries.firstOrNull { it.key.equals("Content-Length", ignoreCase = true) }?.value?.toIntOrNull()
        val isChunked = headers.entries.firstOrNull { it.key.equals("Transfer-Encoding", ignoreCase = true) }?.value?.contains("chunked", true) == true
        val isGzip = headers.entries.firstOrNull { it.key.equals("Content-Encoding", ignoreCase = true) }?.value?.contains("gzip", true) == true

        var bodyText: String? = null
        var complete = false
        if (headerEnd >= 0) {
            val bodyOffset = headerEnd + separatorLength(bytes, headerEnd)
            val rawBody = if (bodyOffset < bytes.size) {
                bytes.copyOfRange(bodyOffset, bytes.size)
            } else {
                ByteArray(0)
            }
            when {
                isChunked -> {
                    val (decoded, chunkDone) = decodeChunkedBody(rawBody)
                    complete = chunkDone
                    bodyText = decodeBodyBytes(decoded, contentType, isGzip)
                }
                contentLength != null -> {
                    complete = rawBody.size >= contentLength
                    val slice = rawBody.copyOfRange(0, minOf(rawBody.size, contentLength))
                    bodyText = decodeBodyBytes(slice, contentType, isGzip)
                }
                else -> {
                    complete = statusCode == 204 || statusCode == 304
                    if (rawBody.isNotEmpty()) {
                        bodyText = decodeBodyBytes(rawBody, contentType, isGzip)
                    }
                }
            }
        }

        return ParsedHttpResponse(
            httpVersion = version,
            statusCode = statusCode,
            statusMessage = statusMsg,
            headers = headers,
            bodyText = bodyText,
            contentType = contentType,
            isComplete = complete,
            rawHeaderBlock = headerBlock
        )
    }

    private fun findHeaderEnd(bytes: ByteArray): Int {
        for (i in 0 until bytes.size - 3) {
            if (bytes[i] == '\r'.code.toByte() &&
                bytes[i + 1] == '\n'.code.toByte() &&
                bytes[i + 2] == '\r'.code.toByte() &&
                bytes[i + 3] == '\n'.code.toByte()
            ) {
                return i
            }
        }
        for (i in 0 until bytes.size - 1) {
            if (bytes[i] == '\n'.code.toByte() && bytes[i + 1] == '\n'.code.toByte()) {
                return i
            }
        }
        return -1
    }

    private fun separatorLength(bytes: ByteArray, index: Int): Int {
        if (index + 3 < bytes.size && bytes[index] == '\r'.code.toByte()) return 4
        return 2
    }

    private fun decodeBodyBytes(raw: ByteArray, contentType: String?, isGzip: Boolean): String? {
        if (raw.isEmpty()) return null
        val bytes = if (isGzip) {
            runCatching {
                GZIPInputStream(ByteArrayInputStream(raw)).use { it.readBytes() }
            }.getOrElse { raw }
        } else {
            raw
        }

        val ct = contentType?.lowercase().orEmpty()
        val isBinary = ct.startsWith("image/") || ct.startsWith("video/") || ct.startsWith("audio/") || ct.contains("octet-stream")
        if (isBinary) {
            return "[Binary Payload: ${bytes.size} bytes, Content-Type: ${contentType ?: "application/octet-stream"}]"
        }
        val capped = if (bytes.size > 262_144) bytes.copyOfRange(0, 262_144) else bytes
        return String(capped, Charsets.UTF_8)
    }

    fun decodeChunkedBody(raw: ByteArray): Pair<ByteArray, Boolean> {
        val out = ByteArrayOutputStream()
        var pos = 0
        while (pos < raw.size) {
            val lineEnd = findCrLf(raw, pos)
            if (lineEnd < 0) return out.toByteArray() to false
            val sizeLine = String(raw, pos, lineEnd - pos, Charsets.ISO_8859_1).substringBefore(';').trim()
            val chunkSize = sizeLine.toIntOrNull(16) ?: return out.toByteArray() to false
            pos = lineEnd + 2
            if (chunkSize == 0) {
                return out.toByteArray() to true
            }
            if (pos + chunkSize > raw.size) {
                out.write(raw, pos, raw.size - pos)
                return out.toByteArray() to false
            }
            out.write(raw, pos, chunkSize)
            pos += chunkSize + 2 // skip trailing \r\n
        }
        return out.toByteArray() to false
    }

    private fun findCrLf(raw: ByteArray, start: Int): Int {
        for (i in start until raw.size - 1) {
            if (raw[i] == '\r'.code.toByte() && raw[i + 1] == '\n'.code.toByte()) return i
        }
        return -1
    }

    private fun extractHostFromTarget(target: String): String? {
        if (target.startsWith("http://", true) || target.startsWith("https://", true)) {
            val afterScheme = target.substringAfter("://")
            return afterScheme.substringBefore('/').ifBlank { null }
        }
        return null
    }

    private fun extractPathFromTarget(target: String): String {
        if (target.startsWith("http://", true) || target.startsWith("https://", true)) {
            val afterScheme = target.substringAfter("://")
            val idx = afterScheme.indexOf('/')
            return if (idx >= 0) afterScheme.substring(idx) else "/"
        }
        return target
    }

    private fun extractQueryParams(target: String): Map<String, String> {
        val qIdx = target.indexOf('?')
        if (qIdx < 0 || qIdx == target.lastIndex) return emptyMap()
        val query = target.substring(qIdx + 1)
        val map = linkedMapOf<String, String>()
        query.split("&").forEach { pair ->
            if (pair.isNotBlank()) {
                val eq = pair.indexOf('=')
                if (eq > 0) {
                    val k = runCatching { URLDecoder.decode(pair.substring(0, eq), "UTF-8") }.getOrElse { pair.substring(0, eq) }
                    val v = runCatching { URLDecoder.decode(pair.substring(eq + 1), "UTF-8") }.getOrElse { pair.substring(eq + 1) }
                    map[k] = v
                } else {
                    map[pair] = ""
                }
            }
        }
        return map
    }
}
