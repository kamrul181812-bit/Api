package com.example.capture

import com.example.browser.AppAttribution
import com.example.classifier.DomainClassifier
import com.example.data.db.CaptureSessionEntity
import com.example.data.db.TrafficRecordEntity
import com.example.data.repository.TrafficRepository
import com.example.data.settings.InspectorSettings
import com.example.privacy.PrivacyRedactionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

data class CaptureEngineStatus(
    val isVpnRunning: Boolean = false,
    val isLocalProxyRunning: Boolean = false,
    val isPaused: Boolean = false,
    val activeSessionId: String? = null,
    val sessionStartedAt: Long = 0L,
    val totalRequests: Int = 0,
    val totalConnections: Int = 0,
    val uploadedBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val activeDomains: Set<String> = emptySet(),
    val lastCapturedRequestSummary: String? = null,
    val lastCapturedTimestamp: Long = 0L,
    val vpnConflictMessage: String? = null,
    val networkStatus: String = "Ready",
    val localProxyStatus: String = "Stopped"
) {
    val isMonitoring: Boolean get() = isVpnRunning || isLocalProxyRunning
}

/**
 * Independent network traffic capture coordinator decoupled from UI.
 * Sanitizes every captured record through PrivacyRedactionEngine before persistence.
 */
class CaptureEngine(
    private val repository: TrafficRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sequenceCounter = AtomicInteger(0)
    private val dnsCache = ConcurrentHashMap<String, String>()

    private val _status = MutableStateFlow(CaptureEngineStatus())
    val status: StateFlow<CaptureEngineStatus> = _status.asStateFlow()

    @Volatile
    var currentSettings: InspectorSettings = InspectorSettings()

    fun cacheDnsMapping(ip: String, domain: String) {
        if (ip.isNotBlank() && domain.isNotBlank()) {
            dnsCache[ip] = domain.trimEnd('.')
        }
    }

    fun lookupCachedDomain(ip: String): String? = dnsCache[ip]

    suspend fun ensureActiveSession(mode: String, settings: InspectorSettings): String {
        currentSettings = settings
        val existing = _status.value.activeSessionId
        if (existing != null && _status.value.isMonitoring) {
            return existing
        }
        val newId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        sequenceCounter.set(0)
        val session = CaptureSessionEntity(
            sessionId = newId,
            title = "Session ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(now))}",
            mode = mode,
            selectedBrowserPackage = settings.selectedBrowserPackage,
            selectedBrowserName = settings.selectedBrowserName,
            appScopeMode = settings.appScopeMode.name,
            startedAt = now,
            isActive = true
        )
        repository.startSession(session)
        _status.update {
            it.copy(
                activeSessionId = newId,
                sessionStartedAt = now,
                totalRequests = 0,
                totalConnections = 0,
                uploadedBytes = 0L,
                downloadedBytes = 0L,
                activeDomains = emptySet(),
                lastCapturedRequestSummary = null,
                lastCapturedTimestamp = 0L,
                vpnConflictMessage = null
            )
        }
        return newId
    }

    fun setVpnState(running: Boolean, networkStatus: String = if (running) "VPN Active" else "VPN Disconnected", conflictMsg: String? = null) {
        _status.update {
            it.copy(
                isVpnRunning = running,
                networkStatus = networkStatus,
                vpnConflictMessage = conflictMsg
            )
        }
        if (!running && !_status.value.isLocalProxyRunning) {
            scope.launch { repository.closeActiveSessions() }
        }
    }

    fun setLocalProxyState(running: Boolean, statusText: String) {
        _status.update {
            it.copy(
                isLocalProxyRunning = running,
                localProxyStatus = statusText
            )
        }
        if (!running && !_status.value.isVpnRunning) {
            scope.launch { repository.closeActiveSessions() }
        }
    }

    fun pauseRecording() {
        _status.update { it.copy(isPaused = true) }
    }

    fun resumeRecording() {
        _status.update { it.copy(isPaused = false) }
    }

    fun setNetworkStatus(text: String) {
        _status.update { it.copy(networkStatus = text) }
    }

    suspend fun clearCurrentSession() {
        val sid = _status.value.activeSessionId
        if (sid != null) {
            repository.clearSessionTraffic(sid)
        }
        sequenceCounter.set(0)
        _status.update {
            it.copy(
                totalRequests = 0,
                totalConnections = 0,
                uploadedBytes = 0L,
                downloadedBytes = 0L,
                activeDomains = emptySet(),
                lastCapturedRequestSummary = null,
                lastCapturedTimestamp = 0L
            )
        }
    }

    fun isPaused(): Boolean = _status.value.isPaused

    fun recordCapturedFlow(
        requestId: String = UUID.randomUUID().toString(),
        isUpdate: Boolean = false,
        isNewConnection: Boolean = !isUpdate,
        timestamp: Long = System.currentTimeMillis(),
        responseTimestamp: Long? = null,
        durationMs: Long = 0L,
        method: String,
        protocol: String,
        httpVersion: String,
        rawUrl: String,
        host: String,
        path: String,
        queryParams: Map<String, String> = emptyMap(),
        statusCode: Int = 0,
        statusMessage: String = "",
        remoteAddress: String,
        remotePort: Int,
        localPort: Int = 0,
        connectionType: String,
        attribution: AppAttribution,
        requestSize: Long,
        responseSize: Long,
        addedUpBytes: Long = requestSize,
        addedDownBytes: Long = responseSize,
        contentType: String? = null,
        requestHeaders: Map<String, String> = emptyMap(),
        responseHeaders: Map<String, String> = emptyMap(),
        rawRequestBody: String? = null,
        rawResponseBody: String? = null,
        rawRequestInfo: String = "",
        rawResponseInfo: String = "",
        isTlsMetadataOnly: Boolean = false,
        isSslProxied: Boolean = false,
        isPending: Boolean = false,
        isFailed: Boolean = false,
        errorMessage: String? = null,
        limitationNote: String? = null,
        timingBreakdown: String = "",
        seqNumberOverride: Int? = null
    ): Pair<String, Int>? {
        if (_status.value.isPaused) return null
        val sid = _status.value.activeSessionId ?: return null
        val settings = currentSettings
        val redactEnabled = settings.autoRedactSensitiveData

        var totalRedactions = 0
        val (safeUrl, urlRedactions) = if (redactEnabled) PrivacyRedactionEngine.redactUrl(rawUrl) else rawUrl to 0
        totalRedactions += urlRedactions

        val (safeReqHeaders, reqHRedactions) = if (redactEnabled) PrivacyRedactionEngine.redactHeaders(requestHeaders) else requestHeaders to 0
        totalRedactions += reqHRedactions

        val (safeRespHeaders, respHRedactions) = if (redactEnabled) PrivacyRedactionEngine.redactHeaders(responseHeaders) else responseHeaders to 0
        totalRedactions += respHRedactions

        val safeQueryParams = queryParams.mapValues { (k, v) ->
            if (redactEnabled && PrivacyRedactionEngine.isSensitiveKey(k)) {
                totalRedactions++
                PrivacyRedactionEngine.REDACTED_VALUE
            } else {
                v
            }
        }

        val reqContentType = requestHeaders.entries.firstOrNull { it.key.equals("Content-Type", true) }?.value ?: contentType
        val (safeReqBody, reqBRedactions) = if (redactEnabled) PrivacyRedactionEngine.redactBody(rawRequestBody, reqContentType) else rawRequestBody to 0
        totalRedactions += reqBRedactions

        val (safeRespBody, respBRedactions) = if (redactEnabled) PrivacyRedactionEngine.redactBody(rawResponseBody, contentType) else rawResponseBody to 0
        totalRedactions += respBRedactions

        val (safeRawReq, r1) = if (redactEnabled) PrivacyRedactionEngine.redactInlineSecrets(rawRequestInfo) else rawRequestInfo to 0
        val (safeRawResp, r2) = if (redactEnabled) PrivacyRedactionEngine.redactInlineSecrets(rawResponseInfo) else rawResponseInfo to 0
        totalRedactions += r1 + r2

        val cleanDomain = host.substringBefore(':').ifBlank {
            lookupCachedDomain(remoteAddress) ?: remoteAddress
        }
        val category = DomainClassifier.classify(
            url = safeUrl,
            host = cleanDomain,
            contentType = contentType,
            protocol = protocol,
            isTlsMetadataOnly = isTlsMetadataOnly
        )

        val seq = seqNumberOverride ?: sequenceCounter.incrementAndGet()
        val isSelectedBrowser = !settings.selectedBrowserPackage.isNullOrBlank() &&
            attribution.packageName == settings.selectedBrowserPackage

        val record = TrafficRecordEntity(
            requestId = requestId,
            sessionId = sid,
            sequenceNumber = seq,
            timestamp = timestamp,
            responseTimestamp = responseTimestamp,
            durationMs = durationMs,
            method = method.uppercase(),
            protocol = protocol,
            httpVersion = httpVersion,
            url = safeUrl,
            domain = cleanDomain,
            host = host.ifBlank { cleanDomain },
            path = path,
            queryParamsJson = JSONObject(safeQueryParams).toString(),
            statusCode = statusCode,
            statusMessage = statusMessage,
            remoteAddress = remoteAddress,
            remotePort = remotePort,
            localPort = localPort,
            connectionType = connectionType,
            appName = attribution.appName,
            packageName = attribution.packageName,
            isSelectedBrowser = isSelectedBrowser,
            requestSize = requestSize,
            responseSize = responseSize,
            contentType = contentType,
            requestHeadersJson = JSONObject(safeReqHeaders).toString(),
            responseHeadersJson = JSONObject(safeRespHeaders).toString(),
            requestBody = safeReqBody,
            responseBody = safeRespBody,
            rawRequestInfo = safeRawReq,
            rawResponseInfo = safeRawResp,
            isBodyAvailable = !safeReqBody.isNullOrBlank() || !safeRespBody.isNullOrBlank(),
            isTlsMetadataOnly = isTlsMetadataOnly,
            isSslProxied = isSslProxied,
            isPending = isPending,
            isFailed = isFailed,
            errorMessage = errorMessage,
            limitationNote = limitationNote,
            category = category.name,
            redactedCount = totalRedactions,
            timingBreakdown = timingBreakdown
        )

        scope.launch {
            if (isUpdate) {
                repository.updateTraffic(record, addedUpBytes, addedDownBytes)
            } else {
                repository.recordTraffic(record, isNewConnection)
            }
        }

        _status.update { st ->
            st.copy(
                totalRequests = if (isUpdate) st.totalRequests else st.totalRequests + 1,
                totalConnections = if (isNewConnection && !isUpdate) st.totalConnections + 1 else st.totalConnections,
                uploadedBytes = st.uploadedBytes + addedUpBytes,
                downloadedBytes = st.downloadedBytes + addedDownBytes,
                activeDomains = (st.activeDomains + cleanDomain).take(200).toSet(),
                lastCapturedRequestSummary = "${record.method} ${record.domain}${record.path.take(40)}",
                lastCapturedTimestamp = System.currentTimeMillis()
            )
        }
        return requestId to seq
    }
}
