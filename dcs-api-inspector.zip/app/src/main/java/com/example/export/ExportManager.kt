package com.example.export

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.data.db.TrafficRecordEntity
import com.example.privacy.PrivacyRedactionEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class ExportFormat(val extension: String, val mimeType: String, val label: String) {
    JSON("json", "application/json", "JSON"),
    TXT("txt", "text/plain", "TXT"),
    CSV("csv", "text/csv", "CSV")
}

enum class ExportScope(val label: String) {
    SELECTED_REQUEST("Selected Request"),
    SELECTED_DOMAIN("Selected Domain"),
    CURRENT_FILTER("Current Filter Results"),
    ENTIRE_SESSION("Entire Session")
}

class ExportManager(private val context: Context) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .build()

    fun generateExportContent(records: List<TrafficRecordEntity>, format: ExportFormat): String {
        return when (format) {
            ExportFormat.JSON -> toRedactedJson(records)
            ExportFormat.TXT -> toRedactedTxt(records)
            ExportFormat.CSV -> toRedactedCsv(records)
        }
    }

    fun toRedactedJson(records: List<TrafficRecordEntity>): String {
        val root = JSONObject()
        root.put("exporter", "DCS API Inspector — Dark Cyber Security")
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))
        root.put("recordCount", records.size)
        root.put("privacyGuarantee", "Sensitive credentials, OTPs, tokens, and session cookies automatically redacted.")

        val arr = JSONArray()
        records.forEach { rec ->
            val obj = JSONObject()
            obj.put("requestId", rec.requestId)
            obj.put("sequenceNumber", rec.sequenceNumber)
            obj.put("timestamp", rec.timestamp)
            obj.put("method", rec.method)
            obj.put("protocol", rec.protocol)
            obj.put("httpVersion", rec.httpVersion)
            obj.put("url", PrivacyRedactionEngine.redactUrl(rec.url).first)
            obj.put("domain", rec.domain)
            obj.put("host", rec.host)
            obj.put("statusCode", rec.statusCode)
            obj.put("statusMessage", rec.statusMessage)
            obj.put("appName", rec.appName)
            obj.put("packageName", rec.packageName ?: JSONObject.NULL)
            obj.put("durationMs", rec.durationMs)
            obj.put("timing", rec.timingBreakdown)
            obj.put("requestSize", rec.requestSize)
            obj.put("responseSize", rec.responseSize)
            obj.put("connectionType", rec.connectionType)
            obj.put("isTlsMetadataOnly", rec.isTlsMetadataOnly)
            obj.put("requestHeaders", safeJsonObject(rec.requestHeadersJson))
            obj.put("responseHeaders", safeJsonObject(rec.responseHeadersJson))
            obj.put("requestBody", PrivacyRedactionEngine.redactBody(rec.requestBody, rec.contentType).first ?: JSONObject.NULL)
            obj.put("responseBody", PrivacyRedactionEngine.redactBody(rec.responseBody, rec.contentType).first ?: JSONObject.NULL)
            if (!rec.errorMessage.isNullOrBlank()) {
                obj.put("error", rec.errorMessage)
            }
            arr.put(obj)
        }
        root.put("records", arr)
        return root.toString(2)
    }

    fun toRedactedTxt(records: List<TrafficRecordEntity>): String {
        val sb = StringBuilder()
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
        sb.appendLine("============================================================")
        sb.appendLine("DCS API INSPECTOR — DARK CYBER SECURITY (ALIF ISLAM)")
        sb.appendLine("Exported: ${fmt.format(Date())} | Records: ${records.size}")
        sb.appendLine("Privacy: Passwords, OTPs, tokens & cookies redacted.")
        sb.appendLine("============================================================")
        sb.appendLine()

        records.forEach { rec ->
            sb.appendLine("[#${rec.sequenceNumber}] ${rec.method} ${PrivacyRedactionEngine.redactUrl(rec.url).first}")
            sb.appendLine("Status: ${rec.statusCode} ${rec.statusMessage} | App: ${rec.appName} (${rec.packageName ?: "n/a"})")
            sb.appendLine("Time: ${fmt.format(Date(rec.timestamp))} | Duration: ${rec.durationMs}ms | Size: Up ${rec.requestSize}B / Down ${rec.responseSize}B")
            sb.appendLine("Remote: ${rec.remoteAddress}:${rec.remotePort} via ${rec.connectionType}")
            sb.appendLine("Request Headers: ${rec.requestHeadersJson}")
            sb.appendLine("Response Headers: ${rec.responseHeadersJson}")
            val safeReqBody = PrivacyRedactionEngine.redactBody(rec.requestBody, rec.contentType).first
            val safeRespBody = PrivacyRedactionEngine.redactBody(rec.responseBody, rec.contentType).first
            if (!safeReqBody.isNullOrBlank()) {
                sb.appendLine("Request Body:\n$safeReqBody")
            }
            if (!safeRespBody.isNullOrBlank()) {
                sb.appendLine("Response Body:\n$safeRespBody")
            }
            if (!rec.limitationNote.isNullOrBlank()) {
                sb.appendLine("Note: ${rec.limitationNote}")
            }
            sb.appendLine("------------------------------------------------------------")
        }
        return sb.toString()
    }

    fun toRedactedCsv(records: List<TrafficRecordEntity>): String {
        val sb = StringBuilder()
        sb.appendLine("Seq,Timestamp,Method,Protocol,Status,Domain,URL,App,DurationMs,RequestBytes,ResponseBytes,ConnectionType,TlsMetadataOnly,RedactedFields")
        records.forEach { rec ->
            val safeUrl = PrivacyRedactionEngine.redactUrl(rec.url).first
            val row = listOf(
                rec.sequenceNumber.toString(),
                rec.timestamp.toString(),
                csvEscape(rec.method),
                csvEscape(rec.protocol),
                rec.statusCode.toString(),
                csvEscape(rec.domain),
                csvEscape(safeUrl),
                csvEscape(rec.appName),
                rec.durationMs.toString(),
                rec.requestSize.toString(),
                rec.responseSize.toString(),
                csvEscape(rec.connectionType),
                rec.isTlsMetadataOnly.toString(),
                rec.redactedCount.toString()
            ).joinToString(",")
            sb.appendLine(row)
        }
        return sb.toString()
    }

    fun shareExportFile(records: List<TrafficRecordEntity>, format: ExportFormat, fileNamePrefix: String = "dcs_traffic"): Result<Unit> {
        return runCatching {
            val content = generateExportContent(records, format)
            val dir = File(context.cacheDir, "exports").apply { mkdirs() }
            val file = File(dir, "${fileNamePrefix}_${System.currentTimeMillis()}.${format.extension}")
            file.writeText(content)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = format.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "DCS API Inspector Traffic Export (${records.size} entries)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Share Redacted Traffic Report").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }
    }

    fun shareCertificateFile(pemContent: String): Result<Unit> {
        return runCatching {
            val dir = File(context.cacheDir, "exports").apply { mkdirs() }
            val file = File(dir, "dcs_inspector_root_ca.crt")
            file.writeText(pemContent)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/x-x509-ca-cert"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "DCS API Inspector Local Test CA Certificate")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Export Test CA Certificate").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        }
    }

    suspend fun testSecondaryProxyConnection(host: String, port: Int): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val start = System.currentTimeMillis()
            Socket().use { sock ->
                sock.connect(InetSocketAddress(host.trim(), port), 4500)
            }
            System.currentTimeMillis() - start
        }
    }

    suspend fun testReportServerConnection(serverUrl: String): Result<Pair<Int, Long>> = withContext(Dispatchers.IO) {
        runCatching {
            val trimmed = serverUrl.trim()
            require(trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
                "Server URL must start with http:// or https://"
            }
            val start = System.currentTimeMillis()
            val req = Request.Builder().url(trimmed).head().build()
            httpClient.newCall(req).execute().use { resp ->
                resp.code to (System.currentTimeMillis() - start)
            }
        }
    }

    suspend fun uploadReportToServer(serverUrl: String, records: List<TrafficRecordEntity>): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val trimmed = serverUrl.trim()
            require(trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
                "Server URL must start with http:// or https://"
            }
            val jsonPayload = toRedactedJson(records)
            val body = jsonPayload.toRequestBody("application/json; charset=utf-8".toMediaType())
            val req = Request.Builder()
                .url(trimmed)
                .post(body)
                .header("X-DCS-Exporter", "DCS-API-Inspector")
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("HTTP ${resp.code}: ${resp.message}")
                }
                resp.code
            }
        }
    }

    private fun safeJsonObject(rawJson: String): JSONObject {
        return runCatching { JSONObject(rawJson) }.getOrElse { JSONObject() }
    }

    private fun csvEscape(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }
}
