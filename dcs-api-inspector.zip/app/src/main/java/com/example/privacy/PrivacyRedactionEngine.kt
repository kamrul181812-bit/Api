package com.example.privacy

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Enforces strict automatic redaction of sensitive authentication data before persistence,
 * UI rendering, search indexing, sharing, exporting, or report server upload.
 */
object PrivacyRedactionEngine {

    const val REDACTED_VALUE = "[REDACTED]"

    private val prettyJson = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    private val sensitiveHeaderNames = setOf(
        "authorization",
        "proxy-authorization",
        "cookie",
        "set-cookie",
        "set-cookie2",
        "x-api-key",
        "x-auth-token",
        "x-access-token",
        "x-refresh-token",
        "x-session-id",
        "x-session-token",
        "x-csrf-token",
        "x-xsrf-token",
        "x-secret-key",
        "api-key",
        "apikey"
    )

    private val sensitiveKeyTokens = listOf(
        "otp",
        "code",
        "verification_code",
        "pin",
        "password",
        "passwd",
        "passcode",
        "secret",
        "token",
        "access_token",
        "refresh_token",
        "id_token",
        "auth",
        "authorization",
        "cookie",
        "session",
        "api_key",
        "apikey",
        "private_key",
        "client_secret",
        "jwt",
        "bearer",
        "phone",
        "mobile",
        "ssn",
        "cvv",
        "card_number"
    )

    private val safeStructuralKeys = setOf(
        "status",
        "purpose",
        "type",
        "mode",
        "method",
        "expires_in",
        "message",
        "error",
        "error_code",
        "success",
        "verified",
        "timestamp",
        "code_length",
        "retry_after"
    )

    private val bearerRegex = Regex("""(?i)(Bearer|Basic|Token)\s+[A-Za-z0-9\-._~+/]+=*""")
    private val jwtRegex = Regex("""eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+""")
    private val inlineOtpRegex = Regex("""(?i)\b(otp|pin|passcode|verification_code|code)\s*[:=]\s*["']?\d{4,8}["']?""")

    fun isSensitiveKey(key: String): Boolean {
        val normalized = key.trim().lowercase()
        if (normalized in safeStructuralKeys) return false
        return sensitiveKeyTokens.any { token ->
            normalized == token ||
                normalized.endsWith("_$token") ||
                normalized.startsWith("${token}_") ||
                normalized.contains(token)
        }
    }

    fun redactUrl(rawUrl: String): Pair<String, Int> {
        val qIndex = rawUrl.indexOf('?')
        if (qIndex == -1 || qIndex == rawUrl.lastIndex) return rawUrl to 0
        val base = rawUrl.substring(0, qIndex)
        val query = rawUrl.substring(qIndex + 1)
        var count = 0
        val redactedQuery = query.split("&").joinToString("&") { part ->
            val eqIdx = part.indexOf('=')
            if (eqIdx > 0) {
                val k = part.substring(0, eqIdx)
                if (isSensitiveKey(k)) {
                    count++
                    "$k=$REDACTED_VALUE"
                } else {
                    part
                }
            } else {
                part
            }
        }
        return "$base?$redactedQuery" to count
    }

    fun redactHeaders(headers: Map<String, String>): Pair<Map<String, String>, Int> {
        var count = 0
        val result = linkedMapOf<String, String>()
        headers.forEach { (key, value) ->
            val lower = key.trim().lowercase()
            if (lower in sensitiveHeaderNames || isSensitiveKey(lower)) {
                count++
                result[key] = if (lower == "cookie" || lower == "set-cookie") {
                    redactCookieHeaderValue(value)
                } else {
                    REDACTED_VALUE
                }
            } else {
                result[key] = redactInlineSecrets(value).first
            }
        }
        return result to count
    }

    private fun redactCookieHeaderValue(raw: String): String {
        val parts = raw.split(";").map { it.trim() }
        if (parts.isEmpty()) return REDACTED_VALUE
        val first = parts.first()
        val eq = first.indexOf('=')
        val redactedFirst = if (eq > 0) "${first.substring(0, eq)}=$REDACTED_VALUE" else REDACTED_VALUE
        val safeAttributes = parts.drop(1).filter { attr ->
            val name = attr.substringBefore('=').trim().lowercase()
            name in setOf("path", "domain", "max-age", "expires", "secure", "httponly", "samesite")
        }
        return (listOf(redactedFirst) + safeAttributes).joinToString("; ")
    }

    fun redactBody(body: String?, contentType: String?): Pair<String?, Int> {
        if (body.isNullOrBlank()) return body to 0
        val trimmed = body.trim()
        val ct = contentType?.lowercase().orEmpty()

        if (ct.contains("json") || trimmed.startsWith("{") || trimmed.startsWith("[")) {
            val jsonResult = tryRedactJson(trimmed)
            if (jsonResult != null) return jsonResult
        }

        if (ct.contains("x-www-form-urlencoded") || (trimmed.contains("=") && !trimmed.contains("<") && !trimmed.contains("\n"))) {
            return redactFormUrlEncoded(trimmed)
        }

        val (inlineRedacted, count) = redactInlineSecrets(body)
        return inlineRedacted to count
    }

    private fun tryRedactJson(rawJson: String): Pair<String, Int>? {
        return try {
            val rootElement = prettyJson.parseToJsonElement(rawJson)
            var count = 0

            fun redactElement(element: JsonElement, forceRedact: Boolean): JsonElement {
                return when (element) {
                    is JsonObject -> {
                        val map = linkedMapOf<String, JsonElement>()
                        element.forEach { (k, v) ->
                            val sensitive = forceRedact || isSensitiveKey(k)
                            when (v) {
                                is JsonObject -> map[k] = redactElement(v, false)
                                is JsonArray -> map[k] = redactElement(v, sensitive)
                                is JsonNull -> map[k] = JsonNull
                                is JsonPrimitive -> {
                                    if (sensitive) {
                                        count++
                                        map[k] = JsonPrimitive(REDACTED_VALUE)
                                    } else if (v.isString) {
                                        val (masked, c) = redactInlineSecrets(v.content)
                                        count += c
                                        map[k] = JsonPrimitive(masked)
                                    } else {
                                        map[k] = v
                                    }
                                }
                            }
                        }
                        JsonObject(map)
                    }
                    is JsonArray -> {
                        JsonArray(element.map { item -> redactElement(item, forceRedact) })
                    }
                    is JsonPrimitive -> {
                        if (forceRedact) {
                            count++
                            JsonPrimitive(REDACTED_VALUE)
                        } else if (element.isString) {
                            val (masked, c) = redactInlineSecrets(element.content)
                            count += c
                            JsonPrimitive(masked)
                        } else {
                            element
                        }
                    }
                }
            }

            val redactedRoot = redactElement(rootElement, false)
            val formatted = prettyJson.encodeToString(JsonElement.serializer(), redactedRoot)
            formatted to count
        } catch (_: Exception) {
            null
        }
    }

    private fun redactFormUrlEncoded(raw: String): Pair<String, Int> {
        var count = 0
        val out = raw.split("&").joinToString("&") { pair ->
            val idx = pair.indexOf('=')
            if (idx > 0) {
                val key = pair.substring(0, idx)
                if (isSensitiveKey(key)) {
                    count++
                    "$key=$REDACTED_VALUE"
                } else {
                    pair
                }
            } else {
                pair
            }
        }
        return out to count
    }

    fun redactInlineSecrets(text: String): Pair<String, Int> {
        var count = 0
        var current = bearerRegex.replace(text) { match ->
            count++
            "${match.groupValues[1]} $REDACTED_VALUE"
        }
        current = jwtRegex.replace(current) {
            count++
            REDACTED_VALUE
        }
        current = inlineOtpRegex.replace(current) { match ->
            count++
            "${match.groupValues[1]}=$REDACTED_VALUE"
        }
        return current to count
    }
}
