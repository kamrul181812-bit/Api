package com.example.proxy

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.DcsInspectorApp
import com.example.MainActivity
import com.example.R
import com.example.browser.AppAttribution
import com.example.capture.HttpParser
import com.example.capture.LocalCaManager
import com.example.data.settings.InspectorSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Loopback-only (127.0.0.1) HTTP & CONNECT debugging proxy server.
 * Never binds to 0.0.0.0 or alters system-wide proxy settings silently.
 */
class LocalProxyService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopProxy()
            return START_NOT_STICKY
        }

        val port = intent?.getIntExtra(EXTRA_PORT, 9000)?.coerceIn(1024, 65535) ?: 9000
        startForeground(NOTIFICATION_ID, buildNotification("Listening on 127.0.0.1:$port"))
        startProxy(port)
        return START_STICKY
    }

    private fun startProxy(port: Int) {
        acceptJob?.cancel()
        runCatching { serverSocket?.close() }
        val app = DcsInspectorApp.instance

        acceptJob = scope.launch {
            val settings = app.settingsManager.settingsFlow.first()
            app.captureEngine.ensureActiveSession("LOCAL_PROXY", settings)
            try {
                // Strictly bind to loopback 127.0.0.1 so external network cannot reach it
                val srv = ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"))
                serverSocket = srv
                app.captureEngine.setLocalProxyState(true, "Listening 127.0.0.1:$port")

                while (isActive && !srv.isClosed) {
                    val client = srv.accept()
                    launch { handleClient(client) }
                }
            } catch (e: Exception) {
                app.captureEngine.setLocalProxyState(false, "Error: ${e.message ?: "Port in use"}")
                stopSelf()
            }
        }
    }

    private suspend fun handleClient(client: Socket) {
        val app = DcsInspectorApp.instance
        val engine = app.captureEngine
        val settings = app.settingsManager.settingsFlow.first()
        val startedAt = System.currentTimeMillis()
        var upstream: Socket? = null

        try {
            client.soTimeout = 20_000
            val clientIn = client.getInputStream()
            val clientOut = client.getOutputStream()

            val initialBytes = readUntilHeadersEnd(clientIn)
            if (initialBytes.isEmpty()) return

            val req = HttpParser.parseHttpRequest(initialBytes, defaultHost = "127.0.0.1") ?: return

            if (req.method == "CONNECT") {
                val targetHost = req.rawTarget.substringBefore(':')
                val targetPort = req.rawTarget.substringAfter(':', "443").toIntOrNull() ?: 443
                val isAllowlisted = settings.sslProxyingEnabled &&
                    settings.sslAllowlistDomains.any { targetHost.equals(it, true) || targetHost.endsWith(".$it", true) }

                upstream = connectUpstream(targetHost, targetPort, settings)
                clientOut.write("HTTP/1.1 200 Connection Established\r\nProxy-Agent: DCS-API-Inspector\r\n\r\n".toByteArray(Charsets.US_ASCII))
                clientOut.flush()

                if (isAllowlisted && targetPort == 443) {
                    handleAuthorizedSslMitm(client, upstream, targetHost, targetPort, startedAt, settings)
                } else {
                    val (upBytes, downBytes) = tunnelRawBidirectional(client, upstream)
                    val duration = System.currentTimeMillis() - startedAt
                    engine.recordCapturedFlow(
                        timestamp = startedAt,
                        responseTimestamp = System.currentTimeMillis(),
                        durationMs = duration,
                        method = "CONNECT",
                        protocol = "HTTPS",
                        httpVersion = "TLS Tunnel",
                        rawUrl = "https://$targetHost:$targetPort",
                        host = targetHost,
                        path = "/[tls-tunnel]",
                        statusCode = 200,
                        statusMessage = "Tunnel Established",
                        remoteAddress = upstream.inetAddress?.hostAddress ?: targetHost,
                        remotePort = targetPort,
                        localPort = client.port,
                        connectionType = "Local Proxy",
                        attribution = AppAttribution(null, "Local Proxy Client", false),
                        requestSize = upBytes,
                        responseSize = downBytes,
                        isTlsMetadataOnly = true,
                        limitationNote = if (settings.sslProxyingEnabled) {
                            "'$targetHost' is not in your testing-domain allowlist. Passed through encrypted."
                        } else {
                            "SSL Proxying disabled. HTTPS tunnel passed through encrypted (metadata-only)."
                        },
                        timingBreakdown = "Total: ${duration}ms"
                    )
                }
            } else {
                // Plaintext HTTP proxy request
                val hostParts = req.host.split(":")
                val targetHost = hostParts[0]
                val targetPort = hostParts.getOrNull(1)?.toIntOrNull() ?: 80

                upstream = connectUpstream(targetHost, targetPort, settings)
                upstream.getOutputStream().write(initialBytes)
                upstream.getOutputStream().flush()

                val respBuf = ByteArrayOutputStream()
                val tmp = ByteArray(8192)
                val upIn = upstream.getInputStream()
                while (true) {
                    val n = upIn.read(tmp)
                    if (n < 0) break
                    clientOut.write(tmp, 0, n)
                    clientOut.flush()
                    if (respBuf.size() < 262_144) {
                        respBuf.write(tmp, 0, n)
                    }
                }

                val respBytes = respBuf.toByteArray()
                val parsedResp = HttpParser.parseHttpResponse(respBytes)
                val duration = System.currentTimeMillis() - startedAt
                val fullUrl = if (req.rawTarget.startsWith("http")) req.rawTarget else "http://${req.host}${req.rawTarget}"

                engine.recordCapturedFlow(
                    timestamp = startedAt,
                    responseTimestamp = System.currentTimeMillis(),
                    durationMs = duration,
                    method = req.method,
                    protocol = "HTTP",
                    httpVersion = req.httpVersion,
                    rawUrl = fullUrl,
                    host = req.host,
                    path = req.path,
                    queryParams = req.queryParams,
                    statusCode = parsedResp?.statusCode ?: 0,
                    statusMessage = parsedResp?.statusMessage.orEmpty(),
                    remoteAddress = upstream.inetAddress?.hostAddress ?: targetHost,
                    remotePort = targetPort,
                    localPort = client.port,
                    connectionType = "Local Proxy",
                    attribution = AppAttribution(null, "Local Proxy Client", false),
                    requestSize = initialBytes.size.toLong(),
                    responseSize = respBytes.size.toLong(),
                    contentType = parsedResp?.contentType ?: req.contentType,
                    requestHeaders = req.headers,
                    responseHeaders = parsedResp?.headers ?: emptyMap(),
                    rawRequestBody = req.bodyText,
                    rawResponseBody = parsedResp?.bodyText,
                    rawRequestInfo = req.rawHeaderBlock,
                    rawResponseInfo = parsedResp?.rawHeaderBlock.orEmpty(),
                    timingBreakdown = "Total: ${duration}ms"
                )
            }
        } catch (e: Exception) {
            engine.recordCapturedFlow(
                timestamp = startedAt,
                durationMs = System.currentTimeMillis() - startedAt,
                method = "PROXY",
                protocol = "HTTP",
                httpVersion = "HTTP/1.1",
                rawUrl = "http://127.0.0.1",
                host = "127.0.0.1",
                path = "/",
                statusCode = 502,
                statusMessage = "Proxy Error",
                remoteAddress = "127.0.0.1",
                remotePort = 0,
                connectionType = "Local Proxy",
                attribution = AppAttribution(null, "Local Proxy Client", false),
                requestSize = 0L,
                responseSize = 0L,
                isFailed = true,
                errorMessage = e.message ?: "Proxy connection failed"
            )
        } finally {
            runCatching { upstream?.close() }
            runCatching { client.close() }
        }
    }

    private fun handleAuthorizedSslMitm(
        rawClient: Socket,
        rawUpstream: Socket,
        targetHost: String,
        targetPort: Int,
        startedAt: Long,
        settings: InspectorSettings
    ) {
        val engine = DcsInspectorApp.instance.captureEngine
        try {
            val sslCtx = LocalCaManager.buildLeafSslContextForDomain(this, targetHost)
            val clientSsl = sslCtx.socketFactory.createSocket(rawClient, targetHost, targetPort, true) as SSLSocket
            clientSsl.useClientMode = false
            clientSsl.startHandshake()

            val upstreamSsl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                .createSocket(rawUpstream, targetHost, targetPort, true) as SSLSocket
            upstreamSsl.startHandshake()

            val reqBytes = readUntilHeadersEnd(clientSsl.inputStream)
            val req = HttpParser.parseHttpRequest(reqBytes, defaultHost = targetHost, scheme = "https")
            upstreamSsl.outputStream.write(reqBytes)
            upstreamSsl.outputStream.flush()

            val respBuf = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            while (true) {
                val n = upstreamSsl.inputStream.read(buf)
                if (n < 0) break
                clientSsl.outputStream.write(buf, 0, n)
                clientSsl.outputStream.flush()
                if (respBuf.size() < 262_144) respBuf.write(buf, 0, n)
            }
            val respBytes = respBuf.toByteArray()
            val resp = HttpParser.parseHttpResponse(respBytes)
            val duration = System.currentTimeMillis() - startedAt

            if (req != null) {
                engine.recordCapturedFlow(
                    timestamp = startedAt,
                    responseTimestamp = System.currentTimeMillis(),
                    durationMs = duration,
                    method = req.method,
                    protocol = "HTTPS",
                    httpVersion = req.httpVersion,
                    rawUrl = "https://$targetHost${req.rawTarget}",
                    host = targetHost,
                    path = req.path,
                    queryParams = req.queryParams,
                    statusCode = resp?.statusCode ?: 0,
                    statusMessage = resp?.statusMessage.orEmpty(),
                    remoteAddress = rawUpstream.inetAddress?.hostAddress ?: targetHost,
                    remotePort = targetPort,
                    connectionType = "Local Proxy (SSL Allowlisted)",
                    attribution = AppAttribution(null, "Authorized Test Client", false),
                    requestSize = reqBytes.size.toLong(),
                    responseSize = respBytes.size.toLong(),
                    contentType = resp?.contentType ?: req.contentType,
                    requestHeaders = req.headers,
                    responseHeaders = resp?.headers ?: emptyMap(),
                    rawRequestBody = req.bodyText,
                    rawResponseBody = resp?.bodyText,
                    rawRequestInfo = req.rawHeaderBlock,
                    rawResponseInfo = resp?.rawHeaderBlock.orEmpty(),
                    isSslProxied = true,
                    timingBreakdown = "Total: ${duration}ms"
                )
            }
            runCatching { clientSsl.close() }
            runCatching { upstreamSsl.close() }
        } catch (e: SSLHandshakeException) {
            // Client rejected user CA due to certificate pinning or Network Security Config
            val duration = System.currentTimeMillis() - startedAt
            engine.recordCapturedFlow(
                timestamp = startedAt,
                durationMs = duration,
                method = "CONNECT",
                protocol = "HTTPS",
                httpVersion = "TLS Rejected",
                rawUrl = "https://$targetHost:$targetPort",
                host = targetHost,
                path = "/[tls-pinning-or-nsc]",
                statusCode = 0,
                statusMessage = "TLS Handshake Rejected",
                remoteAddress = rawUpstream.inetAddress?.hostAddress ?: targetHost,
                remotePort = targetPort,
                connectionType = "Local Proxy",
                attribution = AppAttribution(null, "TLS Client", false),
                requestSize = 0L,
                responseSize = 0L,
                isTlsMetadataOnly = true,
                isFailed = true,
                errorMessage = "Client rejected DCS Test CA (certificate pinning or Network Security Config): ${e.message}",
                limitationNote = "Android enforces certificate pinning and app Network Security Config. Payload remains protected."
            )
        }
    }

    private fun connectUpstream(host: String, port: Int, settings: InspectorSettings): Socket {
        return if (settings.secondaryProxyEnabled && settings.secondaryProxyHost.isNotBlank()) {
            Socket().apply {
                connect(InetSocketAddress(settings.secondaryProxyHost, settings.secondaryProxyPort), 8000)
                val connectCmd = "CONNECT $host:$port HTTP/1.1\r\nHost: $host:$port\r\n\r\n"
                getOutputStream().write(connectCmd.toByteArray(Charsets.US_ASCII))
                getOutputStream().flush()
                val line = getInputStream().bufferedReader().readLine().orEmpty()
                if (!line.contains("200")) {
                    close()
                    throw IllegalStateException("Secondary proxy error: $line")
                }
            }
        } else {
            Socket().apply {
                connect(InetSocketAddress(host, port), 8000)
            }
        }
    }

    private fun tunnelRawBidirectional(a: Socket, b: Socket): Pair<Long, Long> {
        var up = 0L
        var down = 0L
        val t1 = Thread {
            runCatching {
                val buf = ByteArray(8192)
                val ins = a.getInputStream()
                val outs = b.getOutputStream()
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    up += n
                    outs.write(buf, 0, n)
                    outs.flush()
                }
            }
            runCatching { b.shutdownOutput() }
        }
        val t2 = Thread {
            runCatching {
                val buf = ByteArray(8192)
                val ins = b.getInputStream()
                val outs = a.getOutputStream()
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    down += n
                    outs.write(buf, 0, n)
                    outs.flush()
                }
            }
            runCatching { a.shutdownOutput() }
        }
        t1.start()
        t2.start()
        t1.join()
        t2.join()
        return up to down
    }

    private fun readUntilHeadersEnd(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(1024)
        while (out.size() < 65_536) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            val arr = out.toByteArray()
            if (arr.size >= 4) {
                val str = String(arr, Charsets.ISO_8859_1)
                if (str.contains("\r\n\r\n")) break
            }
            if (n < buf.size) break
        }
        return out.toByteArray()
    }

    private fun stopProxy() {
        acceptJob?.cancel()
        runCatching { serverSocket?.close() }
        serverSocket = null
        DcsInspectorApp.instance.captureEngine.setLocalProxyState(false, "Stopped")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        acceptJob?.cancel()
        runCatching { serverSocket?.close() }
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            2,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, LocalProxyService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, DcsInspectorApp.CHANNEL_PROXY)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("DCS API Inspector • Local Proxy")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 4102
        const val EXTRA_PORT = "proxy_port"
        const val ACTION_START = "com.example.proxy.START"
        const val ACTION_STOP = "com.example.proxy.STOP"

        fun start(context: Context, port: Int) {
            val intent = Intent(context, LocalProxyService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PORT, port)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, LocalProxyService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }
}
