package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.capture.CaptureEngineStatus
import com.example.data.settings.InspectorSettings
import com.example.ui.components.formatBytes
import com.example.ui.components.formatDurationSeconds
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsRedirect
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsSurfaceElevated
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.LivePulseDot
import com.example.ui.theme.StatusPill

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    status: CaptureEngineStatus,
    settings: InspectorSettings,
    elapsedSeconds: Long,
    onOpenMenu: () -> Unit,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit,
    onPauseMonitoring: () -> Unit,
    onResumeMonitoring: () -> Unit,
    onRestartMonitoring: () -> Unit,
    onClearSession: () -> Unit,
    onOpenTraffic: () -> Unit,
    onOpenBrowsers: () -> Unit,
    onLaunchBrowser: () -> Unit,
    onOpenVpnDetails: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "DCS API INSPECTOR",
                        style = MaterialTheme.typography.titleLarge,
                        color = DcsTextPrimary
                    )
                    Text(
                        text = "DARK CYBER SECURITY • BY ALIF ISLAM",
                        style = MaterialTheme.typography.labelSmall,
                        color = DcsCyan
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier.testTag("dashboard_menu_button")
                ) {
                    Icon(Icons.Default.Menu, contentDescription = "Open Traffic Management Menu", tint = DcsCyan)
                }
            },
            actions = {
                LivePulseDot(isActive = status.isMonitoring, isPaused = status.isPaused)
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("dashboard_settings_button")
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = DcsTextSilver)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Capture Engine Card
            item {
                GlassCard(
                    glowAccent = if (status.isMonitoring) DcsEmerald else DcsCyan,
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_dcs_hero_banner),
                            contentDescription = "Network telemetry backdrop",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .matchParentSize()
                                .alpha(0.24f)
                        )
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.VpnLock,
                                        contentDescription = "VPN Engine",
                                        tint = if (status.isMonitoring) DcsEmerald else DcsCyan,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = settings.recordMode.label,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = DcsTextPrimary
                                    )
                                }
                                StatusPill(
                                    text = formatDurationSeconds(elapsedSeconds),
                                    color = if (status.isMonitoring) DcsEmerald else DcsTextMuted
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Status: ${status.networkStatus} | Proxy: ${status.localProxyStatus}",
                                style = MaterialTheme.typography.bodySmall,
                                color = DcsTextSilver
                            )

                            if (!status.vpnConflictMessage.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                StatusPill(text = status.vpnConflictMessage, color = DcsServerError)
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (!status.isMonitoring) {
                                    Button(
                                        onClick = onStartMonitoring,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = DcsCyan,
                                            contentColor = DcsVoidBg
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("start_monitoring_button")
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Start Monitoring", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Button(
                                        onClick = onStopMonitoring,
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = DcsServerError,
                                            contentColor = DcsTextPrimary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("stop_monitoring_button")
                                    ) {
                                        Icon(Icons.Default.Stop, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Stop", fontWeight = FontWeight.Bold)
                                    }

                                    FilledTonalButton(
                                        onClick = if (status.isPaused) onResumeMonitoring else onPauseMonitoring,
                                        modifier = Modifier.testTag("pause_resume_button")
                                    ) {
                                        Icon(
                                            if (status.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                            contentDescription = if (status.isPaused) "Resume" else "Pause"
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (status.isPaused) "Resume" else "Pause")
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onRestartMonitoring,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("restart_session_button")
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Restart")
                                }
                                OutlinedButton(
                                    onClick = onClearSession,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("clear_session_button")
                                ) {
                                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Clear")
                                }
                                OutlinedButton(
                                    onClick = onOpenVpnDetails,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("vpn_console_button")
                                ) {
                                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Console")
                                }
                            }
                        }
                    }
                }
            }

            // Live Telemetry Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        title = "Requests",
                        value = status.totalRequests.toString(),
                        accent = DcsCyan,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTraffic
                    )
                    MetricTile(
                        title = "Connections",
                        value = status.totalConnections.toString(),
                        accent = DcsEmerald,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTraffic
                    )
                    MetricTile(
                        title = "Domains",
                        value = status.activeDomains.size.toString(),
                        accent = DcsRedirect,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTraffic
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricTile(
                        title = "Uploaded",
                        value = formatBytes(status.uploadedBytes),
                        accent = DcsCyan,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTraffic
                    )
                    MetricTile(
                        title = "Downloaded",
                        value = formatBytes(status.downloadedBytes),
                        accent = DcsEmerald,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenTraffic
                    )
                }
            }

            // Last Captured Request Card
            item {
                GlassCard(onClick = onOpenTraffic) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SwapVert, contentDescription = null, tint = DcsCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Last Captured Request", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                        }
                        Text("View All →", style = MaterialTheme.typography.labelMedium, color = DcsCyan)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = status.lastCapturedRequestSummary ?: "No live traffic captured in current session yet.",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (status.lastCapturedRequestSummary != null) DcsEmerald else DcsTextMuted,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Selected Browser Quick Launch
            item {
                GlassCard(glowAccent = DcsCyan.copy(alpha = 0.5f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = DcsCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Target Browser",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = DcsTextMuted
                                )
                                Text(
                                    text = settings.selectedBrowserName ?: "None selected (All apps)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = DcsTextPrimary
                                )
                            }
                        }
                        OutlinedButton(onClick = onOpenBrowsers) {
                            Text("Change")
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "URL: ${settings.browserLaunchUrl}",
                        style = MaterialTheme.typography.labelMedium,
                        color = DcsTextSilver,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onLaunchBrowser,
                        colors = ButtonDefaults.buttonColors(containerColor = DcsSurfaceElevated, contentColor = DcsEmerald),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dashboard_launch_browser_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Monitor & Open Target Browser")
                    }
                }
            }

            // Honest Privacy & HTTPS Capabilities Notice
            item {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = DcsEmerald)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Privacy & Capture Architecture", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Local on-device VPN TUN & loopback proxy — zero remote traffic forwarding.\n" +
                            "• Passwords, OTPs, cookies, and auth tokens are automatically redacted before storage.\n" +
                            "• Encrypted HTTPS traffic shows honest SNI/DNS/byte metadata unless explicitly configured in authorized test environments.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier,
        glowAccent = accent.copy(alpha = 0.4f),
        contentPadding = PaddingValues(12.dp),
        onClick = onClick
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = DcsTextMuted,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
