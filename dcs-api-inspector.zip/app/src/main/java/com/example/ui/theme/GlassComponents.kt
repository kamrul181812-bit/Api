package com.example.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glowAccent: Color? = null,
    cornerRadius: Dp = 16.dp,
    contentPadding: PaddingValues = PaddingValues(14.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val borderBrush = if (glowAccent != null) {
        Brush.linearGradient(
            listOf(glowAccent.copy(alpha = 0.45f), DcsGlassBorder.copy(alpha = 0.6f))
        )
    } else {
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.08f), DcsGlassBorder.copy(alpha = 0.55f))
        )
    }

    val containerBrush = Brush.verticalGradient(
        listOf(
            DcsSurfaceElevated.copy(alpha = 0.88f),
            DcsSurface.copy(alpha = 0.94f)
        )
    )

    if (onClick != null) {
        Surface(
            onClick = onClick,
            modifier = modifier
                .clip(shape)
                .border(BorderStroke(1.dp, borderBrush), shape),
            shape = shape,
            color = Color.Transparent
        ) {
            Column(
                modifier = Modifier
                    .background(containerBrush)
                    .padding(contentPadding),
                content = content
            )
        }
    } else {
        Box(
            modifier = modifier
                .clip(shape)
                .background(containerBrush)
                .border(BorderStroke(1.dp, borderBrush), shape)
        ) {
            Column(
                modifier = Modifier.padding(contentPadding),
                content = content
            )
        }
    }
}

@Composable
fun GlassBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier.background(
            Brush.radialGradient(
                colors = listOf(
                    Color(0xFF0E1B28),
                    DcsVoidBg,
                    Color(0xFF080B0F)
                )
            )
        ),
        content = content
    )
}

@Composable
fun StatusPill(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.38f))
    ) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun MethodPill(
    method: String,
    modifier: Modifier = Modifier
) {
    val color = methodColor(method)
    StatusPill(text = method.uppercase(), color = color, modifier = modifier)
}

@Composable
fun LivePulseDot(
    isActive: Boolean,
    isPaused: Boolean = false,
    modifier: Modifier = Modifier
) {
    val dotColor = when {
        isActive && !isPaused -> DcsEmerald
        isActive && isPaused -> DcsRedirect
        else -> DcsTextMuted
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = when {
                isActive && !isPaused -> "LIVE"
                isActive && isPaused -> "PAUSED"
                else -> "IDLE"
            },
            style = MaterialTheme.typography.labelMedium,
            color = dotColor
        )
    }
}

fun methodColor(method: String): Color = when (method.uppercase()) {
    "GET" -> DcsCyan
    "POST" -> DcsEmerald
    "PUT", "PATCH" -> DcsRedirect
    "DELETE" -> DcsServerError
    "HEAD", "OPTIONS" -> DcsTextSilver
    "CONNECT", "TLS" -> DcsTlsBadge
    "UDP", "DNS", "QUIC" -> Color(0xFF56CCF2)
    else -> DcsTextSilver
}

fun statusCodeColor(statusCode: Int, isFailed: Boolean): Color = when {
    isFailed || statusCode >= 500 -> DcsServerError
    statusCode in 400..499 -> DcsClientError
    statusCode in 300..399 -> DcsRedirect
    statusCode in 200..299 -> DcsSuccess
    statusCode == 0 -> DcsPending
    else -> DcsTextSilver
}
