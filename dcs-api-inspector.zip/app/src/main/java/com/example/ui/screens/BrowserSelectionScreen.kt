package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.browser.BrowserManager
import com.example.browser.InstalledBrowser
import com.example.capture.CaptureEngineStatus
import com.example.data.settings.InspectorSettings
import com.example.ui.components.AppIconBadge
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.StatusPill

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserSelectionScreen(
    browsers: List<InstalledBrowser>,
    settings: InspectorSettings,
    status: CaptureEngineStatus,
    browserManager: BrowserManager,
    onRefreshBrowsers: () -> Unit,
    onSelectBrowser: (InstalledBrowser) -> Unit,
    onStartMonitorAndLaunch: (String) -> Unit,
    onLaunchBrowserOnly: (String) -> Unit,
    onStopMonitoring: () -> Unit
) {
    var urlInput by remember(settings.browserLaunchUrl) { mutableStateOf(settings.browserLaunchUrl) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("Browser Selection", style = MaterialTheme.typography.titleLarge, color = DcsTextPrimary)
                    Text(
                        text = "${browsers.size} compatible browser(s) discovered",
                        style = MaterialTheme.typography.labelSmall,
                        color = DcsCyan
                    )
                }
            },
            actions = {
                IconButton(
                    onClick = onRefreshBrowsers,
                    modifier = Modifier.testTag("refresh_browsers_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh installed browsers", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Launch URL & Monitoring Session Box
            item {
                GlassCard(glowAccent = DcsCyan) {
                    Text("Active Browser Session", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Selected: ${settings.selectedBrowserName ?: "None"} (${settings.selectedBrowserPackage ?: "All apps"})",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("Target Website URL") },
                        placeholder = { Text("https://httpbin.org/get") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("browser_url_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onStartMonitorAndLaunch(urlInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("start_and_launch_browser_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Monitor & Open", fontWeight = FontWeight.Bold)
                        }
                        if (status.isMonitoring) {
                            OutlinedButton(
                                onClick = onStopMonitoring,
                                modifier = Modifier.testTag("browser_stop_monitoring_button")
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, tint = DcsServerError, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Stop", color = DcsServerError)
                            }
                        } else {
                            OutlinedButton(
                                onClick = { onLaunchBrowserOnly(urlInput) },
                                modifier = Modifier.testTag("launch_browser_only_button")
                            ) {
                                Icon(Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Launch")
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = DcsEmerald, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Browser Attribution & Routing", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Selecting a browser lets you launch URLs directly and filter/distinguish its traffic. To restrict VPN capture exclusively to this browser, enable 'Selected Apps Only' in Application Selection. Android's Network Security Config still protects third-party browser HTTPS payloads unless explicitly authorized.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }

            if (browsers.isEmpty()) {
                item {
                    GlassCard {
                        Text(
                            text = "No compatible browsers discovered on this device. Install Chrome, Firefox, Edge, Brave, Opera, or Samsung Internet and tap Refresh.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = DcsTextSilver
                        )
                    }
                }
            } else {
                items(browsers, key = { it.packageName }) { browser ->
                    val isSelected = browser.packageName == settings.selectedBrowserPackage
                    val icon = remember(browser.packageName) { browserManager.getAppIcon(browser.packageName) }

                    GlassCard(
                        glowAccent = if (isSelected) DcsEmerald else null,
                        onClick = { onSelectBrowser(browser) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("browser_item_${browser.packageName}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIconBadge(bitmap = icon, contentDescription = browser.appName, size = 40.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = browser.appName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = DcsTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (browser.isDefault) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        StatusPill(text = "Default", color = DcsCyan)
                                    }
                                }
                                Text(
                                    text = browser.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DcsTextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Installed • v${browser.versionName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DcsEmerald
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected browser",
                                    tint = DcsEmerald,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { onSelectBrowser(browser) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isSelected) "Selected" else "Select")
                            }
                            Button(
                                onClick = {
                                    onSelectBrowser(browser)
                                    onStartMonitorAndLaunch(urlInput)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DcsCyan.copy(alpha = 0.2f), contentColor = DcsCyan),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Monitor & Launch")
                            }
                        }
                    }
                }
            }
        }
    }
}
