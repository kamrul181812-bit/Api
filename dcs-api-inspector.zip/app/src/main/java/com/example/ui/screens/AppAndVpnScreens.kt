package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.browser.BrowserManager
import com.example.browser.InstalledAppInfo
import com.example.capture.CaptureEngineStatus
import com.example.data.settings.AppScopeMode
import com.example.data.settings.CaptureRecordMode
import com.example.data.settings.InspectorSettings
import com.example.ui.components.AppIconBadge
import com.example.ui.components.formatBytes
import com.example.ui.components.formatDurationSeconds
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsRedirect
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.StatusPill

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSelectionScreen(
    apps: List<InstalledAppInfo>,
    settings: InspectorSettings,
    browserManager: BrowserManager,
    onSetScopeMode: (AppScopeMode) -> Unit,
    onToggleApp: (String) -> Unit,
    onBack: () -> Unit
) {
    var search by remember { mutableStateOf("") }
    val filteredApps = remember(apps, search) {
        if (search.isBlank()) apps
        else apps.filter {
            it.appName.contains(search, true) || it.packageName.contains(search, true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Application Selection", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                GlassCard(glowAccent = DcsCyan) {
                    Text("VPN Monitoring Scope", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    AppScopeMode.entries.forEach { mode ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSetScopeMode(mode) }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(selected = settings.appScopeMode == mode, onClick = { onSetScopeMode(mode) })
                            Text(mode.label, color = DcsTextPrimary)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (settings.appScopeMode == AppScopeMode.SELECTED_APPS) {
                            "Selected Applications Only (${settings.selectedAppPackages.size} selected): VpnService uses addAllowedApplication() so only checked apps route through the VPN TUN. Note: Third-party apps still default to metadata-only HTTPS unless explicitly configured for authorized debugging."
                        } else {
                            "All Supported Applications: Captures traffic across device apps (excluding DCS API Inspector itself) with metadata-only protection for encrypted HTTPS."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text("Search installed applications...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            items(filteredApps, key = { it.packageName }) { app ->
                val checked = app.packageName in settings.selectedAppPackages
                val icon = remember(app.packageName) { browserManager.getAppIcon(app.packageName) }
                GlassCard(
                    onClick = { onToggleApp(app.packageName) },
                    contentPadding = PaddingValues(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppIconBadge(bitmap = icon, contentDescription = app.appName, size = 34.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = DcsTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (app.isBrowser) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusPill(text = "Browser", color = DcsCyan)
                                }
                            }
                            Text(
                                text = app.packageName,
                                style = MaterialTheme.typography.labelSmall,
                                color = DcsTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Checkbox(checked = checked, onCheckedChange = { onToggleApp(app.packageName) })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnMonitoringScreen(
    status: CaptureEngineStatus,
    settings: InspectorSettings,
    elapsedSeconds: Long,
    onSetRecordMode: (CaptureRecordMode) -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("VPN & Record Mode", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                GlassCard(glowAccent = if (status.isMonitoring) DcsEmerald else DcsCyan) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VpnLock, contentDescription = null, tint = if (status.isMonitoring) DcsEmerald else DcsCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Live VPN Monitoring Telemetry", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    TelemetryRow("VPN Connection Status", if (status.isVpnRunning) "Connected (${status.networkStatus})" else "Disconnected")
                    TelemetryRow("Local Proxy Status", status.localProxyStatus)
                    TelemetryRow("Monitoring Duration", formatDurationSeconds(elapsedSeconds))
                    TelemetryRow("Total Requests", status.totalRequests.toString())
                    TelemetryRow("Total Connections", status.totalConnections.toString())
                    TelemetryRow("Uploaded Data", formatBytes(status.uploadedBytes))
                    TelemetryRow("Downloaded Data", formatBytes(status.downloadedBytes))
                    TelemetryRow("Active Domains", status.activeDomains.size.toString())
                    TelemetryRow("Last Captured Request", status.lastCapturedRequestSummary ?: "None yet")

                    if (!status.vpnConflictMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        StatusPill(text = status.vpnConflictMessage, color = DcsServerError)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!status.isMonitoring) {
                            Button(
                                onClick = onStart,
                                colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                                modifier = Modifier.weight(1f).testTag("vpn_console_start_btn")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Start", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = onStop,
                                colors = ButtonDefaults.buttonColors(containerColor = DcsServerError, contentColor = DcsTextPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Stop")
                            }
                            OutlinedButton(
                                onClick = if (status.isPaused) onResume else onPause,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(if (status.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (status.isPaused) "Resume" else "Pause")
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onRestart, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restart Session")
                        }
                        OutlinedButton(onClick = onClear, modifier = Modifier.weight(1f)) {
                            Text("Clear Session")
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Text("Record Mode Selection", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    CaptureRecordMode.entries.forEach { mode ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSetRecordMode(mode) }
                                .padding(vertical = 6.dp)
                        ) {
                            RadioButton(selected = settings.recordMode == mode, onClick = { onSetRecordMode(mode) })
                            Column {
                                Text(mode.label, color = DcsTextPrimary, style = MaterialTheme.typography.bodyMedium)
                                Text(mode.description, color = DcsTextMuted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Text("Android VPN Permission & Limitations", style = MaterialTheme.typography.titleSmall, color = DcsRedirect)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Android only permits one active VpnService at a time. Starting another VPN will invoke onRevoke() and stop capture gracefully.\n" +
                            "• A persistent foreground notification stays visible whenever monitoring is active.\n" +
                            "• TLS/HTTPS flows show honest metadata (SNI hostname, ALPN, IP, bytes, timing) rather than attempting unauthorized decryption.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = DcsTextMuted)
        Text(value, style = MaterialTheme.typography.labelMedium, color = DcsTextPrimary)
    }
}
