package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.capture.CaCertStatus
import com.example.capture.CaptureEngineStatus
import com.example.classifier.AutoHighlightSettings
import com.example.data.settings.InspectorSettings
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsRedirect
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsSurface
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.StatusPill
import com.example.ui.viewmodel.AsyncActionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProxyConfigScreen(
    settings: InspectorSettings,
    status: CaptureEngineStatus,
    onSave: (Boolean, Int) -> Unit,
    onBack: () -> Unit
) {
    var enabled by remember(settings.localProxyEnabled) { mutableStateOf(settings.localProxyEnabled) }
    var portText by remember(settings.localProxyPort) { mutableStateOf(settings.localProxyPort.toString()) }
    val portInt = portText.toIntOrNull()
    val portValid = portInt != null && portInt in 1024..65535

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Proxy Port Configuration", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(glowAccent = if (status.isLocalProxyRunning) DcsEmerald else DcsCyan) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Local Loopback Proxy", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                            Text("Status: ${status.localProxyStatus}", style = MaterialTheme.typography.bodySmall, color = DcsCyan)
                        }
                        Switch(
                            checked = enabled,
                            onCheckedChange = {
                                enabled = it
                                if (portValid) onSave(it, portInt!!)
                            },
                            modifier = Modifier.testTag("proxy_enable_switch")
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = portText,
                        onValueChange = { portText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Local Proxy Port (1024 - 65535)") },
                        isError = !portValid,
                        supportingText = {
                            Text(if (portValid) "Binds strictly to 127.0.0.1:$portInt" else "Enter a valid unprivileged port between 1024 and 65535")
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("proxy_port_input")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                portText = "9000"
                                onSave(enabled, 9000)
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Reset Default (9000)") }
                        Button(
                            onClick = { if (portValid) onSave(enabled, portInt!!) },
                            enabled = portValid,
                            colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                            modifier = Modifier.weight(1f).testTag("apply_proxy_port_button")
                        ) { Text("Apply Port", fontWeight = FontWeight.Bold) }
                    }
                }
            }

            item {
                GlassCard {
                    Text("Security & Isolation Guarantee", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Bound exclusively to 127.0.0.1 (localhost) — never exposed to external Wi-Fi or LAN networks.\n" +
                            "• Never alters Android's global system proxy silently.\n" +
                            "• Point your test client (OkHttp, curl, or dev browser config) to 127.0.0.1:${portInt ?: 9000}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnhancedModeScreen(
    settings: InspectorSettings,
    onUpdate: (Boolean, Boolean, Boolean, Boolean) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Enhanced Mode", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(glowAccent = if (settings.enhancedModeEnabled) DcsEmerald else null) {
                    ToggleRow("Enable Enhanced Analysis", "Activates extended metadata correlation", settings.enhancedModeEnabled) {
                        onUpdate(it, settings.enhancedUidAttribution, settings.enhancedDnsCorrelation, settings.enhancedTimingBreakdown)
                    }
                    ToggleRow("UID-to-App Attribution", "Uses Android ConnectivityManager.getConnectionOwnerUid (API 29+)", settings.enhancedUidAttribution) {
                        onUpdate(settings.enhancedModeEnabled, it, settings.enhancedDnsCorrelation, settings.enhancedTimingBreakdown)
                    }
                    ToggleRow("DNS Hostname Correlation", "Maps resolved A-records to IP connections in real time", settings.enhancedDnsCorrelation) {
                        onUpdate(settings.enhancedModeEnabled, settings.enhancedUidAttribution, it, settings.enhancedTimingBreakdown)
                    }
                    ToggleRow("Connection Timing Breakdown", "Tracks TCP Connect, TTFB, and Total duration ms", settings.enhancedTimingBreakdown) {
                        onUpdate(settings.enhancedModeEnabled, settings.enhancedUidAttribution, settings.enhancedDnsCorrelation, it)
                    }
                }
            }
            item {
                GlassCard {
                    Text("Supported vs Restricted Capabilities", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Supported: Socket UID lookup on Android 10+, DNS query/answer domain correlation, TLS SNI/ALPN inspection, endpoint classification, and TCP timing.\n\n" +
                            "Not Supported (Platform Policy): Bypassing Android Network Security Config, bypassing certificate pinning, or reading other apps' private TLS keys.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SslDebuggingScreen(
    settings: InspectorSettings,
    caStatus: CaCertStatus,
    onUpdateSsl: (Boolean, Set<String>, Boolean) -> Unit,
    onGenerateCa: () -> Unit,
    onExportCa: () -> Unit,
    onBack: () -> Unit
) {
    var domainInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("SSL Proxying (Authorized Only)", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(glowAccent = DcsRedirect) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = DcsRedirect)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Authorized Testing Only — HTTPS Limitations", style = MaterialTheme.typography.titleSmall, color = DcsRedirect)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Intended strictly for developer-owned test apps and explicitly authorized staging servers.\n" +
                            "• Android 7+ ignores user-installed CA certificates by default unless an app's Network Security Config explicitly trusts user CAs.\n" +
                            "• Apps using Certificate Pinning will reject any proxy CA; DCS Inspector never attempts to bypass pinning and records unsupported TLS flows as metadata-only.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }

            item {
                GlassCard(glowAccent = if (settings.sslProxyingEnabled) DcsEmerald else null) {
                    ToggleRow(
                        title = "Enable Authorized SSL Proxying",
                        subtitle = "Applies ONLY to explicitly allowlisted test domains in Local Proxy mode",
                        checked = settings.sslProxyingEnabled
                    ) {
                        onUpdateSsl(it, settings.sslAllowlistDomains, settings.customCaInstalledNoteConfirmed)
                    }
                    ToggleRow(
                        title = "Confirm Authorized Environment",
                        subtitle = "I confirm I own or have explicit permission to debug the allowlisted domains",
                        checked = settings.customCaInstalledNoteConfirmed
                    ) {
                        onUpdateSsl(settings.sslProxyingEnabled, settings.sslAllowlistDomains, it)
                    }
                }
            }

            item {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = DcsCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Local Test Root CA Certificate", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Status: ${if (caStatus.isGenerated) "Generated" else "Not Generated"}", style = MaterialTheme.typography.bodySmall, color = DcsEmerald)
                    Text("Subject: ${caStatus.subject}", style = MonoCodeStyle, color = DcsTextSilver)
                    Text("SHA-256: ${caStatus.sha256Fingerprint}", style = MonoCodeStyle, color = DcsTextMuted)
                    Text("Valid Until: ${caStatus.validUntil}", style = MonoCodeStyle, color = DcsTextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onGenerateCa, modifier = Modifier.weight(1f).testTag("generate_ca_button")) {
                            Text(if (caStatus.isGenerated) "Verify CA" else "Generate CA")
                        }
                        Button(
                            onClick = onExportCa,
                            colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                            modifier = Modifier.weight(1f).testTag("export_ca_button")
                        ) {
                            Text("Export .CRT", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Text("Testing-Domain Allowlist (${settings.sslAllowlistDomains.size})", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = domainInput,
                            onValueChange = { domainInput = it },
                            placeholder = { Text("staging.myapp.local") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = {
                            val clean = domainInput.trim().lowercase()
                            if (clean.isNotBlank()) {
                                onUpdateSsl(settings.sslProxyingEnabled, settings.sslAllowlistDomains + clean, settings.customCaInstalledNoteConfirmed)
                                domainInput = ""
                            }
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Add domain", tint = DcsEmerald)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    settings.sslAllowlistDomains.forEach { dom ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(dom, style = MonoCodeStyle, color = DcsTextPrimary)
                            IconButton(onClick = {
                                onUpdateSsl(settings.sslProxyingEnabled, settings.sslAllowlistDomains - dom, settings.customCaInstalledNoteConfirmed)
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove $dom", tint = DcsServerError)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoHighlightScreen(
    settings: AutoHighlightSettings,
    onUpdate: (AutoHighlightSettings) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Auto Highlight", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard {
                    ToggleRow("Successful Requests (2xx)", "Highlight HTTP 200-299 in emerald", settings.highlightSuccess) {
                        onUpdate(settings.copy(highlightSuccess = it))
                    }
                    ToggleRow("Errors & Failures (4xx/5xx)", "Highlight failed & error responses", settings.highlightErrors) {
                        onUpdate(settings.copy(highlightErrors = it))
                    }
                    ToggleRow("Redirects (3xx)", "Highlight 301/302/307/308 redirects", settings.highlightRedirects) {
                        onUpdate(settings.copy(highlightRedirects = it))
                    }
                    ToggleRow("JSON Responses", "Tag application/json API payloads", settings.highlightJson) {
                        onUpdate(settings.copy(highlightJson = it))
                    }
                    ToggleRow("Auth & OTP Endpoints", "Categorize login/OTP endpoints (values always redacted)", settings.highlightAuthOtp) {
                        onUpdate(settings.copy(highlightAuthOtp = it))
                    }
                    ToggleRow("Slow Requests (> ${settings.slowThresholdMs}ms)", "Flag high-latency requests", settings.highlightSlow) {
                        onUpdate(settings.copy(highlightSlow = it))
                    }
                    ToggleRow("Large Responses (> ${settings.largeThresholdBytes / 1024}KB)", "Flag heavy response payloads", settings.highlightLarge) {
                        onUpdate(settings.copy(highlightLarge = it))
                    }
                }
            }
            item {
                GlassCard(glowAccent = DcsEmerald) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = DcsEmerald)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Login & OTP Redaction Policy", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Authentication & OTP highlighting shows endpoint structure, timestamps, status codes, and duration only. Actual OTPs, passwords, tokens, and session cookies are automatically replaced with [REDACTED].",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecondaryProxyScreen(
    settings: InspectorSettings,
    testState: AsyncActionState,
    onSave: (Boolean, String, Int) -> Unit,
    onTest: (String, Int) -> Unit,
    onBack: () -> Unit
) {
    var enabled by remember(settings.secondaryProxyEnabled) { mutableStateOf(settings.secondaryProxyEnabled) }
    var host by remember(settings.secondaryProxyHost) { mutableStateOf(settings.secondaryProxyHost) }
    var portStr by remember(settings.secondaryProxyPort) { mutableStateOf(settings.secondaryProxyPort.toString()) }
    val portInt = portStr.toIntOrNull() ?: 8080

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Secondary Proxy", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard {
                    ToggleRow("Enable Secondary Upstream Proxy", "Requires explicit host and port configuration", enabled) {
                        enabled = it
                        onSave(it, host, portInt)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        label = { Text("Upstream Proxy Host") },
                        placeholder = { Text("192.168.1.50") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = portStr,
                        onValueChange = { portStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Upstream Proxy Port") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    if (!testState.message.isNullOrBlank()) {
                        StatusPill(
                            text = testState.message,
                            color = if (testState.isError) DcsServerError else DcsEmerald
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { onTest(host, portInt) },
                            enabled = host.isNotBlank() && !testState.isLoading,
                            modifier = Modifier.weight(1f)
                        ) { Text(if (testState.isLoading) "Testing..." else "Test Connection") }
                        Button(
                            onClick = { onSave(enabled, host, portInt) },
                            colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                            modifier = Modifier.weight(1f)
                        ) { Text("Save", fontWeight = FontWeight.Bold) }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            enabled = false
                            host = ""
                            portStr = "8080"
                            onSave(false, "", 8080)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Reset Configuration") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessControlScreen(
    settings: InspectorSettings,
    isVpnRunning: Boolean,
    onUpdateAccessControl: (Boolean, Boolean) -> Unit,
    onOpenAppSelection: () -> Unit,
    onOpenSslAllowlist: () -> Unit,
    onClearAllData: () -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Access Control", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(glowAccent = DcsEmerald) {
                    Text("Sensitive-Data Redaction & Local Protection", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
                    Spacer(modifier = Modifier.height(6.dp))
                    ToggleRow(
                        title = "Automatic Credential & OTP Redaction",
                        subtitle = "Masks passwords, OTP codes, bearer tokens, API keys, and session cookies",
                        checked = settings.autoRedactSensitiveData
                    ) {
                        onUpdateAccessControl(it, settings.strictAllowlistOnlyForBody)
                    }
                    ToggleRow(
                        title = "Restrict Body Capture to Allowlisted Domains",
                        subtitle = "Only retain plaintext bodies for explicitly allowlisted test hosts",
                        checked = settings.strictAllowlistOnlyForBody
                    ) {
                        onUpdateAccessControl(settings.autoRedactSensitiveData, it)
                    }
                }
            }

            item {
                GlassCard {
                    Text("Monitoring Transparency & Controls", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• VPN State: ${if (isVpnRunning) "Active with persistent owner notification" else "Inactive"}\n" +
                            "• App Scope: ${settings.appScopeMode.label} (${settings.selectedAppPackages.size} selected)\n" +
                            "• SSL Allowlist: ${settings.sslAllowlistDomains.size} domain(s)",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenAppSelection, modifier = Modifier.weight(1f)) { Text("App Restrictions") }
                        OutlinedButton(onClick = onOpenSslAllowlist, modifier = Modifier.weight(1f)) { Text("Domain Allowlist") }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = onClearAllData, modifier = Modifier.fillMaxWidth()) {
                        Text("Wipe All Stored Session Data", color = DcsServerError)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportServerScreen(
    settings: InspectorSettings,
    recordCount: Int,
    state: AsyncActionState,
    onSave: (String, Boolean) -> Unit,
    onTest: (String) -> Unit,
    onUploadConfirmed: (String) -> Unit,
    onBack: () -> Unit
) {
    var serverUrl by remember(settings.reportServerUrl) { mutableStateOf(settings.reportServerUrl) }
    var requireConfirm by remember(settings.confirmBeforeReportUpload) { mutableStateOf(settings.confirmBeforeReportUpload) }
    var showConfirmDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Report Server", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard {
                    Text("Configurable Report Endpoint", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = serverUrl,
                        onValueChange = { serverUrl = it },
                        label = { Text("Report Server URL") },
                        placeholder = { Text("https://httpbin.org/post") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("report_server_url_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    ToggleRow(
                        title = "Require Explicit Upload Confirmation",
                        subtitle = "Traffic is never uploaded automatically",
                        checked = requireConfirm
                    ) {
                        requireConfirm = it
                        onSave(serverUrl, it)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    if (!state.message.isNullOrBlank()) {
                        StatusPill(
                            text = state.message,
                            color = if (state.isError) DcsServerError else DcsEmerald
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                onSave(serverUrl, requireConfirm)
                                onTest(serverUrl)
                            },
                            enabled = serverUrl.isNotBlank() && !state.isLoading,
                            modifier = Modifier.weight(1f)
                        ) { Text("Connection Test") }
                        Button(
                            onClick = {
                                onSave(serverUrl, requireConfirm)
                                if (requireConfirm) showConfirmDialog = true else onUploadConfirmed(serverUrl)
                            },
                            enabled = serverUrl.isNotBlank() && !state.isLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                            modifier = Modifier.weight(1f).testTag("upload_report_button")
                        ) { Text("Upload Report", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }

    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            containerColor = DcsSurface,
            title = { Text("Upload Redacted Report?", color = DcsTextPrimary) },
            text = {
                Text(
                    "Upload $recordCount traffic record(s) to $serverUrl?\n\nAll passwords, OTPs, cookies, and auth tokens remain redacted.",
                    color = DcsTextSilver
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmDialog = false
                    onUploadConfirmed(serverUrl)
                }) { Text("Confirm Upload", color = DcsEmerald) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = DcsTextPrimary)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = DcsTextMuted)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
