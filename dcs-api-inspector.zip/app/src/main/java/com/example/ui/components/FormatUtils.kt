package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.privacy.PrivacyRedactionEngine
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsRedactedBadge
import com.example.ui.theme.DcsRedirect
import com.example.ui.theme.DcsSurfaceHighlight
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.MonoCodeStyle
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(Locale.US, "%.2f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format(Locale.US, "%.2f MB", mb)
    return String.format(Locale.US, "%.2f GB", mb / 1024.0)
}

fun formatDurationSeconds(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}

fun formatTimeOnly(timestamp: Long): String {
    return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(timestamp))
}

fun formatDateTime(timestamp: Long): String {
    return SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US).format(Date(timestamp))
}

fun highlightSearchMatches(text: String, query: String): AnnotatedString {
    if (query.isBlank()) return AnnotatedString(text)
    val lowerText = text.lowercase()
    val lowerQuery = query.trim().lowercase()
    return buildAnnotatedString {
        var idx = 0
        while (idx < text.length) {
            val match = lowerText.indexOf(lowerQuery, idx)
            if (match < 0) {
                append(text.substring(idx))
                break
            }
            if (match > idx) {
                append(text.substring(idx, match))
            }
            withStyle(
                SpanStyle(
                    background = DcsCyan.copy(alpha = 0.28f),
                    color = DcsCyan,
                    fontWeight = FontWeight.Bold
                )
            ) {
                append(text.substring(match, match + lowerQuery.length))
            }
            idx = match + lowerQuery.length
        }
    }
}

@Composable
fun AppIconBadge(
    bitmap: ImageBitmap?,
    contentDescription: String,
    size: Dp = 28.dp
) {
    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = contentDescription,
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(8.dp))
        )
    } else {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(8.dp))
                .background(DcsSurfaceHighlight),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Public,
                contentDescription = contentDescription,
                tint = DcsCyan,
                modifier = Modifier.size(size * 0.62f)
            )
        }
    }
}

/**
 * Interactive expandable JSON tree with syntax highlighting and explicit [REDACTED] warning badges.
 */
@Composable
fun InteractiveJsonTree(
    rawJson: String,
    modifier: Modifier = Modifier
) {
    val parsed = remember(rawJson) {
        runCatching {
            val t = rawJson.trim()
            when {
                t.startsWith("{") -> JSONObject(t)
                t.startsWith("[") -> JSONArray(t)
                else -> null
            }
        }.getOrNull()
    }

    if (parsed == null) {
        Text(
            text = rawJson,
            style = MonoCodeStyle,
            color = DcsTextSilver,
            modifier = modifier
        )
        return
    }

    Column(modifier = modifier.fillMaxWidth()) {
        when (parsed) {
            is JSONObject -> JsonObjectNode(keyName = null, obj = parsed, depth = 0)
            is JSONArray -> JsonArrayNode(keyName = null, arr = parsed, depth = 0)
        }
    }
}

@Composable
private fun JsonObjectNode(keyName: String?, obj: JSONObject, depth: Int) {
    var expanded by remember { mutableStateOf(depth < 2) }
    val keys = remember(obj) { obj.keys().asSequence().toList() }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .padding(start = (depth * 14).dp, top = 2.dp, bottom = 2.dp)
    ) {
        Icon(
            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
            contentDescription = if (expanded) "Collapse" else "Expand",
            tint = DcsCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        if (keyName != null) {
            Text("\"$keyName\": ", style = MonoCodeStyle, color = DcsCyan)
        }
        Text(
            text = if (expanded) "{" else "{ ${keys.size} keys }",
            style = MonoCodeStyle,
            color = DcsTextMuted
        )
    }

    AnimatedVisibility(visible = expanded) {
        Column {
            keys.forEach { k ->
                val value = obj.opt(k)
                when (value) {
                    is JSONObject -> JsonObjectNode(keyName = k, obj = value, depth = depth + 1)
                    is JSONArray -> JsonArrayNode(keyName = k, arr = value, depth = depth + 1)
                    else -> JsonPrimitiveRow(keyName = k, value = value, depth = depth + 1)
                }
            }
            Text(
                text = "}",
                style = MonoCodeStyle,
                color = DcsTextMuted,
                modifier = Modifier.padding(start = (depth * 14 + 20).dp)
            )
        }
    }
}

@Composable
private fun JsonArrayNode(keyName: String?, arr: JSONArray, depth: Int) {
    var expanded by remember { mutableStateOf(depth < 2) }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .padding(start = (depth * 14).dp, top = 2.dp, bottom = 2.dp)
    ) {
        Icon(
            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
            contentDescription = if (expanded) "Collapse" else "Expand",
            tint = DcsCyan,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        if (keyName != null) {
            Text("\"$keyName\": ", style = MonoCodeStyle, color = DcsCyan)
        }
        Text(
            text = if (expanded) "[" else "[ ${arr.length()} items ]",
            style = MonoCodeStyle,
            color = DcsTextMuted
        )
    }

    AnimatedVisibility(visible = expanded) {
        Column {
            for (i in 0 until arr.length()) {
                when (val item = arr.opt(i)) {
                    is JSONObject -> JsonObjectNode(keyName = "[$i]", obj = item, depth = depth + 1)
                    is JSONArray -> JsonArrayNode(keyName = "[$i]", arr = item, depth = depth + 1)
                    else -> JsonPrimitiveRow(keyName = "[$i]", value = item, depth = depth + 1)
                }
            }
            Text(
                text = "]",
                style = MonoCodeStyle,
                color = DcsTextMuted,
                modifier = Modifier.padding(start = (depth * 14 + 20).dp)
            )
        }
    }
}

@Composable
private fun JsonPrimitiveRow(keyName: String, value: Any?, depth: Int) {
    val isRedacted = value?.toString() == PrivacyRedactionEngine.REDACTED_VALUE
    val valueText = when (value) {
        null, JSONObject.NULL -> "null"
        is String -> "\"$value\""
        else -> value.toString()
    }
    val valueColor = when {
        isRedacted -> DcsRedactedBadge
        value is Number -> DcsRedirect
        value is Boolean -> DcsEmerald
        value == null || value == JSONObject.NULL -> DcsTextMuted
        else -> DcsEmerald
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = (depth * 14 + 20).dp, top = 1.dp, bottom = 1.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Text(
            text = "\"$keyName\": ",
            style = MonoCodeStyle,
            color = DcsCyan
        )
        Text(
            text = valueText,
            style = MonoCodeStyle.copy(
                fontWeight = if (isRedacted) FontWeight.Bold else FontWeight.Normal
            ),
            color = valueColor
        )
    }
}

fun parseHeadersMap(headersJson: String): Map<String, String> {
    return runCatching {
        val obj = JSONObject(headersJson)
        val map = linkedMapOf<String, String>()
        obj.keys().forEach { k ->
            map[k] = obj.optString(k, "")
        }
        map
    }.getOrElse { emptyMap() }
}
