package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.db.CaptureSessionEntity
import com.example.data.db.TrafficRecordEntity
import com.example.export.ExportFormat
import com.example.export.ExportScope
import com.example.ui.components.formatBytes
import com.example.ui.components.formatDateTime
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsSurface
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.StatusPill
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExportManagerScreen(
    preselectedRequestId: String?,
    preselectedDomain: String?,
    resolveRecords: suspend (ExportScope, String?, String?) -> List<TrafficRecordEntity>,
    generateExportText: (List<TrafficRecordEntity>, ExportFormat) -> String,
    onShareExport: (List<TrafficRecordEntity>, ExportFormat) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedFormat by remember { mutableStateOf(ExportFormat.JSON) }
    var selectedScope by remember {
        mutableStateOf(
            when {
                preselectedRequestId != null -> ExportScope.SELECTED_REQUEST
                preselectedDomain != null -> ExportScope.SELECTED_DOMAIN
                else -> ExportScope.ENTIRE_SESSION
            }
        )
    }
    var resolvedRecords by remember { mutableStateOf<List<TrafficRecordEntity>>(emptyList()) }
    var previewText by remember { mutableStateOf("") }

    LaunchedEffect(selectedScope, selectedFormat, preselectedRequestId, preselectedDomain) {
        val list = resolveRecords(selectedScope, preselectedRequestId, preselectedDomain)
        resolvedRecords = list
        previewText = generateExportText(list.take(20), selectedFormat).take(2500)
    }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(selectedFormat.mimeType)
    ) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val content = generateExportText(resolvedRecords, selectedFormat)
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                }.onSuccess {
                    Toast.makeText(context, "Saved ${resolvedRecords.size} redacted record(s)", Toast.LENGTH_SHORT).show()
                }.onFailure {
                    Toast.makeText(context, "Save failed: ${it.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Export & Share Manager", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                GlassCard {
                    Text("Export Scope", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportScope.entries.forEach { sc ->
                            val enabled = when (sc) {
                                ExportScope.SELECTED_REQUEST -> preselectedRequestId != null
                                ExportScope.SELECTED_DOMAIN -> preselectedDomain != null
                                else -> true
                            }
                            if (enabled) {
                                FilterChip(
                                    selected = selectedScope == sc,
                                    onClick = { selectedScope = sc },
                                    label = { Text(sc.label) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Output Format", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ExportFormat.entries.forEach { fmt ->
                            FilterChip(
                                selected = selectedFormat == fmt,
                                onClick = { selectedFormat = fmt },
                                label = { Text(fmt.label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Matched Records: ${resolvedRecords.size} • All sensitive credentials automatically redacted.",
                        style = MaterialTheme.typography.labelMedium,
                        color = DcsEmerald
                    )
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onShareExport(resolvedRecords, selectedFormat) },
                        enabled = resolvedRecords.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                        modifier = Modifier.weight(1f).testTag("share_export_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            val fileName = "dcs_traffic_${System.currentTimeMillis()}.${selectedFormat.extension}"
                            createDocumentLauncher.launch(fileName)
                        },
                        enabled = resolvedRecords.isNotEmpty(),
                        modifier = Modifier.weight(1f).testTag("save_export_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save File")
                    }
                }
            }

            item {
                GlassCard {
                    Text("Redacted Output Preview", style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = previewText.ifBlank { "No records available for the selected scope." },
                        style = MonoCodeStyle,
                        color = DcsTextSilver
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionHistoryScreen(
    sessions: List<CaptureSessionEntity>,
    dbSizeBytes: Long,
    totalDbCount: Int,
    onSelectSession: (String) -> Unit,
    onDeleteSession: (String) -> Unit,
    onCleanupOld: () -> Unit,
    onClearAll: () -> Unit,
    onExportSession: () -> Unit
) {
    var showClearAllConfirm by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("Session History", style = MaterialTheme.typography.titleLarge, color = DcsTextPrimary)
                    Text("${sessions.size} session(s) • $totalDbCount stored record(s)", style = MaterialTheme.typography.labelSmall, color = DcsCyan)
                }
            },
            actions = {
                IconButton(onClick = onExportSession) {
                    Icon(Icons.Default.Download, contentDescription = "Export Session", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                GlassCard {
                    Text("Storage & Database Cleanup", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Local Room DB Size: ${formatBytes(dbSizeBytes)} • Records: $totalDbCount",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onCleanupOld, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Prune >24h")
                        }
                        OutlinedButton(onClick = { showClearAllConfirm = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = DcsServerError, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear All", color = DcsServerError)
                        }
                    }
                }
            }

            if (sessions.isEmpty()) {
                item {
                    GlassCard {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.History, contentDescription = null, tint = DcsTextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No capture sessions recorded yet", color = DcsTextSilver)
                        }
                    }
                }
            } else {
                items(sessions, key = { it.sessionId }) { session ->
                    GlassCard(
                        glowAccent = if (session.isActive) DcsEmerald else null,
                        onClick = { onSelectSession(session.sessionId) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(session.title, style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    StatusPill(
                                        text = if (session.isActive) "ACTIVE" else session.mode,
                                        color = if (session.isActive) DcsEmerald else DcsCyan
                                    )
                                }
                                Text(
                                    text = "Started: ${formatDateTime(session.startedAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DcsTextMuted
                                )
                                Text(
                                    text = "Browser: ${session.selectedBrowserName ?: "All Apps"} • Reqs: ${session.totalRequests} • ${formatBytes(session.bytesUploaded + session.bytesDownloaded)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DcsTextSilver
                                )
                            }
                            IconButton(onClick = { onDeleteSession(session.sessionId) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete session", tint = DcsServerError)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearAllConfirm) {
        AlertDialog(
            onDismissRequest = { showClearAllConfirm = false },
            containerColor = DcsSurface,
            title = { Text("Delete All Sessions & Traffic?", color = DcsTextPrimary) },
            text = { Text("This permanently deletes all local Room traffic history.", color = DcsTextSilver) },
            confirmButton = {
                TextButton(onClick = {
                    showClearAllConfirm = false
                    onClearAll()
                }) { Text("Delete All", color = DcsServerError) }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onOpenProxyConfig: () -> Unit,
    onOpenSsl: () -> Unit,
    onOpenAccessControl: () -> Unit,
    onOpenEnhancedMode: () -> Unit,
    onOpenReportServer: () -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Settings & Branding", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(glowAccent = DcsCyan) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = DcsCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("DCS API INSPECTOR", style = MaterialTheme.typography.titleMedium, color = DcsTextPrimary)
                            Text("DARK CYBER SECURITY • DEVELOPER: ALIF ISLAM", style = MaterialTheme.typography.labelSmall, color = DcsEmerald)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Professional Android network capture, local VPN packet telemetry, browser traffic debugger, and privacy-enforcing HTTP inspector.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextSilver
                    )
                }
            }

            item {
                GlassCard {
                    Text("Configuration Shortcuts", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenProxyConfig, modifier = Modifier.fillMaxWidth()) { Text("Proxy Port Configuration") }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(onClick = onOpenEnhancedMode, modifier = Modifier.fillMaxWidth()) { Text("Enhanced Mode") }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(onClick = onOpenSsl, modifier = Modifier.fillMaxWidth()) { Text("SSL Proxying (Authorized Only)") }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(onClick = onOpenAccessControl, modifier = Modifier.fillMaxWidth()) { Text("Access Control & Privacy") }
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(onClick = onOpenReportServer, modifier = Modifier.fillMaxWidth()) { Text("Report Server") }
                }
            }
        }
    }
}
