package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassBackdrop
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.88f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, animationSpec = tween(450))
        scale.animateTo(1f, animationSpec = tween(450))
        delay(850L)
        onFinished()
    }

    GlassBackdrop(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onFinished() }
            .testTag("splash_screen")
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_dcs_hero_banner),
            contentDescription = "Dark Cyber Security network grid backdrop",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.28f)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
                .alpha(alpha.value)
                .scale(scale.value),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(116.dp)
                    .clip(CircleShape)
                    .background(DcsVoidBg)
                    .border(2.dp, DcsCyan.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_dcs_foreground_art),
                    contentDescription = "DCS API Inspector emblem",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "DCS API INSPECTOR",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                ),
                color = DcsTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "UNIVERSAL NETWORK & HTTP DEBUGGER",
                style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.4.sp),
                color = DcsCyan
            )

            Spacer(modifier = Modifier.height(28.dp))

            LinearProgressIndicator(
                color = DcsEmerald,
                trackColor = DcsCyan.copy(alpha = 0.15f),
                modifier = Modifier
                    .size(width = 180.dp, height = 3.dp)
                    .clip(RoundedCornerShape(4.dp))
            )

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = "DARK CYBER SECURITY",
                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 1.8.sp),
                color = DcsTextSilver
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ENGINEERED BY ALIF ISLAM",
                style = MaterialTheme.typography.labelSmall,
                color = DcsTextMuted
            )
        }
    }
}
