package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsGlassBorder
import com.example.ui.theme.DcsSurface
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.StatusPill

enum class MenuActionId {
    FILTER, SEARCH, SORT, SHARE, EXPORT, GROUP_BY_HOST, APP_SELECTION,
    PROXY_PORT, RECORD_MODE_VPN, ENHANCED_MODE, SSL_PROXYING, AUTO_HIGHLIGHT,
    SECONDARY_PROXY, ACCESS_CONTROL, REPORT_SERVER
}

private data class MenuEntry(
    val id: MenuActionId,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val badge: String? = null,
    val accent: Color = DcsCyan
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrafficManagementMenuSheet(
    activeFilterCount: Int,
    sslEnabled: Boolean,
    enhancedEnabled: Boolean,
    proxyPort: Int,
    secondaryProxyEnabled: Boolean,
    onDismiss: () -> Unit,
    onSelectAction: (MenuActionId) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val trafficManagementItems = listOf(
        MenuEntry(MenuActionId.FILTER, "Filter", "Method, status, domain, app, time range", Icons.Default.FilterAlt, if (activeFilterCount > 0) "$activeFilterCount active" else null),
        MenuEntry(MenuActionId.SEARCH, "Search", "Real-time search with match highlighting", Icons.Default.Search),
        MenuEntry(MenuActionId.SORT, "Sort", "Newest, oldest, size, status, domain, duration", Icons.Default.Sort),
        MenuEntry(MenuActionId.SHARE, "Share", "Share redacted report via Android Intent", Icons.Default.Share),
        MenuEntry(MenuActionId.EXPORT, "Export", "Export JSON, TXT, or CSV safely", Icons.Default.Download),
        MenuEntry(MenuActionId.GROUP_BY_HOST, "Group by Host", "Domain traffic grouping & totals", Icons.Default.Dns),
        MenuEntry(MenuActionId.APP_SELECTION, "Application Selection", "Restrict capture to chosen apps/browsers", Icons.Default.Apps)
    )

    val proxySettingsItems = listOf(
        MenuEntry(MenuActionId.PROXY_PORT, "Proxy Port Configuration", "Loopback 127.0.0.1:$proxyPort", Icons.Default.Router, ":$proxyPort", DcsEmerald),
        MenuEntry(MenuActionId.RECORD_MODE_VPN, "Record Mode (VPN)", "VPN TUN, Local Proxy, or hybrid capture", Icons.Default.VpnKey),
        MenuEntry(MenuActionId.ENHANCED_MODE, "Enhanced Mode", "UID attribution, DNS & timing breakdown", Icons.Default.Speed, if (enhancedEnabled) "ON" else "OFF"),
        MenuEntry(MenuActionId.SSL_PROXYING, "SSL Proxying", "Authorized testing CA & domain allowlist", Icons.Default.Lock, if (sslEnabled) "ON" else "OFF", if (sslEnabled) DcsEmerald else DcsTextMuted),
        MenuEntry(MenuActionId.AUTO_HIGHLIGHT, "Auto Highlight", "Auth/OTP, JSON, errors, slow & large rules", Icons.Default.AutoAwesome),
        MenuEntry(MenuActionId.SECONDARY_PROXY, "Secondary Proxy", "Upstream HTTP proxy tunnel & test", Icons.Default.Hub, if (secondaryProxyEnabled) "ON" else "OFF"),
        MenuEntry(MenuActionId.ACCESS_CONTROL, "Access Control", "Permissions, allowlist & redaction policy", Icons.Default.AdminPanelSettings),
        MenuEntry(MenuActionId.REPORT_SERVER, "Report Server", "Test & upload redacted debug report", Icons.Default.CloudUpload)
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DcsSurface,
        contentColor = DcsTextPrimary
    ) {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            item {
                Text(
                    text = "TRAFFIC MANAGEMENT",
                    style = MaterialTheme.typography.labelMedium,
                    color = DcsCyan,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            items(trafficManagementItems, key = { it.id.name }) { item ->
                MenuRow(item = item, onClick = {
                    onDismiss()
                    onSelectAction(item.id)
                })
            }

            item {
                HorizontalDivider(
                    color = DcsGlassBorder,
                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp)
                )
                Text(
                    text = "PROXY & CAPTURE SETTINGS",
                    style = MaterialTheme.typography.labelMedium,
                    color = DcsEmerald,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
            items(proxySettingsItems, key = { it.id.name }) { item ->
                MenuRow(item = item, onClick = {
                    onDismiss()
                    onSelectAction(item.id)
                })
            }
        }
    }
}

@Composable
private fun MenuRow(item: MenuEntry, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("menu_item_${item.id.name.lowercase()}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = item.icon,
            contentDescription = item.title,
            tint = item.accent,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = item.title, style = MaterialTheme.typography.titleSmall, color = DcsTextPrimary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = item.subtitle, style = MaterialTheme.typography.bodySmall, color = DcsTextSilver)
        }
        if (item.badge != null) {
            Spacer(modifier = Modifier.width(8.dp))
            StatusPill(text = item.badge, color = item.accent)
        }
    }
}
