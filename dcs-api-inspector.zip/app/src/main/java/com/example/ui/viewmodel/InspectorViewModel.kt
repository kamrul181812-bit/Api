package com.example.ui.viewmodel

import android.app.Application
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.DcsInspectorApp
import com.example.browser.InstalledAppInfo
import com.example.browser.InstalledBrowser
import com.example.capture.CaCertStatus
import com.example.capture.CaptureEngineStatus
import com.example.capture.LocalCaManager
import com.example.classifier.AutoHighlightSettings
import com.example.data.db.CaptureSessionEntity
import com.example.data.db.SavedFilterEntity
import com.example.data.db.TrafficFilterCriteria
import com.example.data.db.TrafficRecordEntity
import com.example.data.repository.DomainGroupSummary
import com.example.data.repository.TrafficRepository
import com.example.data.repository.TrafficSortOption
import com.example.data.settings.AppScopeMode
import com.example.data.settings.CaptureRecordMode
import com.example.data.settings.InspectorSettings
import com.example.export.ExportFormat
import com.example.export.ExportScope
import com.example.proxy.LocalProxyService
import com.example.vpn.DcsVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AsyncActionState(
    val isLoading: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false
)

class InspectorViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as DcsInspectorApp
    private val repository = app.repository
    private val settingsManager = app.settingsManager
    val browserManager = app.browserManager
    private val captureEngine = app.captureEngine
    private val exportManager = app.exportManager

    val captureStatus: StateFlow<CaptureEngineStatus> = captureEngine.status

    val settings: StateFlow<InspectorSettings> = settingsManager.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, InspectorSettings())

    private val _filterCriteria = MutableStateFlow(TrafficFilterCriteria())
    val filterCriteria: StateFlow<TrafficFilterCriteria> = _filterCriteria.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOption = MutableStateFlow(TrafficSortOption.NEWEST_FIRST)
    val sortOption: StateFlow<TrafficSortOption> = _sortOption.asStateFlow()

    private val _selectedSessionFilterId = MutableStateFlow<String?>(null)
    val selectedSessionFilterId: StateFlow<String?> = _selectedSessionFilterId.asStateFlow()

    private val _pageLimit = MutableStateFlow(100)
    val pageLimit: StateFlow<Int> = _pageLimit.asStateFlow()

    private val _elapsedSeconds = MutableStateFlow(0L)
    val elapsedSeconds: StateFlow<Long> = _elapsedSeconds.asStateFlow()

    private val _installedBrowsers = MutableStateFlow<List<InstalledBrowser>>(emptyList())
    val installedBrowsers: StateFlow<List<InstalledBrowser>> = _installedBrowsers.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _caStatus = MutableStateFlow(LocalCaManager.getCaStatus(app))
    val caStatus: StateFlow<CaCertStatus> = _caStatus.asStateFlow()

    private val _secondaryProxyTestState = MutableStateFlow(AsyncActionState())
    val secondaryProxyTestState: StateFlow<AsyncActionState> = _secondaryProxyTestState.asStateFlow()

    private val _reportServerState = MutableStateFlow(AsyncActionState())
    val reportServerState: StateFlow<AsyncActionState> = _reportServerState.asStateFlow()

    private val _dbSizeBytes = MutableStateFlow(0L)
    val dbSizeBytes: StateFlow<Long> = _dbSizeBytes.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events = _events.asSharedFlow()

    val sessions: StateFlow<List<CaptureSessionEntity>> = repository.observeSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedFilters: StateFlow<List<SavedFilterEntity>> = repository.observeSavedFilters()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalDbCount: StateFlow<Int> = repository.observeTotalCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val rawRecordsFlow: Flow<List<TrafficRecordEntity>> = repository.observeRecentRecords(limit = 2000)

    val filteredTraffic: StateFlow<List<TrafficRecordEntity>> = combine(
        rawRecordsFlow,
        _filterCriteria,
        _searchQuery,
        _sortOption,
        _selectedSessionFilterId
    ) { records, filter, query, sort, sessionFilterId ->
        val scoped = if (sessionFilterId != null) {
            records.filter { it.sessionId == sessionFilterId }
        } else {
            records
        }
        TrafficRepository.applyFilterSearchAndSort(scoped, filter, query, sort)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pagedTraffic: StateFlow<List<TrafficRecordEntity>> = combine(
        filteredTraffic,
        _pageLimit
    ) { list, limit ->
        list.take(limit)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val domainGroups: StateFlow<List<DomainGroupSummary>> = combine(
        filteredTraffic,
        _searchQuery
    ) { list, _ ->
        TrafficRepository.groupByHost(list)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        refreshInstalledPackages()
        refreshStorageSize()
        viewModelScope.launch {
            while (true) {
                val st = captureStatus.value
                _elapsedSeconds.value = if (st.isMonitoring && st.sessionStartedAt > 0L) {
                    (System.currentTimeMillis() - st.sessionStartedAt) / 1000L
                } else {
                    0L
                }
                delay(1000L)
            }
        }
        viewModelScope.launch {
            settings.collect { latest ->
                captureEngine.currentSettings = latest
            }
        }
    }

    fun observeRecord(requestId: String): Flow<TrafficRecordEntity?> = repository.observeRecordById(requestId)

    fun refreshInstalledPackages() {
        viewModelScope.launch(Dispatchers.IO) {
            val browsers = browserManager.discoverInstalledBrowsers()
            _installedBrowsers.value = browsers
            val browserPkgs = browsers.map { it.packageName }.toSet()
            _installedApps.value = browserManager.discoverLaunchableApps(browserPkgs)

            // Pre-select default browser if none selected yet
            val current = settingsManager.settingsFlow.first()
            if (current.selectedBrowserPackage == null && browsers.isNotEmpty()) {
                val preferred = browsers.firstOrNull { it.isDefault } ?: browsers.first()
                settingsManager.setSelectedBrowser(preferred.packageName, preferred.appName)
            }
        }
    }

    fun refreshStorageSize() {
        viewModelScope.launch(Dispatchers.IO) {
            _dbSizeBytes.value = repository.getDatabaseSizeBytes()
        }
    }

    fun loadMoreTraffic() {
        _pageLimit.value += 100
    }

    fun setSessionFilter(sessionId: String?) {
        _selectedSessionFilterId.value = sessionId
    }

    fun prepareVpnIntent() = VpnService.prepare(app)

    fun startMonitoringAfterVpnGranted() {
        viewModelScope.launch {
            val s = settings.value
            when (s.recordMode) {
                CaptureRecordMode.VPN -> DcsVpnService.start(app)
                CaptureRecordMode.LOCAL_PROXY -> {
                    settingsManager.setLocalProxy(true, s.localProxyPort)
                    LocalProxyService.start(app, s.localProxyPort)
                }
                CaptureRecordMode.VPN_AND_PROXY -> {
                    DcsVpnService.start(app)
                    settingsManager.setLocalProxy(true, s.localProxyPort)
                    LocalProxyService.start(app, s.localProxyPort)
                }
            }
        }
    }

    fun stopMonitoring() {
        if (captureStatus.value.isVpnRunning) {
            DcsVpnService.sendAction(app, DcsVpnService.ACTION_STOP)
        }
        if (captureStatus.value.isLocalProxyRunning) {
            LocalProxyService.stop(app)
        }
    }

    fun pauseMonitoring() {
        captureEngine.pauseRecording()
        if (captureStatus.value.isVpnRunning) {
            DcsVpnService.sendAction(app, DcsVpnService.ACTION_PAUSE)
        }
    }

    fun resumeMonitoring() {
        captureEngine.resumeRecording()
        if (captureStatus.value.isVpnRunning) {
            DcsVpnService.sendAction(app, DcsVpnService.ACTION_RESUME)
        }
    }

    fun restartMonitoring() {
        viewModelScope.launch {
            if (captureStatus.value.isVpnRunning) {
                DcsVpnService.sendAction(app, DcsVpnService.ACTION_RESTART)
            } else {
                startMonitoringAfterVpnGranted()
            }
            if (captureStatus.value.isLocalProxyRunning) {
                LocalProxyService.stop(app)
                delay(250)
                LocalProxyService.start(app, settings.value.localProxyPort)
            }
        }
    }

    fun clearCurrentTraffic() {
        viewModelScope.launch {
            val sid = _selectedSessionFilterId.value ?: captureStatus.value.activeSessionId
            if (sid != null) {
                repository.clearSessionTraffic(sid)
            } else {
                repository.clearAllTrafficAndSessions()
            }
            captureEngine.clearCurrentSession()
            refreshStorageSize()
            _events.emit("Traffic cleared")
        }
    }

    fun selectBrowser(browser: InstalledBrowser) {
        viewModelScope.launch {
            settingsManager.setSelectedBrowser(browser.packageName, browser.appName)
            _events.emit("Selected ${browser.appName}")
        }
    }

    fun updateBrowserLaunchUrl(url: String) {
        viewModelScope.launch {
            settingsManager.setBrowserLaunchUrl(url)
        }
    }

    fun launchSelectedBrowser(url: String) {
        viewModelScope.launch {
            val s = settings.value
            settingsManager.setBrowserLaunchUrl(url)
            val res = browserManager.launchBrowserWithUrl(s.selectedBrowserPackage, url)
            res.onSuccess { launchedUrl ->
                _events.emit("Opened $launchedUrl in ${s.selectedBrowserName ?: "Browser"}")
            }.onFailure { err ->
                _events.emit("Launch failed: ${err.message}")
            }
        }
    }

    fun setAppScopeMode(mode: AppScopeMode) {
        viewModelScope.launch {
            settingsManager.setAppScopeMode(mode)
        }
    }

    fun toggleSelectedApp(packageName: String) {
        viewModelScope.launch {
            val current = settings.value.selectedAppPackages.toMutableSet()
            if (!current.add(packageName)) {
                current.remove(packageName)
            }
            settingsManager.setSelectedAppPackages(current)
        }
    }

    fun applyFilter(criteria: TrafficFilterCriteria, saveRecent: Boolean = true) {
        _filterCriteria.value = criteria
        if (saveRecent && !criteria.isEmpty()) {
            viewModelScope.launch {
                val summary = buildString {
                    if (criteria.methods.isNotEmpty()) append(criteria.methods.joinToString("/"))
                    if (criteria.domainQuery.isNotBlank()) append(" ${criteria.domainQuery}")
                    if (criteria.statusGroups.isNotEmpty()) append(" ${criteria.statusGroups.joinToString(",")}")
                }.trim().ifBlank { "Custom Filter" }
                repository.saveFilter(summary, criteria, isRecent = true)
            }
        }
    }

    fun saveNamedFilter(name: String, criteria: TrafficFilterCriteria) {
        viewModelScope.launch {
            repository.saveFilter(name.ifBlank { "Saved Filter" }, criteria, isRecent = false)
            _events.emit("Filter saved")
        }
    }

    fun applySavedFilter(saved: SavedFilterEntity) {
        val decoded = repository.decodeFilterCriteria(saved.criteriaJson)
        if (decoded != null) {
            _filterCriteria.value = decoded
            viewModelScope.launch { _events.emit("Applied '${saved.name}'") }
        }
    }

    fun deleteSavedFilter(id: Long) {
        viewModelScope.launch { repository.deleteSavedFilter(id) }
    }

    fun resetFilter() {
        _filterCriteria.value = TrafficFilterCriteria()
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOption(option: TrafficSortOption) {
        _sortOption.value = option
    }

    fun setRecordMode(mode: CaptureRecordMode) {
        viewModelScope.launch { settingsManager.setRecordMode(mode) }
    }

    fun updateLocalProxyConfig(enabled: Boolean, port: Int) {
        viewModelScope.launch {
            val validPort = port.coerceIn(1024, 65535)
            settingsManager.setLocalProxy(enabled, validPort)
            if (enabled) {
                LocalProxyService.start(app, validPort)
            } else {
                LocalProxyService.stop(app)
            }
        }
    }

    fun updateEnhancedMode(enabled: Boolean, uid: Boolean, dns: Boolean, timing: Boolean) {
        viewModelScope.launch {
            settingsManager.setEnhancedMode(enabled, uid, dns, timing)
        }
    }

    fun updateSslProxying(enabled: Boolean, allowlist: Set<String>, confirmed: Boolean) {
        viewModelScope.launch {
            settingsManager.setSslProxying(enabled, allowlist, confirmed)
        }
    }

    fun generateOrRefreshRootCa() {
        viewModelScope.launch(Dispatchers.IO) {
            LocalCaManager.getOrCreateRootCa(app)
            _caStatus.value = LocalCaManager.getCaStatus(app)
            _events.emit("Local Test Root CA ready")
        }
    }

    fun exportRootCa() {
        viewModelScope.launch(Dispatchers.IO) {
            val pem = LocalCaManager.exportPemContent(app)
            _caStatus.value = LocalCaManager.getCaStatus(app)
            exportManager.shareCertificateFile(pem)
                .onFailure { _events.emit("Export CA failed: ${it.message}") }
        }
    }

    fun updateAutoHighlight(autoHighlight: AutoHighlightSettings) {
        viewModelScope.launch { settingsManager.setAutoHighlight(autoHighlight) }
    }

    fun updateSecondaryProxy(enabled: Boolean, host: String, port: Int) {
        viewModelScope.launch {
            settingsManager.setSecondaryProxy(enabled, host.trim(), port.coerceIn(1, 65535))
        }
    }

    fun testSecondaryProxy(host: String, port: Int) {
        viewModelScope.launch {
            _secondaryProxyTestState.value = AsyncActionState(isLoading = true, message = "Testing TCP handshake...")
            val res = exportManager.testSecondaryProxyConnection(host, port)
            _secondaryProxyTestState.value = res.fold(
                onSuccess = { ms -> AsyncActionState(isLoading = false, message = "Connected in ${ms}ms", isError = false) },
                onFailure = { e -> AsyncActionState(isLoading = false, message = "Failed: ${e.message}", isError = true) }
            )
        }
    }

    fun updateAccessControl(autoRedact: Boolean, strictAllowlistBody: Boolean) {
        viewModelScope.launch {
            settingsManager.setAccessControl(autoRedact, strictAllowlistBody)
        }
    }

    fun updateReportServer(url: String, requireConfirmation: Boolean) {
        viewModelScope.launch {
            settingsManager.setReportServer(url.trim(), requireConfirmation)
        }
    }

    fun testReportServer(url: String) {
        viewModelScope.launch {
            _reportServerState.value = AsyncActionState(isLoading = true, message = "Testing server connection...")
            val res = exportManager.testReportServerConnection(url)
            _reportServerState.value = res.fold(
                onSuccess = { (code, ms) -> AsyncActionState(false, "Reachable (HTTP $code in ${ms}ms)", false) },
                onFailure = { e -> AsyncActionState(false, "Connection failed: ${e.message}", true) }
            )
        }
    }

    fun uploadReportToServer(url: String) {
        viewModelScope.launch {
            val records = filteredTraffic.value
            if (records.isEmpty()) {
                _reportServerState.value = AsyncActionState(false, "No captured traffic records to upload.", true)
                return@launch
            }
            _reportServerState.value = AsyncActionState(true, "Redacting & uploading ${records.size} records...")
            val res = exportManager.uploadReportToServer(url, records)
            _reportServerState.value = res.fold(
                onSuccess = { code -> AsyncActionState(false, "Uploaded ${records.size} redacted records (HTTP $code)", false) },
                onFailure = { e -> AsyncActionState(false, "Upload error: ${e.message}", true) }
            )
        }
    }

    suspend fun resolveExportRecords(
        scope: ExportScope,
        selectedRequestId: String? = null,
        selectedDomain: String? = null
    ): List<TrafficRecordEntity> {
        return when (scope) {
            ExportScope.SELECTED_REQUEST -> {
                if (selectedRequestId != null) {
                    listOfNotNull(repository.getAllRecordsSnapshot().firstOrNull { it.requestId == selectedRequestId })
                } else emptyList()
            }
            ExportScope.SELECTED_DOMAIN -> {
                if (!selectedDomain.isNullOrBlank()) {
                    repository.getAllRecordsSnapshot().filter { it.domain.equals(selectedDomain, true) }
                } else emptyList()
            }
            ExportScope.CURRENT_FILTER -> filteredTraffic.value
            ExportScope.ENTIRE_SESSION -> {
                val sid = _selectedSessionFilterId.value ?: captureStatus.value.activeSessionId
                if (sid != null) repository.getSessionRecordsSnapshot(sid) else repository.getAllRecordsSnapshot()
            }
        }
    }

    fun generateExportText(records: List<TrafficRecordEntity>, format: ExportFormat): String =
        exportManager.generateExportContent(records, format)

    fun shareExport(records: List<TrafficRecordEntity>, format: ExportFormat) {
        exportManager.shareExportFile(records, format)
            .onFailure {
                viewModelScope.launch { _events.emit("Share failed: ${it.message}") }
            }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_selectedSessionFilterId.value == sessionId) {
                _selectedSessionFilterId.value = null
            }
            refreshStorageSize()
            _events.emit("Session deleted")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllTrafficAndSessions()
            _selectedSessionFilterId.value = null
            refreshStorageSize()
            _events.emit("All captured sessions & traffic cleared")
        }
    }

    fun cleanupOldTraffic(hours: Int = 24) {
        viewModelScope.launch {
            val count = repository.deleteTrafficOlderThanHours(hours)
            refreshStorageSize()
            _events.emit("Cleaned up $count records older than ${hours}h")
        }
    }
}
