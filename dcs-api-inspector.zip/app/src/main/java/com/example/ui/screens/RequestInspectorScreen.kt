package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.db.TrafficRecordEntity
import com.example.ui.components.InteractiveJsonTree
import com.example.ui.components.formatBytes
import com.example.ui.components.formatDateTime
import com.example.ui.components.parseHeadersMap
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsRedactedBadge
import com.example.ui.theme.DcsRedirect
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsTlsBadge
import com.example.ui.theme.GlassCard
import com.example.ui.theme.MethodPill
import com.example.ui.theme.MonoCodeStyle
import com.example.ui.theme.StatusPill
import com.example.ui.theme.statusCodeColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestInspectorScreen(
    record: TrafficRecordEntity?,
    onBack: () -> Unit,
    onExportRequest: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Summary", "Raw", "Headers", "Body")

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                if (record != null) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            MethodPill(method = record.method)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = record.domain,
                                style = MaterialTheme.typography.titleMedium,
                                color = DcsTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = record.path,
                            style = MaterialTheme.typography.labelSmall,
                            color = DcsTextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    Text("Request Inspector", color = DcsTextPrimary)
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack, modifier = Modifier.testTag("inspector_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            actions = {
                if (record != null) {
                    IconButton(
                        onClick = { copyToClipboard(context, "URL", record.url) },
                        modifier = Modifier.testTag("copy_url_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy URL", tint = DcsTextSilver)
                    }
                    IconButton(
                        onClick = { onExportRequest(record.requestId) },
                        modifier = Modifier.testTag("export_request_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Export Request", tint = DcsCyan)
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        if (record == null) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Traffic record not found", color = DcsTextSilver)
            }
            return
        }

        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.Transparent,
            contentColor = DcsCyan
        ) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = {
                        Text(
                            text = title,
                            color = if (selectedTab == idx) DcsCyan else DcsTextMuted,
                            fontWeight = if (selectedTab == idx) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    modifier = Modifier.testTag("inspector_tab_${title.lowercase()}")
                )
            }
        }

        when (selectedTab) {
            0 -> SummaryTab(record = record, context = context, onExportRequest = onExportRequest)
            1 -> RawTab(record = record)
            2 -> HeadersTab(record = record, context = context)
            3 -> BodyTab(record = record, context = context)
        }
    }
}

@Composable
private fun SummaryTab(
    record: TrafficRecordEntity,
    context: Context,
    onExportRequest: (String) -> Unit
) {
    val queryParams = remember(record.queryParamsJson) { parseHeadersMap(record.queryParamsJson) }
    val statusColor = statusCodeColor(record.statusCode, record.isFailed)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        if (record.redactedCount > 0) {
            item {
                GlassCard(glowAccent = DcsRedactedBadge) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = DcsRedactedBadge)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Privacy Shield Active: ${record.redactedCount} sensitive field(s) automatically redacted.",
                            style = MaterialTheme.typography.bodySmall,
                            color = DcsRedactedBadge
                        )
                    }
                }
            }
        }

        if (!record.limitationNote.isNullOrBlank()) {
            item {
                GlassCard(glowAccent = DcsTlsBadge) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = DcsTlsBadge)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("TLS / Platform Transparency", style = MaterialTheme.typography.titleSmall, color = DcsTlsBadge)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(record.limitationNote, style = MaterialTheme.typography.bodySmall, color = DcsTextSilver)
                }
            }
        }

        if (!record.errorMessage.isNullOrBlank()) {
            item {
                GlassCard(glowAccent = DcsServerError) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = DcsServerError)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Connection Error", style = MaterialTheme.typography.titleSmall, color = DcsServerError)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(record.errorMessage, style = MaterialTheme.typography.bodySmall, color = DcsTextPrimary)
                }
            }
        }

        item {
            GlassCard {
                Text("General & Connection", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                Spacer(modifier = Modifier.height(8.dp))
                DetailRow("Status", if (record.statusCode > 0) "${record.statusCode} ${record.statusMessage}" else if (record.isFailed) "Failed" else "Pending", statusColor)
                DetailRow("Method", record.method)
                DetailRow("Protocol", record.protocol)
                DetailRow("HTTP Version", record.httpVersion)
                DetailRow("Request URL", record.url)
                DetailRow("Remote Address", record.remoteAddress)
                DetailRow("Remote Port", record.remotePort.toString())
                DetailRow("Connection Type", record.connectionType)
                DetailRow("Application", "${record.appName} (${record.packageName ?: "n/a"})")
                DetailRow("Request Size", formatBytes(record.requestSize))
                DetailRow("Response Size", formatBytes(record.responseSize))
                DetailRow("Content Type", record.contentType ?: "Unavailable")
                DetailRow("Duration", "${record.durationMs} ms")
                DetailRow("Timing", record.timingBreakdown.ifBlank { "${record.durationMs} ms" })
                DetailRow("Timestamp", formatDateTime(record.timestamp))
            }
        }

        if (queryParams.isNotEmpty()) {
            item {
                GlassCard {
                    Text("Query Parameters (${queryParams.size})", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
                    Spacer(modifier = Modifier.height(8.dp))
                    queryParams.forEach { (k, v) ->
                        DetailRow(k, v, if (v == "[REDACTED]") DcsRedactedBadge else DcsTextPrimary)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { copyToClipboard(context, "URL", record.url) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Copy URL")
                }
                OutlinedButton(
                    onClick = { onExportRequest(record.requestId) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Export Details")
                }
            }
        }
    }
}

@Composable
private fun RawTab(record: TrafficRecordEntity) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        GlassCard {
            Text("Raw Request Information", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
            Spacer(modifier = Modifier.height(6.dp))
            SelectionContainer {
                Text(
                    text = buildString {
                        append(record.rawRequestInfo.ifBlank { "${record.method} ${record.path} ${record.httpVersion}\nHost: ${record.host}" })
                        if (!record.requestBody.isNullOrBlank()) {
                            append("\n\n").append(record.requestBody)
                        } else if (record.isTlsMetadataOnly) {
                            append("\n\n[Encrypted TLS Request Payload — Unavailable]")
                        }
                    },
                    style = MonoCodeStyle,
                    color = DcsTextSilver
                )
            }
        }

        GlassCard {
            Text("Raw Response Information", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
            Spacer(modifier = Modifier.height(6.dp))
            SelectionContainer {
                Text(
                    text = buildString {
                        append(record.rawResponseInfo.ifBlank {
                            if (record.isTlsMetadataOnly) "[Encrypted TLS Response — Metadata Only]" else "[No raw response headers captured]"
                        })
                        if (!record.responseBody.isNullOrBlank()) {
                            append("\n\n").append(record.responseBody)
                        }
                    },
                    style = MonoCodeStyle,
                    color = DcsTextSilver
                )
            }
        }
    }
}

@Composable
private fun HeadersTab(record: TrafficRecordEntity, context: Context) {
    val reqHeaders = remember(record.requestHeadersJson) { parseHeadersMap(record.requestHeadersJson) }
    val respHeaders = remember(record.responseHeadersJson) { parseHeadersMap(record.responseHeadersJson) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = {
                        val combined = "Request Headers:\n${record.requestHeadersJson}\n\nResponse Headers:\n${record.responseHeadersJson}"
                        copyToClipboard(context, "Headers", combined)
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy Headers")
                }
            }
        }

        item {
            GlassCard {
                Text("Request Headers (${reqHeaders.size})", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                Spacer(modifier = Modifier.height(8.dp))
                if (reqHeaders.isEmpty()) {
                    Text(
                        text = if (record.isTlsMetadataOnly) "Encrypted TLS handshake — HTTP request headers unavailable." else "No request headers captured.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextMuted
                    )
                } else {
                    reqHeaders.forEach { (k, v) ->
                        DetailRow(k, v, if (v.contains("[REDACTED]")) DcsRedactedBadge else DcsTextPrimary)
                    }
                }
            }
        }

        item {
            GlassCard {
                Text("Response Headers (${respHeaders.size})", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
                Spacer(modifier = Modifier.height(8.dp))
                if (respHeaders.isEmpty()) {
                    Text(
                        text = if (record.isTlsMetadataOnly) "Encrypted TLS connection — HTTP response headers unavailable." else "No response headers captured.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DcsTextMuted
                    )
                } else {
                    respHeaders.forEach { (k, v) ->
                        DetailRow(k, v, if (v.contains("[REDACTED]")) DcsRedactedBadge else DcsTextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun BodyTab(record: TrafficRecordEntity, context: Context) {
    var showRequestBody by remember { mutableStateOf(!record.requestBody.isNullOrBlank() && record.responseBody.isNullOrBlank()) }
    var rawMode by remember { mutableStateOf(false) }

    val activeBody = if (showRequestBody) record.requestBody else record.responseBody

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = { showRequestBody = true },
                modifier = Modifier.weight(1f)
            ) {
                Text("Request", color = if (showRequestBody) DcsCyan else DcsTextSilver)
            }
            OutlinedButton(
                onClick = { showRequestBody = false },
                modifier = Modifier.weight(1f)
            ) {
                Text("Response", color = if (!showRequestBody) DcsEmerald else DcsTextSilver)
            }
            OutlinedButton(onClick = { rawMode = !rawMode }) {
                Text(if (rawMode) "Tree" else "Raw")
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (activeBody.isNullOrBlank()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Body Unavailable", style = MaterialTheme.typography.titleSmall, color = DcsRedirect)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (record.isTlsMetadataOnly) {
                        "Encrypted HTTPS traffic was passed through without interception. Body content is never fabricated."
                    } else {
                        "This ${if (showRequestBody) "request" else "response"} does not contain a body payload."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = DcsTextSilver
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Content-Type: ${record.contentType ?: "text/plain"}",
                    style = MaterialTheme.typography.labelMedium,
                    color = DcsTextMuted
                )
                OutlinedButton(
                    onClick = { copyToClipboard(context, "Body", activeBody) }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy")
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            GlassCard(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                SelectionContainer {
                    val trimmed = activeBody.trim()
                    val isJson = !rawMode && (trimmed.startsWith("{") || trimmed.startsWith("["))
                    if (isJson) {
                        InteractiveJsonTree(rawJson = trimmed)
                    } else {
                        Text(
                            text = activeBody,
                            style = MonoCodeStyle,
                            color = DcsTextSilver
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String, valueColor: Color = DcsTextPrimary) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = DcsTextMuted)
        SelectionContainer {
            Text(text = value, style = MonoCodeStyle, color = valueColor)
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    cm?.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
}
