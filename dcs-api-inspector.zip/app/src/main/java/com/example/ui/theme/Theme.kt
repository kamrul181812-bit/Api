package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DcsDarkColorScheme = darkColorScheme(
    primary = DcsCyan,
    onPrimary = DcsVoidBg,
    primaryContainer = DcsSurfaceHighlight,
    onPrimaryContainer = DcsCyan,
    secondary = DcsEmerald,
    onSecondary = DcsVoidBg,
    secondaryContainer = DcsSurfaceElevated,
    onSecondaryContainer = DcsEmerald,
    tertiary = DcsTlsBadge,
    onTertiary = DcsVoidBg,
    background = DcsVoidBg,
    onBackground = DcsTextPrimary,
    surface = DcsSurface,
    onSurface = DcsTextPrimary,
    surfaceVariant = DcsSurfaceElevated,
    onSurfaceVariant = DcsTextSilver,
    outline = DcsGlassBorder,
    outlineVariant = DcsSurfaceHighlight,
    error = DcsServerError,
    onError = DcsTextPrimary
)

val DcsShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun DcsInspectorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DcsDarkColorScheme,
        typography = DcsTypography,
        shapes = DcsShapes,
        content = content
    )
}
