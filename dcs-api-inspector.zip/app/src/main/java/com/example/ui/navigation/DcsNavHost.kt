package com.example.ui.navigation

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.R
import com.example.data.repository.TrafficSortOption
import com.example.data.settings.CaptureRecordMode
import com.example.export.ExportFormat
import com.example.ui.screens.AccessControlScreen
import com.example.ui.screens.AppSelectionScreen
import com.example.ui.screens.AutoHighlightScreen
import com.example.ui.screens.BrowserSelectionScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DomainGroupsScreen
import com.example.ui.screens.EnhancedModeScreen
import com.example.ui.screens.ExportManagerScreen
import com.example.ui.screens.FilterScreen
import com.example.ui.screens.MenuActionId
import com.example.ui.screens.ProxyConfigScreen
import com.example.ui.screens.ReportServerScreen
import com.example.ui.screens.RequestInspectorScreen
import com.example.ui.screens.SecondaryProxyScreen
import com.example.ui.screens.SessionHistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SslDebuggingScreen
import com.example.ui.screens.TrafficManagementMenuSheet
import com.example.ui.screens.TrafficScreen
import com.example.ui.screens.VpnMonitoringScreen
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsSurface
import com.example.ui.theme.DcsSurfaceHighlight
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.GlassBackdrop
import com.example.ui.viewmodel.InspectorViewModel
import kotlinx.coroutines.launch

@Composable
fun DcsNavHost(
    viewModel: InspectorViewModel = viewModel()
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val status by viewModel.captureStatus.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val elapsedSeconds by viewModel.elapsedSeconds.collectAsStateWithLifecycle()
    val pagedTraffic by viewModel.pagedTraffic.collectAsStateWithLifecycle()
    val filteredTraffic by viewModel.filteredTraffic.collectAsStateWithLifecycle()
    val filterCriteria by viewModel.filterCriteria.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
    val selectedSessionFilterId by viewModel.selectedSessionFilterId.collectAsStateWithLifecycle()
    val domainGroups by viewModel.domainGroups.collectAsStateWithLifecycle()
    val browsers by viewModel.installedBrowsers.collectAsStateWithLifecycle()
    val apps by viewModel.installedApps.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val savedFilters by viewModel.savedFilters.collectAsStateWithLifecycle()
    val caStatus by viewModel.caStatus.collectAsStateWithLifecycle()
    val secondaryProxyState by viewModel.secondaryProxyTestState.collectAsStateWithLifecycle()
    val reportServerState by viewModel.reportServerState.collectAsStateWithLifecycle()
    val dbSizeBytes by viewModel.dbSizeBytes.collectAsStateWithLifecycle()
    val totalDbCount by viewModel.totalDbCount.collectAsStateWithLifecycle()

    var showMenuSheet by remember { mutableStateOf(false) }
    var showSortDialog by remember { mutableStateOf(false) }
    var pendingVpnRationaleIntent by remember { mutableStateOf<Intent?>(null) }
    var pendingLaunchUrlAfterVpn by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.events.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Proceed with monitoring whether notification granted or declined (service still runs gracefully)
        viewModel.startMonitoringAfterVpnGranted()
        pendingLaunchUrlAfterVpn?.let { url ->
            pendingLaunchUrlAfterVpn = null
            viewModel.launchSelectedBrowser(url)
        }
    }

    fun startWithNotificationCheck() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.startMonitoringAfterVpnGranted()
            pendingLaunchUrlAfterVpn?.let { url ->
                pendingLaunchUrlAfterVpn = null
                viewModel.launchSelectedBrowser(url)
            }
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startWithNotificationCheck()
        } else {
            pendingLaunchUrlAfterVpn = null
            scope.launch {
                snackbarHostState.showSnackbar("VPN permission declined. Local Proxy mode remains available.")
            }
        }
    }

    fun requestStartMonitoring(launchUrlAfter: String? = null) {
        pendingLaunchUrlAfterVpn = launchUrlAfter
        if (settings.recordMode == CaptureRecordMode.LOCAL_PROXY) {
            startWithNotificationCheck()
            return
        }
        val prepare = viewModel.prepareVpnIntent()
        if (prepare != null) {
            pendingVpnRationaleIntent = prepare
        } else {
            startWithNotificationCheck()
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination
    val showBottomBar = currentDest != null && (
        currentDest.hasRoute<AppRoute.Dashboard>() ||
            currentDest.hasRoute<AppRoute.Traffic>() ||
            currentDest.hasRoute<AppRoute.Browsers>() ||
            currentDest.hasRoute<AppRoute.History>()
        )

    GlassBackdrop(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = DcsSurface.copy(alpha = 0.96f),
                        contentColor = DcsTextPrimary
                    ) {
                        val navColors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DcsCyan,
                            selectedTextColor = DcsCyan,
                            indicatorColor = DcsSurfaceHighlight,
                            unselectedIconColor = DcsTextMuted,
                            unselectedTextColor = DcsTextMuted
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<AppRoute.Dashboard>() == true,
                            onClick = {
                                navController.navigate(AppRoute.Dashboard) {
                                    popUpTo(AppRoute.Dashboard) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                            label = { Text(stringResource(R.string.nav_dashboard)) },
                            colors = navColors,
                            modifier = Modifier.testTag("nav_dashboard")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<AppRoute.Traffic>() == true,
                            onClick = {
                                navController.navigate(AppRoute.Traffic) {
                                    popUpTo(AppRoute.Dashboard) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.SwapVert, contentDescription = "Traffic") },
                            label = { Text(stringResource(R.string.nav_traffic)) },
                            colors = navColors,
                            modifier = Modifier.testTag("nav_traffic")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<AppRoute.Browsers>() == true,
                            onClick = {
                                navController.navigate(AppRoute.Browsers) {
                                    popUpTo(AppRoute.Dashboard) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.Language, contentDescription = "Browsers") },
                            label = { Text(stringResource(R.string.nav_browsers)) },
                            colors = navColors,
                            modifier = Modifier.testTag("nav_browsers")
                        )
                        NavigationBarItem(
                            selected = currentDest?.hasRoute<AppRoute.History>() == true,
                            onClick = {
                                viewModel.refreshStorageSize()
                                navController.navigate(AppRoute.History) {
                                    popUpTo(AppRoute.Dashboard) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.History, contentDescription = "History") },
                            label = { Text(stringResource(R.string.nav_history)) },
                            colors = navColors,
                            modifier = Modifier.testTag("nav_history")
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = AppRoute.Splash,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                composable<AppRoute.Splash> {
                    SplashScreen(
                        onFinished = {
                            navController.navigate(AppRoute.Dashboard) {
                                popUpTo(AppRoute.Splash) { inclusive = true }
                            }
                        }
                    )
                }

                composable<AppRoute.Dashboard> {
                    DashboardScreen(
                        status = status,
                        settings = settings,
                        elapsedSeconds = elapsedSeconds,
                        onOpenMenu = { showMenuSheet = true },
                        onStartMonitoring = { requestStartMonitoring() },
                        onStopMonitoring = { viewModel.stopMonitoring() },
                        onPauseMonitoring = { viewModel.pauseMonitoring() },
                        onResumeMonitoring = { viewModel.resumeMonitoring() },
                        onRestartMonitoring = { viewModel.restartMonitoring() },
                        onClearSession = { viewModel.clearCurrentTraffic() },
                        onOpenTraffic = { navController.navigate(AppRoute.Traffic) },
                        onOpenBrowsers = { navController.navigate(AppRoute.Browsers) },
                        onLaunchBrowser = {
                            if (status.isMonitoring) {
                                viewModel.launchSelectedBrowser(settings.browserLaunchUrl)
                            } else {
                                requestStartMonitoring(settings.browserLaunchUrl)
                            }
                        },
                        onOpenVpnDetails = { navController.navigate(AppRoute.VpnMonitoring) },
                        onOpenSettings = { navController.navigate(AppRoute.Settings) }
                    )
                }

                composable<AppRoute.Traffic> {
                    TrafficScreen(
                        records = pagedTraffic,
                        totalFilteredCount = filteredTraffic.size,
                        isMonitoring = status.isMonitoring,
                        searchQuery = searchQuery,
                        filterCriteria = filterCriteria,
                        sortOption = sortOption,
                        highlightSettings = settings.autoHighlight,
                        selectedSessionFilterId = selectedSessionFilterId,
                        browserManager = viewModel.browserManager,
                        onOpenMenu = { showMenuSheet = true },
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        onClearTraffic = { viewModel.clearCurrentTraffic() },
                        onOpenFilter = { navController.navigate(AppRoute.Filter) },
                        onResetFilter = { viewModel.resetFilter() },
                        onSelectSort = { viewModel.setSortOption(it) },
                        onOpenGroupByHost = { navController.navigate(AppRoute.DomainGroups) },
                        onOpenExport = { navController.navigate(AppRoute.ExportManager()) },
                        onClearSessionFilter = { viewModel.setSessionFilter(null) },
                        onStartMonitoring = { requestStartMonitoring() },
                        onLoadMore = { viewModel.loadMoreTraffic() },
                        onRecordClick = { reqId -> navController.navigate(AppRoute.Inspector(reqId)) }
                    )
                }

                composable<AppRoute.Browsers> {
                    BrowserSelectionScreen(
                        browsers = browsers,
                        settings = settings,
                        status = status,
                        browserManager = viewModel.browserManager,
                        onRefreshBrowsers = { viewModel.refreshInstalledPackages() },
                        onSelectBrowser = { viewModel.selectBrowser(it) },
                        onStartMonitorAndLaunch = { url ->
                            viewModel.updateBrowserLaunchUrl(url)
                            if (status.isMonitoring) {
                                viewModel.launchSelectedBrowser(url)
                            } else {
                                requestStartMonitoring(url)
                            }
                        },
                        onLaunchBrowserOnly = { url -> viewModel.launchSelectedBrowser(url) },
                        onStopMonitoring = { viewModel.stopMonitoring() }
                    )
                }

                composable<AppRoute.History> {
                    SessionHistoryScreen(
                        sessions = sessions,
                        dbSizeBytes = dbSizeBytes,
                        totalDbCount = totalDbCount,
                        onSelectSession = { sid ->
                            viewModel.setSessionFilter(sid)
                            navController.navigate(AppRoute.Traffic)
                        },
                        onDeleteSession = { viewModel.deleteSession(it) },
                        onCleanupOld = { viewModel.cleanupOldTraffic(24) },
                        onClearAll = { viewModel.clearAllData() },
                        onExportSession = { navController.navigate(AppRoute.ExportManager()) }
                    )
                }

                composable<AppRoute.Inspector> { entry ->
                    val route = entry.toRoute<AppRoute.Inspector>()
                    val record by viewModel.observeRecord(route.requestId)
                        .collectAsStateWithLifecycle(initialValue = null)
                    RequestInspectorScreen(
                        record = record,
                        onBack = { navController.popBackStack() },
                        onExportRequest = { reqId ->
                            navController.navigate(AppRoute.ExportManager(preselectedRequestId = reqId))
                        }
                    )
                }

                composable<AppRoute.Filter> {
                    FilterScreen(
                        currentFilter = filterCriteria,
                        savedFilters = savedFilters,
                        onApply = { viewModel.applyFilter(it) },
                        onReset = { viewModel.resetFilter() },
                        onSaveFilter = { name, criteria -> viewModel.saveNamedFilter(name, criteria) },
                        onApplySaved = { viewModel.applySavedFilter(it) },
                        onDeleteSaved = { viewModel.deleteSavedFilter(it) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.DomainGroups> {
                    DomainGroupsScreen(
                        groups = domainGroups,
                        onBack = { navController.popBackStack() },
                        onRecordClick = { reqId -> navController.navigate(AppRoute.Inspector(reqId)) },
                        onExportDomain = { dom ->
                            navController.navigate(AppRoute.ExportManager(preselectedDomain = dom))
                        }
                    )
                }

                composable<AppRoute.AppSelection> {
                    AppSelectionScreen(
                        apps = apps,
                        settings = settings,
                        browserManager = viewModel.browserManager,
                        onSetScopeMode = { viewModel.setAppScopeMode(it) },
                        onToggleApp = { viewModel.toggleSelectedApp(it) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.VpnMonitoring> {
                    VpnMonitoringScreen(
                        status = status,
                        settings = settings,
                        elapsedSeconds = elapsedSeconds,
                        onSetRecordMode = { viewModel.setRecordMode(it) },
                        onStart = { requestStartMonitoring() },
                        onStop = { viewModel.stopMonitoring() },
                        onPause = { viewModel.pauseMonitoring() },
                        onResume = { viewModel.resumeMonitoring() },
                        onRestart = { viewModel.restartMonitoring() },
                        onClear = { viewModel.clearCurrentTraffic() },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.ProxyConfig> {
                    ProxyConfigScreen(
                        settings = settings,
                        status = status,
                        onSave = { enabled, port -> viewModel.updateLocalProxyConfig(enabled, port) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.EnhancedMode> {
                    EnhancedModeScreen(
                        settings = settings,
                        onUpdate = { e, u, d, t -> viewModel.updateEnhancedMode(e, u, d, t) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.SslDebugging> {
                    SslDebuggingScreen(
                        settings = settings,
                        caStatus = caStatus,
                        onUpdateSsl = { e, list, c -> viewModel.updateSslProxying(e, list, c) },
                        onGenerateCa = { viewModel.generateOrRefreshRootCa() },
                        onExportCa = { viewModel.exportRootCa() },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.AutoHighlight> {
                    AutoHighlightScreen(
                        settings = settings.autoHighlight,
                        onUpdate = { viewModel.updateAutoHighlight(it) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.SecondaryProxy> {
                    SecondaryProxyScreen(
                        settings = settings,
                        testState = secondaryProxyState,
                        onSave = { e, h, p -> viewModel.updateSecondaryProxy(e, h, p) },
                        onTest = { h, p -> viewModel.testSecondaryProxy(h, p) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.AccessControl> {
                    AccessControlScreen(
                        settings = settings,
                        isVpnRunning = status.isVpnRunning,
                        onUpdateAccessControl = { autoRedact, strictBody ->
                            viewModel.updateAccessControl(autoRedact, strictBody)
                        },
                        onOpenAppSelection = { navController.navigate(AppRoute.AppSelection) },
                        onOpenSslAllowlist = { navController.navigate(AppRoute.SslDebugging) },
                        onClearAllData = { viewModel.clearAllData() },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.ReportServer> {
                    ReportServerScreen(
                        settings = settings,
                        recordCount = filteredTraffic.size,
                        state = reportServerState,
                        onSave = { url, confirm -> viewModel.updateReportServer(url, confirm) },
                        onTest = { url -> viewModel.testReportServer(url) },
                        onUploadConfirmed = { url -> viewModel.uploadReportToServer(url) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.ExportManager> { entry ->
                    val route = entry.toRoute<AppRoute.ExportManager>()
                    ExportManagerScreen(
                        preselectedRequestId = route.preselectedRequestId,
                        preselectedDomain = route.preselectedDomain,
                        resolveRecords = { sc, reqId, dom ->
                            viewModel.resolveExportRecords(sc, reqId, dom)
                        },
                        generateExportText = { recs, fmt -> viewModel.generateExportText(recs, fmt) },
                        onShareExport = { recs, fmt -> viewModel.shareExport(recs, fmt) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<AppRoute.Settings> {
                    SettingsScreen(
                        onOpenProxyConfig = { navController.navigate(AppRoute.ProxyConfig) },
                        onOpenSsl = { navController.navigate(AppRoute.SslDebugging) },
                        onOpenAccessControl = { navController.navigate(AppRoute.AccessControl) },
                        onOpenEnhancedMode = { navController.navigate(AppRoute.EnhancedMode) },
                        onOpenReportServer = { navController.navigate(AppRoute.ReportServer) },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }

    if (showMenuSheet) {
        TrafficManagementMenuSheet(
            activeFilterCount = filterCriteria.activeCount(),
            sslEnabled = settings.sslProxyingEnabled,
            enhancedEnabled = settings.enhancedModeEnabled,
            proxyPort = settings.localProxyPort,
            secondaryProxyEnabled = settings.secondaryProxyEnabled,
            onDismiss = { showMenuSheet = false },
            onSelectAction = { action ->
                when (action) {
                    MenuActionId.FILTER -> navController.navigate(AppRoute.Filter)
                    MenuActionId.SEARCH -> navController.navigate(AppRoute.Traffic)
                    MenuActionId.SORT -> showSortDialog = true
                    MenuActionId.SHARE -> {
                        val recs = filteredTraffic
                        if (recs.isEmpty()) {
                            scope.launch { snackbarHostState.showSnackbar("No captured records to share yet.") }
                        } else {
                            viewModel.shareExport(recs, ExportFormat.JSON)
                        }
                    }
                    MenuActionId.EXPORT -> navController.navigate(AppRoute.ExportManager())
                    MenuActionId.GROUP_BY_HOST -> navController.navigate(AppRoute.DomainGroups)
                    MenuActionId.APP_SELECTION -> navController.navigate(AppRoute.AppSelection)
                    MenuActionId.PROXY_PORT -> navController.navigate(AppRoute.ProxyConfig)
                    MenuActionId.RECORD_MODE_VPN -> navController.navigate(AppRoute.VpnMonitoring)
                    MenuActionId.ENHANCED_MODE -> navController.navigate(AppRoute.EnhancedMode)
                    MenuActionId.SSL_PROXYING -> navController.navigate(AppRoute.SslDebugging)
                    MenuActionId.AUTO_HIGHLIGHT -> navController.navigate(AppRoute.AutoHighlight)
                    MenuActionId.SECONDARY_PROXY -> navController.navigate(AppRoute.SecondaryProxy)
                    MenuActionId.ACCESS_CONTROL -> navController.navigate(AppRoute.AccessControl)
                    MenuActionId.REPORT_SERVER -> navController.navigate(AppRoute.ReportServer)
                }
            }
        )
    }

    if (showSortDialog) {
        AlertDialog(
            onDismissRequest = { showSortDialog = false },
            containerColor = DcsSurface,
            title = { Text("Sort Traffic", color = DcsTextPrimary) },
            text = {
                Column {
                    TrafficSortOption.entries.forEach { opt ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setSortOption(opt)
                                    showSortDialog = false
                                }
                                .padding(vertical = 6.dp)
                        ) {
                            RadioButton(selected = opt == sortOption, onClick = {
                                viewModel.setSortOption(opt)
                                showSortDialog = false
                            })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(opt.label, color = DcsTextPrimary)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSortDialog = false }) { Text("Close", color = DcsCyan) }
            }
        )
    }

    pendingVpnRationaleIntent?.let { vpnIntent ->
        AlertDialog(
            onDismissRequest = {
                pendingVpnRationaleIntent = null
                pendingLaunchUrlAfterVpn = null
            },
            containerColor = DcsSurface,
            title = { Text(stringResource(R.string.vpn_permission_title), color = DcsCyan) },
            text = {
                Text(stringResource(R.string.vpn_permission_body), color = DcsTextSilver)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        pendingVpnRationaleIntent = null
                        vpnPermissionLauncher.launch(vpnIntent)
                    },
                    modifier = Modifier.testTag("grant_vpn_permission_button")
                ) {
                    Text("Grant VPN Access", color = DcsEmerald)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingVpnRationaleIntent = null
                    pendingLaunchUrlAfterVpn = null
                }) {
                    Text("Cancel", color = DcsTextMuted)
                }
            }
        )
    }
}
