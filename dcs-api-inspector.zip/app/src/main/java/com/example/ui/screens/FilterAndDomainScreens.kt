package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.db.SavedFilterEntity
import com.example.data.db.TrafficFilterCriteria
import com.example.data.repository.DomainGroupSummary
import com.example.ui.components.formatBytes
import com.example.ui.components.formatTimeOnly
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsSurface
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.MethodPill
import com.example.ui.theme.StatusPill
import com.example.ui.theme.statusCodeColor

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FilterScreen(
    currentFilter: TrafficFilterCriteria,
    savedFilters: List<SavedFilterEntity>,
    onApply: (TrafficFilterCriteria) -> Unit,
    onReset: () -> Unit,
    onSaveFilter: (String, TrafficFilterCriteria) -> Unit,
    onApplySaved: (SavedFilterEntity) -> Unit,
    onDeleteSaved: (Long) -> Unit,
    onBack: () -> Unit
) {
    var draft by remember(currentFilter) { mutableStateOf(currentFilter) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var filterNameInput by remember { mutableStateOf("") }

    val allMethods = listOf("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD", "CONNECT", "TLS", "DNS")
    val statusGroups = listOf("2xx", "3xx", "4xx", "5xx", "FAILED", "PENDING")
    val protocols = listOf("", "HTTP", "HTTPS", "DNS", "UDP", "TCP")
    val timeRanges = listOf(null to "All Time", 5 to "5 min", 15 to "15 min", 60 to "1 hour", 1440 to "24 hours")

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Traffic Filter", color = DcsTextPrimary) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            actions = {
                IconButton(
                    onClick = { showSaveDialog = true },
                    modifier = Modifier.testTag("save_filter_button")
                ) {
                    Icon(Icons.Default.BookmarkAdd, contentDescription = "Save Filter", tint = DcsEmerald)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            item {
                GlassCard {
                    Text("HTTP Method", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        allMethods.forEach { method ->
                            val selected = method in draft.methods
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    val next = draft.methods.toMutableSet()
                                    if (!next.add(method)) next.remove(method)
                                    draft = draft.copy(methods = next)
                                },
                                label = { Text(method) }
                            )
                        }
                    }
                }
            }

            item {
                GlassCard {
                    Text("Status Code & Outcome", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        statusGroups.forEach { st ->
                            val selected = st in draft.statusGroups
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    val next = draft.statusGroups.toMutableSet()
                                    if (!next.add(st)) next.remove(st)
                                    draft = draft.copy(statusGroups = next)
                                },
                                label = { Text(st) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                        draft = draft.copy(onlySuccessful = !draft.onlySuccessful, onlyFailed = false)
                    }) {
                        Checkbox(checked = draft.onlySuccessful, onCheckedChange = {
                            draft = draft.copy(onlySuccessful = it, onlyFailed = if (it) false else draft.onlyFailed)
                        })
                        Text("Successful Requests Only", color = DcsTextPrimary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                        draft = draft.copy(onlyFailed = !draft.onlyFailed, onlySuccessful = false)
                    }) {
                        Checkbox(checked = draft.onlyFailed, onCheckedChange = {
                            draft = draft.copy(onlyFailed = it, onlySuccessful = if (it) false else draft.onlySuccessful)
                        })
                        Text("Failed Requests Only", color = DcsTextPrimary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable {
                        draft = draft.copy(onlySelectedBrowser = !draft.onlySelectedBrowser)
                    }) {
                        Checkbox(checked = draft.onlySelectedBrowser, onCheckedChange = {
                            draft = draft.copy(onlySelectedBrowser = it)
                        })
                        Text("Selected Browser Traffic Only", color = DcsTextPrimary)
                    }
                }
            }

            item {
                GlassCard {
                    Text("Domain, Host, URL, App & Content-Type", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.domainQuery,
                        onValueChange = { draft = draft.copy(domainQuery = it) },
                        label = { Text("Domain contains") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("filter_domain_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.hostQuery,
                        onValueChange = { draft = draft.copy(hostQuery = it) },
                        label = { Text("Host contains") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.urlQuery,
                        onValueChange = { draft = draft.copy(urlQuery = it) },
                        label = { Text("Request URL contains") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.appPackage,
                        onValueChange = { draft = draft.copy(appPackage = it) },
                        label = { Text("Application name or package") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft.contentTypeQuery,
                        onValueChange = { draft = draft.copy(contentTypeQuery = it) },
                        label = { Text("Content-Type (e.g. json, html)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                GlassCard {
                    Text("Protocol & Time Range", style = MaterialTheme.typography.titleSmall, color = DcsCyan)
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        protocols.forEach { p ->
                            FilterChip(
                                selected = draft.protocol == p,
                                onClick = { draft = draft.copy(protocol = p) },
                                label = { Text(if (p.isEmpty()) "All Protocols" else p) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        timeRanges.forEach { (mins, label) ->
                            FilterChip(
                                selected = draft.timeRangeMinutes == mins,
                                onClick = { draft = draft.copy(timeRangeMinutes = mins) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            if (savedFilters.isNotEmpty()) {
                item {
                    GlassCard {
                        Text("Saved & Recent Filters", style = MaterialTheme.typography.titleSmall, color = DcsEmerald)
                        Spacer(modifier = Modifier.height(8.dp))
                        savedFilters.forEach { saved ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onApplySaved(saved)
                                        onBack()
                                    }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(saved.name, color = DcsTextPrimary, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        if (saved.isRecent) "Recent" else "Saved preset",
                                        color = DcsTextMuted,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                                IconButton(onClick = { onDeleteSaved(saved.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete filter", tint = DcsServerError)
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    draft = TrafficFilterCriteria()
                    onReset()
                },
                modifier = Modifier.weight(1f).testTag("reset_filter_button")
            ) {
                Text("Reset")
            }
            Button(
                onClick = {
                    onApply(draft)
                    onBack()
                },
                colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                modifier = Modifier.weight(1f).testTag("apply_filter_button")
            ) {
                Text("Apply Filter", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            containerColor = DcsSurface,
            title = { Text("Save Filter Preset", color = DcsTextPrimary) },
            text = {
                OutlinedTextField(
                    value = filterNameInput,
                    onValueChange = { filterNameInput = it },
                    label = { Text("Filter Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onSaveFilter(filterNameInput, draft)
                    showSaveDialog = false
                }) {
                    Text("Save", color = DcsEmerald)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DomainGroupsScreen(
    groups: List<DomainGroupSummary>,
    onBack: () -> Unit,
    onRecordClick: (String) -> Unit,
    onExportDomain: (String) -> Unit
) {
    var expandedDomains by remember { mutableStateOf(setOf<String>()) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("Group by Host", style = MaterialTheme.typography.titleLarge, color = DcsTextPrimary)
                    Text("${groups.size} active domain(s)", style = MaterialTheme.typography.labelSmall, color = DcsCyan)
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DcsCyan)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        if (groups.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Dns, contentDescription = null, tint = DcsTextMuted, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text("No captured hosts to group yet", color = DcsTextSilver)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(groups, key = { it.domain }) { group ->
                    val expanded = group.domain in expandedDomains
                    GlassCard(
                        glowAccent = if (expanded) DcsCyan else null,
                        onClick = {
                            expandedDomains = if (expanded) expandedDomains - group.domain else expandedDomains + group.domain
                        },
                        modifier = Modifier.fillMaxWidth().testTag("domain_group_${group.domain}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = if (expanded) "Collapse" else "Expand",
                                tint = DcsCyan
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = group.domain,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = DcsTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Total: ${group.totalRequests} • OK: ${group.successfulRequests} • Failed: ${group.failedRequests}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DcsTextSilver
                                )
                            }
                            IconButton(onClick = { onExportDomain(group.domain) }) {
                                Icon(Icons.Default.Download, contentDescription = "Export domain traffic", tint = DcsEmerald)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Traffic: ${formatBytes(group.totalTrafficBytes)}", style = MaterialTheme.typography.labelSmall, color = DcsCyan)
                            Text("Last: ${formatTimeOnly(group.lastActivityTimestamp)}", style = MaterialTheme.typography.labelSmall, color = DcsTextMuted)
                        }

                        AnimatedVisibility(visible = expanded) {
                            Column(
                                modifier = Modifier.padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                group.records.forEach { rec ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onRecordClick(rec.requestId) }
                                            .padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        MethodPill(method = rec.method)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = rec.path,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = DcsTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        StatusPill(
                                            text = if (rec.isFailed) "FAIL" else if (rec.statusCode > 0) "${rec.statusCode}" else rec.protocol,
                                            color = statusCodeColor(rec.statusCode, rec.isFailed)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
