package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.browser.BrowserManager
import com.example.classifier.AutoHighlightSettings
import com.example.classifier.DomainClassifier
import com.example.classifier.TrafficCategory
import com.example.data.db.TrafficFilterCriteria
import com.example.data.db.TrafficRecordEntity
import com.example.data.repository.TrafficSortOption
import com.example.ui.components.AppIconBadge
import com.example.ui.components.formatBytes
import com.example.ui.components.formatTimeOnly
import com.example.ui.components.highlightSearchMatches
import com.example.ui.theme.DcsAuthCategory
import com.example.ui.theme.DcsCyan
import com.example.ui.theme.DcsEmerald
import com.example.ui.theme.DcsPending
import com.example.ui.theme.DcsRedactedBadge
import com.example.ui.theme.DcsRedirect
import com.example.ui.theme.DcsServerError
import com.example.ui.theme.DcsSurface
import com.example.ui.theme.DcsTextMuted
import com.example.ui.theme.DcsTextPrimary
import com.example.ui.theme.DcsTextSilver
import com.example.ui.theme.DcsTlsBadge
import com.example.ui.theme.DcsVoidBg
import com.example.ui.theme.GlassCard
import com.example.ui.theme.MethodPill
import com.example.ui.theme.StatusPill
import com.example.ui.theme.statusCodeColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrafficScreen(
    records: List<TrafficRecordEntity>,
    totalFilteredCount: Int,
    isMonitoring: Boolean,
    searchQuery: String,
    filterCriteria: TrafficFilterCriteria,
    sortOption: TrafficSortOption,
    highlightSettings: AutoHighlightSettings,
    selectedSessionFilterId: String?,
    browserManager: BrowserManager,
    onOpenMenu: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onClearTraffic: () -> Unit,
    onOpenFilter: () -> Unit,
    onResetFilter: () -> Unit,
    onSelectSort: (TrafficSortOption) -> Unit,
    onOpenGroupByHost: () -> Unit,
    onOpenExport: () -> Unit,
    onClearSessionFilter: () -> Unit,
    onStartMonitoring: () -> Unit,
    onLoadMore: () -> Unit,
    onRecordClick: (String) -> Unit
) {
    var showSearchBar by remember { mutableStateOf(searchQuery.isNotEmpty()) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showSortDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Traffic",
                        style = MaterialTheme.typography.titleLarge,
                        color = DcsTextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusPill(
                        text = totalFilteredCount.toString(),
                        color = DcsCyan
                    )
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier.testTag("traffic_menu_button")
                ) {
                    Icon(Icons.Default.Menu, contentDescription = "Open Traffic Management Menu", tint = DcsCyan)
                }
            },
            actions = {
                IconButton(
                    onClick = { showSearchBar = !showSearchBar },
                    modifier = Modifier.testTag("traffic_search_toggle")
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search Traffic", tint = if (showSearchBar) DcsCyan else DcsTextSilver)
                }
                IconButton(
                    onClick = { showClearConfirm = true },
                    modifier = Modifier.testTag("traffic_clear_button")
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Clear Traffic", tint = DcsTextSilver)
                }
                IconButton(
                    onClick = { showMoreMenu = true },
                    modifier = Modifier.testTag("traffic_more_button")
                ) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More Traffic Options", tint = DcsTextSilver)
                }
                DropdownMenu(
                    expanded = showMoreMenu,
                    onDismissRequest = { showMoreMenu = false },
                    containerColor = DcsSurface
                ) {
                    DropdownMenuItem(
                        text = { Text("Filter (${filterCriteria.activeCount()})", color = DcsTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.FilterAlt, contentDescription = null, tint = DcsCyan) },
                        onClick = { showMoreMenu = false; onOpenFilter() }
                    )
                    DropdownMenuItem(
                        text = { Text("Sort: ${sortOption.label}", color = DcsTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Sort, contentDescription = null, tint = DcsCyan) },
                        onClick = { showMoreMenu = false; showSortDialog = true }
                    )
                    DropdownMenuItem(
                        text = { Text("Group by Host", color = DcsTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Dns, contentDescription = null, tint = DcsEmerald) },
                        onClick = { showMoreMenu = false; onOpenGroupByHost() }
                    )
                    DropdownMenuItem(
                        text = { Text("Export / Share", color = DcsTextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Download, contentDescription = null, tint = DcsEmerald) },
                        onClick = { showMoreMenu = false; onOpenExport() }
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )

        AnimatedVisibility(visible = showSearchBar) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search URL, domain, method, status, app, headers...") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = DcsCyan) },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (searchQuery.isNotEmpty()) {
                            Text(
                                text = "$totalFilteredCount",
                                style = MaterialTheme.typography.labelMedium,
                                color = DcsEmerald
                            )
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp)
                    .testTag("traffic_search_input")
            )
        }

        // Active filter / session banner
        if (!filterCriteria.isEmpty() || selectedSessionFilterId != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!filterCriteria.isEmpty()) {
                    StatusPill(text = "Filter Active (${filterCriteria.activeCount()})", color = DcsCyan)
                    TextButton(onClick = onResetFilter) {
                        Text("Reset", color = DcsServerError)
                    }
                }
                if (selectedSessionFilterId != null) {
                    StatusPill(text = "Historical Session", color = DcsRedirect)
                    TextButton(onClick = onClearSessionFilter) {
                        Text("Show All", color = DcsCyan)
                    }
                }
            }
        }

        if (records.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(28.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Radar,
                    contentDescription = "No traffic yet",
                    tint = DcsCyan.copy(alpha = 0.7f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = if (isMonitoring) "Listening for Real Network Traffic..." else "No Captured Traffic",
                    style = MaterialTheme.typography.titleLarge,
                    color = DcsTextPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isMonitoring) {
                        "Open your selected browser or make HTTP/HTTPS requests to see real-time packets appear automatically."
                    } else {
                        "Start VPN or Local Proxy monitoring, then browse any site to inspect live connections."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = DcsTextSilver
                )
                if (!isMonitoring) {
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = onStartMonitoring,
                        colors = ButtonDefaults.buttonColors(containerColor = DcsCyan, contentColor = DcsVoidBg),
                        modifier = Modifier.testTag("empty_traffic_start_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Monitoring", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("traffic_lazy_list"),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(records, key = { it.requestId }) { rec ->
                    TrafficListItem(
                        record = rec,
                        searchQuery = searchQuery,
                        highlightSettings = highlightSettings,
                        browserManager = browserManager,
                        onClick = { onRecordClick(rec.requestId) }
                    )
                }

                if (records.size < totalFilteredCount) {
                    item {
                        OutlinedButton(
                            onClick = onLoadMore,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Text("Load More (${totalFilteredCount - records.size} remaining)")
                        }
                    }
                }
            }
        }
    }

    if (showSortDialog) {
        AlertDialog(
            onDismissRequest = { showSortDialog = false },
            containerColor = DcsSurface,
            title = { Text("Sort Traffic", color = DcsTextPrimary) },
            text = {
                Column {
                    TrafficSortOption.entries.forEach { option ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectSort(option)
                                    showSortDialog = false
                                }
                                .padding(vertical = 6.dp)
                        ) {
                            RadioButton(
                                selected = option == sortOption,
                                onClick = {
                                    onSelectSort(option)
                                    showSortDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(option.label, color = DcsTextPrimary)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSortDialog = false }) { Text("Close", color = DcsCyan) }
            }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = DcsSurface,
            title = { Text("Clear Captured Traffic?", color = DcsTextPrimary) },
            text = { Text("This deletes the traffic entries from the current view/session.", color = DcsTextSilver) },
            confirmButton = {
                TextButton(onClick = {
                    showClearConfirm = false
                    onClearTraffic()
                }) {
                    Text("Clear", color = DcsServerError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel", color = DcsTextSilver)
                }
            }
        )
    }
}

@Composable
fun TrafficListItem(
    record: TrafficRecordEntity,
    searchQuery: String,
    highlightSettings: AutoHighlightSettings,
    browserManager: BrowserManager,
    onClick: () -> Unit
) {
    val iconBitmap = remember(record.packageName) { browserManager.getAppIcon(record.packageName) }
    val statusColor = statusCodeColor(record.statusCode, record.isFailed)
    val category = remember(record.category) {
        runCatching { TrafficCategory.valueOf(record.category) }.getOrDefault(TrafficCategory.OTHER)
    }
    val highlights = remember(record, highlightSettings) {
        DomainClassifier.evaluateHighlights(
            statusCode = record.statusCode,
            isFailed = record.isFailed,
            category = category,
            contentType = record.contentType,
            durationMs = record.durationMs,
            responseSize = record.responseSize,
            rules = highlightSettings
        )
    }
    val glowColor = when {
        record.isFailed || record.statusCode >= 500 -> DcsServerError
        category == TrafficCategory.AUTH || category == TrafficCategory.OTP -> DcsAuthCategory
        record.isSelectedBrowser -> DcsCyan
        else -> null
    }

    GlassCard(
        glowAccent = glowColor,
        contentPadding = PaddingValues(12.dp),
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("traffic_item_${record.sequenceNumber}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIconBadge(bitmap = iconBitmap, contentDescription = record.appName, size = 28.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "#${record.sequenceNumber} • ${record.appName}",
                style = MaterialTheme.typography.labelMedium,
                color = if (record.isSelectedBrowser) DcsCyan else DcsTextSilver,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (record.isSelectedBrowser) {
                StatusPill(text = "Browser", color = DcsCyan)
                Spacer(modifier = Modifier.width(4.dp))
            }
            if (record.isTlsMetadataOnly) {
                Icon(Icons.Default.Lock, contentDescription = "Encrypted TLS metadata-only", tint = DcsTlsBadge, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
            }
            if (record.redactedCount > 0) {
                Icon(Icons.Default.Shield, contentDescription = "Redacted secrets", tint = DcsRedactedBadge, modifier = Modifier.size(14.dp))
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MethodPill(method = record.method)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = highlightSearchMatches(record.url, searchQuery),
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = DcsTextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val statusLabel = when {
                    record.isFailed -> "FAILED"
                    record.isPending -> "PENDING"
                    record.statusCode > 0 -> "${record.statusCode} ${record.statusMessage}".trim()
                    else -> record.protocol
                }
                StatusPill(text = statusLabel, color = statusColor)

                highlights.take(2).forEach { tag ->
                    val tagColor = when {
                        tag.contains("Auth") || tag.contains("OTP") -> DcsAuthCategory
                        tag.contains("JSON") -> DcsEmerald
                        tag.contains("Slow") -> DcsRedirect
                        tag.contains("Redirect") -> DcsRedirect
                        else -> DcsTextSilver
                    }
                    StatusPill(text = tag, color = tagColor)
                }
            }

            Text(
                text = "${formatTimeOnly(record.timestamp)} | ${formatBytes(record.requestSize + record.responseSize)}",
                style = MaterialTheme.typography.labelSmall,
                color = DcsTextMuted
            )
        }
    }
}
