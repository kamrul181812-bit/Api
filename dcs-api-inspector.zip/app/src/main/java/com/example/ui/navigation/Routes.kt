package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed interface AppRoute {
    @Serializable data object Splash : AppRoute
    @Serializable data object Dashboard : AppRoute
    @Serializable data object Traffic : AppRoute
    @Serializable data object Browsers : AppRoute
    @Serializable data object History : AppRoute
    @Serializable data class Inspector(val requestId: String) : AppRoute
    @Serializable data object Filter : AppRoute
    @Serializable data object DomainGroups : AppRoute
    @Serializable data object AppSelection : AppRoute
    @Serializable data object VpnMonitoring : AppRoute
    @Serializable data object ProxyConfig : AppRoute
    @Serializable data object EnhancedMode : AppRoute
    @Serializable data object SslDebugging : AppRoute
    @Serializable data object AutoHighlight : AppRoute
    @Serializable data object SecondaryProxy : AppRoute
    @Serializable data object AccessControl : AppRoute
    @Serializable data object ReportServer : AppRoute
    @Serializable data class ExportManager(
        val preselectedRequestId: String? = null,
        val preselectedDomain: String? = null
    ) : AppRoute
    @Serializable data object Settings : AppRoute
}
