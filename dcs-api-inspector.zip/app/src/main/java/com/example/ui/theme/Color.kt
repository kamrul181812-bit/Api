package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Core Palette (DARK CYBER SECURITY - DCS API INSPECTOR)
val DcsCyan = Color(0xFF00E5FF)
val DcsCyanDim = Color(0xFF00A3B8)
val DcsEmerald = Color(0xFF00FF9D)
val DcsEmeraldDim = Color(0xFF00B871)

// Obsidian & Dark Glass Surfaces
val DcsVoidBg = Color(0xFF0B0F14)
val DcsSurface = Color(0xFF171C24)
val DcsSurfaceElevated = Color(0xFF1D2430)
val DcsSurfaceHighlight = Color(0xFF232C3B)
val DcsGlassBorder = Color(0xFF2B3648)
val DcsGlassBorderGlow = Color(0x4D00E5FF)

// Typography Colors
val DcsTextPrimary = Color(0xFFF3F7FC)
val DcsTextSilver = Color(0xFFC5D0DF)
val DcsTextMuted = Color(0xFF7D8B9F)

// Semantic HTTP & Telemetry Colors
val DcsSuccess = Color(0xFF00FF9D)
val DcsRedirect = Color(0xFFFFB300)
val DcsClientError = Color(0xFFFF7043)
val DcsServerError = Color(0xFFFF3D71)
val DcsPending = Color(0xFF00E5FF)
val DcsTlsBadge = Color(0xFF9D7BFF)
val DcsRedactedBadge = Color(0xFFFFC857)
val DcsAuthCategory = Color(0xFFFF6EC7)
