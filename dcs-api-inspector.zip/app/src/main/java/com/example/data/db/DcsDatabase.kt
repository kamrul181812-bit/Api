package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CaptureSessionEntity::class,
        TrafficRecordEntity::class,
        SavedFilterEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class DcsDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao
    abstract fun trafficDao(): TrafficDao
    abstract fun savedFilterDao(): SavedFilterDao

    companion object {
        @Volatile
        private var INSTANCE: DcsDatabase? = null

        fun getInstance(context: Context): DcsDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DcsDatabase::class.java,
                    "dcs_api_inspector.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
