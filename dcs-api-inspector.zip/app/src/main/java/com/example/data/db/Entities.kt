package com.example.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "capture_sessions")
data class CaptureSessionEntity(
    @PrimaryKey val sessionId: String,
    val title: String,
    val mode: String, // "VPN" or "PROXY" or "VPN+PROXY"
    val selectedBrowserPackage: String?,
    val selectedBrowserName: String?,
    val appScopeMode: String, // "SELECTED_APPS" or "ALL_APPS"
    val startedAt: Long,
    val endedAt: Long? = null,
    val isActive: Boolean = true,
    val totalRequests: Int = 0,
    val totalConnections: Int = 0,
    val bytesUploaded: Long = 0L,
    val bytesDownloaded: Long = 0L
)

@Entity(
    tableName = "traffic_records",
    indices = [
        Index(value = ["sessionId"]),
        Index(value = ["domain"]),
        Index(value = ["timestamp"]),
        Index(value = ["method"]),
        Index(value = ["statusCode"])
    ]
)
data class TrafficRecordEntity(
    @PrimaryKey val requestId: String,
    val sessionId: String,
    val sequenceNumber: Int,
    val timestamp: Long,
    val responseTimestamp: Long? = null,
    val durationMs: Long = 0L,
    val method: String,
    val protocol: String, // HTTP, HTTPS, TLS, DNS, UDP, TCP
    val httpVersion: String, // HTTP/1.1, TLSv1.3, etc.
    val url: String, // Redacted URL
    val domain: String,
    val host: String,
    val path: String,
    val queryParamsJson: String = "{}", // Redacted query params map JSON
    val statusCode: Int = 0, // 0 = pending or metadata-only
    val statusMessage: String = "",
    val remoteAddress: String,
    val remotePort: Int,
    val localPort: Int = 0,
    val connectionType: String, // "VPN TUN", "Local Proxy", "Secondary Proxy"
    val appName: String,
    val packageName: String?,
    val isSelectedBrowser: Boolean = false,
    val requestSize: Long = 0L,
    val responseSize: Long = 0L,
    val contentType: String? = null,
    val requestHeadersJson: String = "{}", // Redacted headers JSON
    val responseHeadersJson: String = "{}", // Redacted headers JSON
    val requestBody: String? = null, // Redacted body or null if unavailable
    val responseBody: String? = null, // Redacted body or null if unavailable
    val rawRequestInfo: String = "",
    val rawResponseInfo: String = "",
    val isBodyAvailable: Boolean = false,
    val isTlsMetadataOnly: Boolean = false,
    val isSslProxied: Boolean = false,
    val isPending: Boolean = false,
    val isFailed: Boolean = false,
    val errorMessage: String? = null,
    val limitationNote: String? = null,
    val category: String = "OTHER", // TrafficCategory name
    val redactedCount: Int = 0,
    val timingBreakdown: String = "" // e.g. "DNS: 12ms | Connect: 28ms | TTFB: 84ms | Total: 112ms"
)

@Serializable
data class TrafficFilterCriteria(
    val methods: Set<String> = emptySet(),
    val statusGroups: Set<String> = emptySet(), // "2xx", "3xx", "4xx", "5xx", "FAILED", "PENDING"
    val domainQuery: String = "",
    val hostQuery: String = "",
    val appPackage: String = "",
    val protocol: String = "",
    val contentTypeQuery: String = "",
    val urlQuery: String = "",
    val timeRangeMinutes: Int? = null, // null = all time
    val onlySuccessful: Boolean = false,
    val onlyFailed: Boolean = false,
    val onlySelectedBrowser: Boolean = false
) {
    fun isEmpty(): Boolean =
        methods.isEmpty() &&
            statusGroups.isEmpty() &&
            domainQuery.isBlank() &&
            hostQuery.isBlank() &&
            appPackage.isBlank() &&
            protocol.isBlank() &&
            contentTypeQuery.isBlank() &&
            urlQuery.isBlank() &&
            timeRangeMinutes == null &&
            !onlySuccessful &&
            !onlyFailed &&
            !onlySelectedBrowser

    fun activeCount(): Int {
        var c = 0
        if (methods.isNotEmpty()) c++
        if (statusGroups.isNotEmpty()) c++
        if (domainQuery.isNotBlank()) c++
        if (hostQuery.isNotBlank()) c++
        if (appPackage.isNotBlank()) c++
        if (protocol.isNotBlank()) c++
        if (contentTypeQuery.isNotBlank()) c++
        if (urlQuery.isNotBlank()) c++
        if (timeRangeMinutes != null) c++
        if (onlySuccessful) c++
        if (onlyFailed) c++
        if (onlySelectedBrowser) c++
        return c
    }
}

@Entity(tableName = "saved_filters")
data class SavedFilterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val criteriaJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val isRecent: Boolean = false
)
