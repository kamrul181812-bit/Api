package com.example.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.classifier.AutoHighlightSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dcs_inspector_settings")

enum class CaptureRecordMode(val label: String, val description: String) {
    VPN("VPN Capture", "On-device VpnService TUN packet capture with per-app routing"),
    LOCAL_PROXY("Local Proxy", "Loopback HTTP/CONNECT proxy on 127.0.0.1 for explicit test clients"),
    VPN_AND_PROXY("VPN + Local Proxy", "Run local VPN capture alongside explicit loopback HTTP proxy")
}

enum class AppScopeMode(val label: String) {
    SELECTED_APPS("Selected Apps Only"),
    ALL_APPS("All Supported Applications")
}

data class InspectorSettings(
    val selectedBrowserPackage: String? = null,
    val selectedBrowserName: String? = null,
    val browserLaunchUrl: String = "https://httpbin.org/get",
    val selectedAppPackages: Set<String> = emptySet(),
    val appScopeMode: AppScopeMode = AppScopeMode.ALL_APPS,
    val recordMode: CaptureRecordMode = CaptureRecordMode.VPN,
    val localProxyEnabled: Boolean = false,
    val localProxyPort: Int = 9000,
    val enhancedModeEnabled: Boolean = true,
    val enhancedUidAttribution: Boolean = true,
    val enhancedDnsCorrelation: Boolean = true,
    val enhancedTimingBreakdown: Boolean = true,
    val sslProxyingEnabled: Boolean = false,
    val sslAllowlistDomains: Set<String> = setOf("localhost", "10.0.2.2"),
    val customCaInstalledNoteConfirmed: Boolean = false,
    val autoHighlight: AutoHighlightSettings = AutoHighlightSettings(),
    val secondaryProxyEnabled: Boolean = false,
    val secondaryProxyHost: String = "",
    val secondaryProxyPort: Int = 8080,
    val autoRedactSensitiveData: Boolean = true,
    val strictAllowlistOnlyForBody: Boolean = false,
    val reportServerUrl: String = "",
    val confirmBeforeReportUpload: Boolean = true
)

class SettingsManager(private val context: Context) {

    private object Keys {
        val SELECTED_BROWSER_PKG = stringPreferencesKey("selected_browser_pkg")
        val SELECTED_BROWSER_NAME = stringPreferencesKey("selected_browser_name")
        val BROWSER_LAUNCH_URL = stringPreferencesKey("browser_launch_url")
        val SELECTED_APP_PACKAGES = stringSetPreferencesKey("selected_app_packages")
        val APP_SCOPE_MODE = stringPreferencesKey("app_scope_mode")
        val RECORD_MODE = stringPreferencesKey("record_mode")
        val LOCAL_PROXY_ENABLED = booleanPreferencesKey("local_proxy_enabled")
        val LOCAL_PROXY_PORT = intPreferencesKey("local_proxy_port")
        val ENHANCED_MODE_ENABLED = booleanPreferencesKey("enhanced_mode_enabled")
        val ENHANCED_UID = booleanPreferencesKey("enhanced_uid")
        val ENHANCED_DNS = booleanPreferencesKey("enhanced_dns")
        val ENHANCED_TIMING = booleanPreferencesKey("enhanced_timing")
        val SSL_PROXYING_ENABLED = booleanPreferencesKey("ssl_proxying_enabled")
        val SSL_ALLOWLIST_DOMAINS = stringSetPreferencesKey("ssl_allowlist_domains")
        val SSL_CA_CONFIRMED = booleanPreferencesKey("ssl_ca_confirmed")
        val HL_SUCCESS = booleanPreferencesKey("hl_success")
        val HL_ERRORS = booleanPreferencesKey("hl_errors")
        val HL_REDIRECTS = booleanPreferencesKey("hl_redirects")
        val HL_JSON = booleanPreferencesKey("hl_json")
        val HL_AUTH_OTP = booleanPreferencesKey("hl_auth_otp")
        val HL_SLOW = booleanPreferencesKey("hl_slow")
        val HL_SLOW_MS = longPreferencesKey("hl_slow_ms")
        val HL_LARGE = booleanPreferencesKey("hl_large")
        val HL_LARGE_BYTES = longPreferencesKey("hl_large_bytes")
        val SECONDARY_PROXY_ENABLED = booleanPreferencesKey("secondary_proxy_enabled")
        val SECONDARY_PROXY_HOST = stringPreferencesKey("secondary_proxy_host")
        val SECONDARY_PROXY_PORT = intPreferencesKey("secondary_proxy_port")
        val AUTO_REDACT = booleanPreferencesKey("auto_redact")
        val STRICT_ALLOWLIST_BODY = booleanPreferencesKey("strict_allowlist_body")
        val REPORT_SERVER_URL = stringPreferencesKey("report_server_url")
        val CONFIRM_REPORT_UPLOAD = booleanPreferencesKey("confirm_report_upload")
    }

    val settingsFlow: Flow<InspectorSettings> = context.dataStore.data.map { prefs ->
        InspectorSettings(
            selectedBrowserPackage = prefs[Keys.SELECTED_BROWSER_PKG],
            selectedBrowserName = prefs[Keys.SELECTED_BROWSER_NAME],
            browserLaunchUrl = prefs[Keys.BROWSER_LAUNCH_URL] ?: "https://httpbin.org/get",
            selectedAppPackages = prefs[Keys.SELECTED_APP_PACKAGES] ?: emptySet(),
            appScopeMode = prefs[Keys.APP_SCOPE_MODE]?.let {
                runCatching { AppScopeMode.valueOf(it) }.getOrNull()
            } ?: AppScopeMode.ALL_APPS,
            recordMode = prefs[Keys.RECORD_MODE]?.let {
                runCatching { CaptureRecordMode.valueOf(it) }.getOrNull()
            } ?: CaptureRecordMode.VPN,
            localProxyEnabled = prefs[Keys.LOCAL_PROXY_ENABLED] ?: false,
            localProxyPort = prefs[Keys.LOCAL_PROXY_PORT] ?: 9000,
            enhancedModeEnabled = prefs[Keys.ENHANCED_MODE_ENABLED] ?: true,
            enhancedUidAttribution = prefs[Keys.ENHANCED_UID] ?: true,
            enhancedDnsCorrelation = prefs[Keys.ENHANCED_DNS] ?: true,
            enhancedTimingBreakdown = prefs[Keys.ENHANCED_TIMING] ?: true,
            sslProxyingEnabled = prefs[Keys.SSL_PROXYING_ENABLED] ?: false,
            sslAllowlistDomains = prefs[Keys.SSL_ALLOWLIST_DOMAINS] ?: setOf("localhost", "10.0.2.2"),
            customCaInstalledNoteConfirmed = prefs[Keys.SSL_CA_CONFIRMED] ?: false,
            autoHighlight = AutoHighlightSettings(
                highlightSuccess = prefs[Keys.HL_SUCCESS] ?: true,
                highlightErrors = prefs[Keys.HL_ERRORS] ?: true,
                highlightRedirects = prefs[Keys.HL_REDIRECTS] ?: true,
                highlightJson = prefs[Keys.HL_JSON] ?: true,
                highlightAuthOtp = prefs[Keys.HL_AUTH_OTP] ?: true,
                highlightSlow = prefs[Keys.HL_SLOW] ?: true,
                slowThresholdMs = prefs[Keys.HL_SLOW_MS] ?: 1200L,
                highlightLarge = prefs[Keys.HL_LARGE] ?: true,
                largeThresholdBytes = prefs[Keys.HL_LARGE_BYTES] ?: (100 * 1024L)
            ),
            secondaryProxyEnabled = prefs[Keys.SECONDARY_PROXY_ENABLED] ?: false,
            secondaryProxyHost = prefs[Keys.SECONDARY_PROXY_HOST] ?: "",
            secondaryProxyPort = prefs[Keys.SECONDARY_PROXY_PORT] ?: 8080,
            autoRedactSensitiveData = prefs[Keys.AUTO_REDACT] ?: true,
            strictAllowlistOnlyForBody = prefs[Keys.STRICT_ALLOWLIST_BODY] ?: false,
            reportServerUrl = prefs[Keys.REPORT_SERVER_URL] ?: "",
            confirmBeforeReportUpload = prefs[Keys.CONFIRM_REPORT_UPLOAD] ?: true
        )
    }

    suspend fun setSelectedBrowser(packageName: String?, appName: String?) {
        context.dataStore.edit { prefs ->
            if (packageName == null) {
                prefs.remove(Keys.SELECTED_BROWSER_PKG)
                prefs.remove(Keys.SELECTED_BROWSER_NAME)
            } else {
                prefs[Keys.SELECTED_BROWSER_PKG] = packageName
                prefs[Keys.SELECTED_BROWSER_NAME] = appName ?: packageName
            }
        }
    }

    suspend fun setBrowserLaunchUrl(url: String) {
        context.dataStore.edit { it[Keys.BROWSER_LAUNCH_URL] = url }
    }

    suspend fun setSelectedAppPackages(packages: Set<String>) {
        context.dataStore.edit { it[Keys.SELECTED_APP_PACKAGES] = packages }
    }

    suspend fun setAppScopeMode(mode: AppScopeMode) {
        context.dataStore.edit { it[Keys.APP_SCOPE_MODE] = mode.name }
    }

    suspend fun setRecordMode(mode: CaptureRecordMode) {
        context.dataStore.edit { it[Keys.RECORD_MODE] = mode.name }
    }

    suspend fun setLocalProxy(enabled: Boolean, port: Int) {
        context.dataStore.edit {
            it[Keys.LOCAL_PROXY_ENABLED] = enabled
            it[Keys.LOCAL_PROXY_PORT] = port
        }
    }

    suspend fun setEnhancedMode(enabled: Boolean, uid: Boolean, dns: Boolean, timing: Boolean) {
        context.dataStore.edit {
            it[Keys.ENHANCED_MODE_ENABLED] = enabled
            it[Keys.ENHANCED_UID] = uid
            it[Keys.ENHANCED_DNS] = dns
            it[Keys.ENHANCED_TIMING] = timing
        }
    }

    suspend fun setSslProxying(enabled: Boolean, allowlist: Set<String>, confirmed: Boolean) {
        context.dataStore.edit {
            it[Keys.SSL_PROXYING_ENABLED] = enabled
            it[Keys.SSL_ALLOWLIST_DOMAINS] = allowlist
            it[Keys.SSL_CA_CONFIRMED] = confirmed
        }
    }

    suspend fun setAutoHighlight(settings: AutoHighlightSettings) {
        context.dataStore.edit {
            it[Keys.HL_SUCCESS] = settings.highlightSuccess
            it[Keys.HL_ERRORS] = settings.highlightErrors
            it[Keys.HL_REDIRECTS] = settings.highlightRedirects
            it[Keys.HL_JSON] = settings.highlightJson
            it[Keys.HL_AUTH_OTP] = settings.highlightAuthOtp
            it[Keys.HL_SLOW] = settings.highlightSlow
            it[Keys.HL_SLOW_MS] = settings.slowThresholdMs
            it[Keys.HL_LARGE] = settings.highlightLarge
            it[Keys.HL_LARGE_BYTES] = settings.largeThresholdBytes
        }
    }

    suspend fun setSecondaryProxy(enabled: Boolean, host: String, port: Int) {
        context.dataStore.edit {
            it[Keys.SECONDARY_PROXY_ENABLED] = enabled
            it[Keys.SECONDARY_PROXY_HOST] = host
            it[Keys.SECONDARY_PROXY_PORT] = port
        }
    }

    suspend fun setAccessControl(autoRedact: Boolean, strictAllowlistBody: Boolean) {
        context.dataStore.edit {
            it[Keys.AUTO_REDACT] = autoRedact
            it[Keys.STRICT_ALLOWLIST_BODY] = strictAllowlistBody
        }
    }

    suspend fun setReportServer(url: String, requireConfirmation: Boolean) {
        context.dataStore.edit {
            it[Keys.REPORT_SERVER_URL] = url
            it[Keys.CONFIRM_REPORT_UPLOAD] = requireConfirmation
        }
    }
}
