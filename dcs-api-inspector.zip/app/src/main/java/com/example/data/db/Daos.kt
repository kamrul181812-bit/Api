package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
    @Query("SELECT * FROM capture_sessions ORDER BY startedAt DESC")
    fun observeAllSessions(): Flow<List<CaptureSessionEntity>>

    @Query("SELECT * FROM capture_sessions WHERE sessionId = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: String): CaptureSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: CaptureSessionEntity)

    @Update
    suspend fun updateSession(session: CaptureSessionEntity)

    @Query("UPDATE capture_sessions SET isActive = 0, endedAt = :endedAt WHERE isActive = 1")
    suspend fun closeAllActiveSessions(endedAt: Long = System.currentTimeMillis())

    @Query("UPDATE capture_sessions SET totalRequests = totalRequests + :reqDelta, totalConnections = totalConnections + :connDelta, bytesUploaded = bytesUploaded + :upDelta, bytesDownloaded = bytesDownloaded + :downDelta WHERE sessionId = :sessionId")
    suspend fun incrementCounters(
        sessionId: String,
        reqDelta: Int,
        connDelta: Int,
        upDelta: Long,
        downDelta: Long
    )

    @Query("DELETE FROM capture_sessions WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: String)

    @Query("DELETE FROM capture_sessions")
    suspend fun deleteAllSessions()
}

@Dao
interface TrafficDao {
    @Query("SELECT * FROM traffic_records ORDER BY timestamp DESC, sequenceNumber DESC LIMIT :limit")
    fun observeRecentRecords(limit: Int): Flow<List<TrafficRecordEntity>>

    @Query("SELECT * FROM traffic_records WHERE sessionId = :sessionId ORDER BY timestamp DESC, sequenceNumber DESC LIMIT :limit")
    fun observeSessionRecords(sessionId: String, limit: Int): Flow<List<TrafficRecordEntity>>

    @Query("SELECT * FROM traffic_records WHERE requestId = :requestId LIMIT 1")
    fun observeRecordById(requestId: String): Flow<TrafficRecordEntity?>

    @Query("SELECT * FROM traffic_records WHERE requestId = :requestId LIMIT 1")
    suspend fun getRecordById(requestId: String): TrafficRecordEntity?

    @Query("SELECT * FROM traffic_records ORDER BY timestamp DESC, sequenceNumber DESC")
    suspend fun getAllRecordsSnapshot(): List<TrafficRecordEntity>

    @Query("SELECT * FROM traffic_records WHERE sessionId = :sessionId ORDER BY timestamp DESC, sequenceNumber DESC")
    suspend fun getSessionRecordsSnapshot(sessionId: String): List<TrafficRecordEntity>

    @Query("SELECT COUNT(*) FROM traffic_records")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM traffic_records WHERE sessionId = :sessionId")
    fun observeSessionCount(sessionId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecord(record: TrafficRecordEntity)

    @Query("DELETE FROM traffic_records WHERE sessionId = :sessionId")
    suspend fun deleteBySession(sessionId: String)

    @Query("DELETE FROM traffic_records")
    suspend fun deleteAllRecords()

    @Query("DELETE FROM traffic_records WHERE timestamp < :olderThanTimestamp")
    suspend fun deleteOlderThan(olderThanTimestamp: Long): Int
}

@Dao
interface SavedFilterDao {
    @Query("SELECT * FROM saved_filters ORDER BY createdAt DESC LIMIT 20")
    fun observeFilters(): Flow<List<SavedFilterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFilter(filter: SavedFilterEntity)

    @Query("DELETE FROM saved_filters WHERE id = :id")
    suspend fun deleteFilter(id: Long)

    @Query("DELETE FROM saved_filters WHERE isRecent = 1")
    suspend fun clearRecentFilters()
}
