package com.example.data.repository

import android.content.Context
import com.example.data.db.CaptureSessionEntity
import com.example.data.db.DcsDatabase
import com.example.data.db.SavedFilterEntity
import com.example.data.db.TrafficFilterCriteria
import com.example.data.db.TrafficRecordEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.json.Json

enum class TrafficSortOption(val label: String) {
    NEWEST_FIRST("Newest First"),
    OLDEST_FIRST("Oldest First"),
    LARGEST_REQUEST("Largest Request"),
    LARGEST_RESPONSE("Largest Response"),
    HIGHEST_STATUS("Highest Status Code"),
    DOMAIN_NAME("Domain Name"),
    HTTP_METHOD("HTTP Method"),
    DURATION("Duration (Slowest)")
}

data class DomainGroupSummary(
    val domain: String,
    val totalRequests: Int,
    val successfulRequests: Int,
    val failedRequests: Int,
    val totalTrafficBytes: Long,
    val lastActivityTimestamp: Long,
    val records: List<TrafficRecordEntity>
)

class TrafficRepository(
    private val context: Context,
    private val db: DcsDatabase
) {
    private val sessionDao = db.sessionDao()
    private val trafficDao = db.trafficDao()
    private val filterDao = db.savedFilterDao()

    private val json = Json { ignoreUnknownKeys = true }

    fun observeSessions(): Flow<List<CaptureSessionEntity>> = sessionDao.observeAllSessions()

    fun observeRecentRecords(limit: Int = 500): Flow<List<TrafficRecordEntity>> =
        trafficDao.observeRecentRecords(limit)

    fun observeSessionRecords(sessionId: String, limit: Int = 500): Flow<List<TrafficRecordEntity>> =
        trafficDao.observeSessionRecords(sessionId, limit)

    fun observeRecordById(requestId: String): Flow<TrafficRecordEntity?> =
        trafficDao.observeRecordById(requestId)

    fun observeTotalCount(): Flow<Int> = trafficDao.observeTotalCount()

    fun observeSavedFilters(): Flow<List<SavedFilterEntity>> = filterDao.observeFilters()

    suspend fun startSession(session: CaptureSessionEntity) {
        sessionDao.closeAllActiveSessions(System.currentTimeMillis())
        sessionDao.insertSession(session)
    }

    suspend fun closeActiveSessions() {
        sessionDao.closeAllActiveSessions(System.currentTimeMillis())
    }

    suspend fun recordTraffic(record: TrafficRecordEntity, isNewConnection: Boolean) {
        trafficDao.upsertRecord(record)
        sessionDao.incrementCounters(
            sessionId = record.sessionId,
            reqDelta = 1,
            connDelta = if (isNewConnection) 1 else 0,
            upDelta = record.requestSize,
            downDelta = record.responseSize
        )
    }

    suspend fun updateTraffic(record: TrafficRecordEntity, addedUpBytes: Long = 0L, addedDownBytes: Long = 0L) {
        trafficDao.upsertRecord(record)
        if (addedUpBytes > 0L || addedDownBytes > 0L) {
            sessionDao.incrementCounters(
                sessionId = record.sessionId,
                reqDelta = 0,
                connDelta = 0,
                upDelta = addedUpBytes,
                downDelta = addedDownBytes
            )
        }
    }

    suspend fun clearSessionTraffic(sessionId: String) {
        trafficDao.deleteBySession(sessionId)
        val existing = sessionDao.getSessionById(sessionId)
        if (existing != null) {
            sessionDao.updateSession(
                existing.copy(
                    totalRequests = 0,
                    totalConnections = 0,
                    bytesUploaded = 0L,
                    bytesDownloaded = 0L
                )
            )
        }
    }

    suspend fun deleteSession(sessionId: String) {
        trafficDao.deleteBySession(sessionId)
        sessionDao.deleteSession(sessionId)
    }

    suspend fun clearAllTrafficAndSessions() {
        trafficDao.deleteAllRecords()
        sessionDao.deleteAllSessions()
    }

    suspend fun deleteTrafficOlderThanHours(hours: Int): Int {
        val cutoff = System.currentTimeMillis() - hours * 3600_000L
        return trafficDao.deleteOlderThan(cutoff)
    }

    suspend fun getAllRecordsSnapshot(): List<TrafficRecordEntity> = trafficDao.getAllRecordsSnapshot()

    suspend fun getSessionRecordsSnapshot(sessionId: String): List<TrafficRecordEntity> =
        trafficDao.getSessionRecordsSnapshot(sessionId)

    suspend fun saveFilter(name: String, criteria: TrafficFilterCriteria, isRecent: Boolean = false) {
        filterDao.insertFilter(
            SavedFilterEntity(
                name = name,
                criteriaJson = json.encodeToString(TrafficFilterCriteria.serializer(), criteria),
                isRecent = isRecent
            )
        )
    }

    suspend fun deleteSavedFilter(id: Long) = filterDao.deleteFilter(id)

    fun decodeFilterCriteria(criteriaJson: String): TrafficFilterCriteria? =
        runCatching { json.decodeFromString(TrafficFilterCriteria.serializer(), criteriaJson) }.getOrNull()

    fun getDatabaseSizeBytes(): Long {
        val dbFile = context.getDatabasePath("dcs_api_inspector.db")
        val walFile = context.getDatabasePath("dcs_api_inspector.db-wal")
        return (if (dbFile.exists()) dbFile.length() else 0L) +
            (if (walFile.exists()) walFile.length() else 0L)
    }

    companion object {
        fun applyFilterSearchAndSort(
            records: List<TrafficRecordEntity>,
            filter: TrafficFilterCriteria,
            searchQuery: String,
            sort: TrafficSortOption,
            nowMs: Long = System.currentTimeMillis()
        ): List<TrafficRecordEntity> {
            val q = searchQuery.trim().lowercase()
            val filtered = records.filter { rec ->
                val matchesMethod = filter.methods.isEmpty() || filter.methods.any { it.equals(rec.method, ignoreCase = true) }
                val matchesStatusGroup = filter.statusGroups.isEmpty() || filter.statusGroups.any { group ->
                    when (group) {
                        "2xx" -> rec.statusCode in 200..299 && !rec.isFailed
                        "3xx" -> rec.statusCode in 300..399
                        "4xx" -> rec.statusCode in 400..499
                        "5xx" -> rec.statusCode >= 500
                        "FAILED" -> rec.isFailed
                        "PENDING" -> rec.isPending
                        else -> false
                    }
                }
                val matchesDomain = filter.domainQuery.isBlank() || rec.domain.contains(filter.domainQuery, ignoreCase = true)
                val matchesHost = filter.hostQuery.isBlank() || rec.host.contains(filter.hostQuery, ignoreCase = true)
                val matchesApp = filter.appPackage.isBlank() ||
                    rec.packageName.equals(filter.appPackage, ignoreCase = true) ||
                    rec.appName.contains(filter.appPackage, ignoreCase = true)
                val matchesProtocol = filter.protocol.isBlank() || rec.protocol.equals(filter.protocol, ignoreCase = true)
                val matchesContentType = filter.contentTypeQuery.isBlank() ||
                    (rec.contentType?.contains(filter.contentTypeQuery, ignoreCase = true) == true)
                val matchesUrl = filter.urlQuery.isBlank() || rec.url.contains(filter.urlQuery, ignoreCase = true)
                val matchesTime = filter.timeRangeMinutes == null ||
                    (nowMs - rec.timestamp) <= filter.timeRangeMinutes * 60_000L
                val matchesSuccess = !filter.onlySuccessful || (rec.statusCode in 200..399 && !rec.isFailed)
                val matchesFailed = !filter.onlyFailed || (rec.isFailed || rec.statusCode >= 400)
                val matchesBrowser = !filter.onlySelectedBrowser || rec.isSelectedBrowser

                val matchesSearch = q.isEmpty() ||
                    rec.url.lowercase().contains(q) ||
                    rec.domain.lowercase().contains(q) ||
                    rec.path.lowercase().contains(q) ||
                    rec.method.lowercase().contains(q) ||
                    rec.statusCode.toString().contains(q) ||
                    rec.host.lowercase().contains(q) ||
                    rec.appName.lowercase().contains(q) ||
                    rec.requestHeadersJson.lowercase().contains(q) ||
                    rec.responseHeadersJson.lowercase().contains(q) ||
                    (rec.requestBody?.lowercase()?.contains(q) == true) ||
                    (rec.responseBody?.lowercase()?.contains(q) == true)

                matchesMethod &&
                    matchesStatusGroup &&
                    matchesDomain &&
                    matchesHost &&
                    matchesApp &&
                    matchesProtocol &&
                    matchesContentType &&
                    matchesUrl &&
                    matchesTime &&
                    matchesSuccess &&
                    matchesFailed &&
                    matchesBrowser &&
                    matchesSearch
            }

            return when (sort) {
                TrafficSortOption.NEWEST_FIRST -> filtered.sortedWith(
                    compareByDescending<TrafficRecordEntity> { it.timestamp }.thenByDescending { it.sequenceNumber }
                )
                TrafficSortOption.OLDEST_FIRST -> filtered.sortedWith(
                    compareBy<TrafficRecordEntity> { it.timestamp }.thenBy { it.sequenceNumber }
                )
                TrafficSortOption.LARGEST_REQUEST -> filtered.sortedByDescending { it.requestSize }
                TrafficSortOption.LARGEST_RESPONSE -> filtered.sortedByDescending { it.responseSize }
                TrafficSortOption.HIGHEST_STATUS -> filtered.sortedByDescending { it.statusCode }
                TrafficSortOption.DOMAIN_NAME -> filtered.sortedBy { it.domain.lowercase() }
                TrafficSortOption.HTTP_METHOD -> filtered.sortedBy { it.method }
                TrafficSortOption.DURATION -> filtered.sortedByDescending { it.durationMs }
            }
        }

        fun groupByHost(records: List<TrafficRecordEntity>): List<DomainGroupSummary> {
            return records
                .groupBy { it.domain.ifBlank { it.host.ifBlank { it.remoteAddress } } }
                .map { (domain, list) ->
                    DomainGroupSummary(
                        domain = domain,
                        totalRequests = list.size,
                        successfulRequests = list.count { it.statusCode in 200..399 && !it.isFailed },
                        failedRequests = list.count { it.isFailed || it.statusCode >= 400 },
                        totalTrafficBytes = list.sumOf { it.requestSize + it.responseSize },
                        lastActivityTimestamp = list.maxOfOrNull { it.timestamp } ?: 0L,
                        records = list.sortedByDescending { it.timestamp }
                    )
                }
                .sortedByDescending { it.lastActivityTimestamp }
        }
    }
}
