package com.example.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import androidx.core.app.NotificationCompat
import com.example.DcsInspectorApp
import com.example.MainActivity
import com.example.R
import com.example.browser.AppAttribution
import com.example.capture.HttpParser
import com.example.capture.LocalCaManager
import com.example.capture.PacketCodec
import com.example.data.settings.AppScopeMode
import com.example.data.settings.InspectorSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLHandshakeException
import javax.net.ssl.SSLSocket
import kotlin.random.Random

class DcsVpnService : VpnService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunInterface: ParcelFileDescriptor? = null
    private var vpnJob: Job? = null
    private val tunWriteChannel = Channel<ByteArray>(capacity = 512)
    private val tcpSessions = ConcurrentHashMap<SessionKey, TcpSession>()
    private val ipIdGenerator = AtomicInteger(100)
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    data class SessionKey(
        val srcIp: String,
        val srcPort: Int,
        val dstIp: String,
        val dstPort: Int
    )

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpnCapture()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                DcsInspectorApp.instance.captureEngine.pauseRecording()
                updateForegroundNotification("Paused — traffic passing through")
                return START_STICKY
            }
            ACTION_RESUME -> {
                DcsInspectorApp.instance.captureEngine.resumeRecording()
                updateForegroundNotification("Capturing real-time network traffic")
                return START_STICKY
            }
            ACTION_RESTART -> {
                serviceScope.launch {
                    tearDownTunnelOnly()
                    startVpnCapture()
                }
                return START_STICKY
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildNotification("Initializing local VPN monitor..."))
                serviceScope.launch {
                    startVpnCapture()
                }
                return START_STICKY
            }
        }
    }

    private suspend fun startVpnCapture() {
        val app = DcsInspectorApp.instance
        val settings = app.settingsManager.settingsFlow.first()
        app.captureEngine.ensureActiveSession("VPN", settings)
        registerNetworkMonitor()

        val builder = Builder()
            .setSession("DCS API Inspector")
            .setMtu(1500)
            .addAddress("10.10.0.1", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            builder.setMetered(false)
        }

        // Per-application routing where Android permits
        val allowedPackages = when {
            settings.appScopeMode == AppScopeMode.SELECTED_APPS && settings.selectedAppPackages.isNotEmpty() -> {
                settings.selectedAppPackages
            }
            settings.appScopeMode == AppScopeMode.SELECTED_APPS && !settings.selectedBrowserPackage.isNullOrBlank() -> {
                setOf(settings.selectedBrowserPackage)
            }
            else -> emptySet()
        }

        if (allowedPackages.isNotEmpty()) {
            var addedCount = 0
            allowedPackages.forEach { pkg ->
                if (pkg != packageName) {
                    runCatching {
                        builder.addAllowedApplication(pkg)
                        addedCount++
                    }
                }
            }
            if (addedCount == 0) {
                runCatching { builder.addDisallowedApplication(packageName) }
            }
        } else {
            runCatching { builder.addDisallowedApplication(packageName) }
        }

        val established = runCatching { builder.establish() }.getOrNull()
        if (established == null) {
            app.captureEngine.setVpnState(
                running = false,
                networkStatus = "Permission or VPN conflict",
                conflictMsg = "Unable to establish local VPN. Another VPN may be active or permission was revoked."
            )
            stopSelf()
            return
        }

        tunInterface = established
        app.captureEngine.setVpnState(running = true, networkStatus = "VPN Active (TUN 10.10.0.1)")
        updateForegroundNotification("Active • Monitoring ${if (allowedPackages.isNotEmpty()) "${allowedPackages.size} app(s)" else "all supported apps"}")

        startTunnelLoops(established, settings)
    }

    private fun startTunnelLoops(pfd: ParcelFileDescriptor, settings: InspectorSettings) {
        vpnJob?.cancel()
        vpnJob = serviceScope.launch {
            val fd = pfd.fileDescriptor
            val input = FileInputStream(fd)
            val output = FileOutputStream(fd)

            val writerJob = launch {
                for (pkt in tunWriteChannel) {
                    runCatching { output.write(pkt) }
                }
            }

            val buffer = ByteArray(32767)
            try {
                while (isActive) {
                    val len = input.read(buffer)
                    if (len < 0) break
                    if (len == 0) continue

                    val ip = PacketCodec.parseIpPacket(buffer, len) ?: continue
                    when (ip.protocol) {
                        PacketCodec.PROTO_UDP -> handleUdpPacket(buffer, ip, settings)
                        PacketCodec.PROTO_TCP -> handleTcpPacket(buffer, ip, settings)
                    }
                }
            } catch (_: Exception) {
                // Closed during teardown
            } finally {
                writerJob.cancel()
            }
        }
    }

    private fun handleUdpPacket(buffer: ByteArray, ip: PacketCodec.IpPacket, settings: InspectorSettings) {
        val udp = PacketCodec.parseUdpHeader(buffer, ip) ?: return
        val payload = buffer.copyOfRange(udp.payloadOffset, udp.payloadOffset + udp.payloadLength)
        val app = DcsInspectorApp.instance
        val engine = app.captureEngine

        val localAddr = InetSocketAddress(ip.srcIp, udp.srcPort)
        val remoteAddr = InetSocketAddress(ip.dstIp, udp.dstPort)
        val attribution = app.browserManager.resolveUidForConnection(
            protocol = OsConstants.IPPROTO_UDP,
            localAddress = localAddr,
            remoteAddress = remoteAddr,
            fallbackBrowserPackage = if (settings.appScopeMode == AppScopeMode.SELECTED_APPS) settings.selectedBrowserPackage else null,
            fallbackBrowserName = settings.selectedBrowserName
        )

        val isDns = udp.dstPort == 53
        val dnsQuery = if (isDns) PacketCodec.parseDnsMessage(payload) else null
        val startMs = System.currentTimeMillis()

        serviceScope.launch {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                protect(socket)
                socket.soTimeout = 4000
                val dstInet = InetAddress.getByAddress(ip.dstIpBytes)
                socket.send(DatagramPacket(payload, payload.size, dstInet, udp.dstPort))

                val respBuf = ByteArray(4096)
                val respPkt = DatagramPacket(respBuf, respBuf.size)
                socket.receive(respPkt)
                val respData = respBuf.copyOfRange(0, respPkt.length)
                val duration = System.currentTimeMillis() - startMs

                var resolvedDomain = dnsQuery?.queryDomain ?: ip.dstIp
                if (isDns) {
                    val parsedResp = PacketCodec.parseDnsMessage(respData)
                    parsedResp.resolvedARecords.forEach { (resolvedIp, dom) ->
                        engine.cacheDnsMapping(resolvedIp, dom)
                    }
                    if (!parsedResp.queryDomain.isNullOrBlank()) {
                        resolvedDomain = parsedResp.queryDomain
                    }
                }

                val returnPacket = PacketCodec.buildIpv4UdpPacket(
                    srcIpBytes = ip.dstIpBytes,
                    dstIpBytes = ip.srcIpBytes,
                    srcPort = udp.dstPort,
                    dstPort = udp.srcPort,
                    ipId = ipIdGenerator.incrementAndGet(),
                    payload = respData
                )
                tunWriteChannel.trySend(returnPacket)

                if (!engine.isPaused()) {
                    val protoLabel = when (udp.dstPort) {
                        53 -> "DNS"
                        443 -> "QUIC/UDP"
                        else -> "UDP"
                    }
                    engine.recordCapturedFlow(
                        timestamp = startMs,
                        responseTimestamp = System.currentTimeMillis(),
                        durationMs = duration,
                        method = protoLabel,
                        protocol = protoLabel,
                        httpVersion = if (udp.dstPort == 443) "HTTP/3-UDP" else "UDP",
                        rawUrl = if (isDns) "dns://$resolvedDomain" else "udp://${ip.dstIp}:${udp.dstPort}",
                        host = resolvedDomain,
                        path = if (isDns) "/query?name=$resolvedDomain" else ":${udp.dstPort}",
                        statusCode = 200,
                        statusMessage = "OK",
                        remoteAddress = ip.dstIp,
                        remotePort = udp.dstPort,
                        localPort = udp.srcPort,
                        connectionType = "VPN TUN",
                        attribution = attribution,
                        requestSize = payload.size.toLong(),
                        responseSize = respData.size.toLong(),
                        contentType = if (isDns) "application/dns-message" else "application/octet-stream",
                        rawRequestInfo = if (isDns) "DNS Query: $resolvedDomain (${payload.size}B)" else "UDP Datagram ${payload.size}B -> ${ip.dstIp}:${udp.dstPort}",
                        rawResponseInfo = if (isDns) "DNS Answer (${respData.size}B)" else "UDP Response (${respData.size}B)",
                        isTlsMetadataOnly = udp.dstPort == 443,
                        limitationNote = if (udp.dstPort == 443) "Encrypted QUIC/HTTP3 UDP datagram — metadata only." else null,
                        timingBreakdown = "Total: ${duration}ms"
                    )
                }
            } catch (e: Exception) {
                if (!engine.isPaused() && !isDns) {
                    engine.recordCapturedFlow(
                        timestamp = startMs,
                        durationMs = System.currentTimeMillis() - startMs,
                        method = "UDP",
                        protocol = "UDP",
                        httpVersion = "UDP",
                        rawUrl = "udp://${ip.dstIp}:${udp.dstPort}",
                        host = engine.lookupCachedDomain(ip.dstIp) ?: ip.dstIp,
                        path = ":${udp.dstPort}",
                        statusCode = 0,
                        statusMessage = "Timeout/Closed",
                        remoteAddress = ip.dstIp,
                        remotePort = udp.dstPort,
                        localPort = udp.srcPort,
                        connectionType = "VPN TUN",
                        attribution = attribution,
                        requestSize = payload.size.toLong(),
                        responseSize = 0L,
                        isFailed = true,
                        errorMessage = e.message ?: "UDP relay failed"
                    )
                }
            } finally {
                runCatching { socket?.close() }
            }
        }
    }

    private fun handleTcpPacket(buffer: ByteArray, ip: PacketCodec.IpPacket, settings: InspectorSettings) {
        val tcp = PacketCodec.parseTcpHeader(buffer, ip) ?: return
        val key = SessionKey(ip.srcIp, tcp.srcPort, ip.dstIp, tcp.dstPort)

        if (tcp.isSyn && !tcp.isAck) {
            tcpSessions.remove(key)?.close()
            val session = TcpSession(key, ip, tcp, settings)
            tcpSessions[key] = session
            session.start()
            return
        }

        val session = tcpSessions[key] ?: return
        if (tcp.isRst) {
            session.close()
            tcpSessions.remove(key)
            return
        }

        if (tcp.payloadLength > 0) {
            val data = buffer.copyOfRange(tcp.payloadOffset, tcp.payloadOffset + tcp.payloadLength)
            session.onClientData(tcp.seqNumber, data)
        }

        if (tcp.isFin) {
            session.onClientFin(tcp.seqNumber + tcp.payloadLength)
        }
    }

    inner class TcpSession(
        private val key: SessionKey,
        private val initialIp: PacketCodec.IpPacket,
        private val initialTcp: PacketCodec.TcpHeader,
        private val settings: InspectorSettings
    ) {
        private var remoteSocket: Socket? = null
        private var clientSeq: Long = (initialTcp.seqNumber + 1) and 0xFFFFFFFFL
        private var serverSeq: Long = Random.nextLong(100_000L, 900_000_000L)
        private val sendLock = Any()
        private val clientStreamBuffer = ByteArrayOutputStream()
        private val serverStreamBuffer = ByteArrayOutputStream()
        private val requestId = UUID.randomUUID().toString()
        private var sequenceNumber: Int? = null
        private val startedAt = System.currentTimeMillis()
        private var connectDoneAt = startedAt
        private var firstByteAt = 0L
        private var totalUpBytes = 0L
        private var totalDownBytes = 0L
        private var inspectedClientHeader = false
        private var isHttpFlow = false
        private var isTlsFlow = false
        private var detectedSni: String? = null
        private var detectedAlpn: List<String> = emptyList()
        private var parsedReq: HttpParser.ParsedHttpRequest? = null
        private var attribution: AppAttribution = AppAttribution(null, "Pending", false)
        @Volatile private var closed = false

        fun start() {
            serviceScope.launch {
                val app = DcsInspectorApp.instance
                val engine = app.captureEngine
                attribution = app.browserManager.resolveUidForConnection(
                    protocol = OsConstants.IPPROTO_TCP,
                    localAddress = InetSocketAddress(key.srcIp, key.srcPort),
                    remoteAddress = InetSocketAddress(key.dstIp, key.dstPort),
                    fallbackBrowserPackage = if (settings.appScopeMode == AppScopeMode.SELECTED_APPS) settings.selectedBrowserPackage else null,
                    fallbackBrowserName = settings.selectedBrowserName
                )

                try {
                    val sock = Socket()
                    protect(sock)
                    sock.soTimeout = 30_000
                    sock.tcpNoDelay = true

                    if (settings.secondaryProxyEnabled && settings.secondaryProxyHost.isNotBlank()) {
                        sock.connect(InetSocketAddress(settings.secondaryProxyHost, settings.secondaryProxyPort), 8000)
                        val connectReq = "CONNECT ${key.dstIp}:${key.dstPort} HTTP/1.1\r\nHost: ${key.dstIp}:${key.dstPort}\r\n\r\n"
                        sock.getOutputStream().write(connectReq.toByteArray(Charsets.US_ASCII))
                        sock.getOutputStream().flush()
                        val respLine = sock.getInputStream().bufferedReader().readLine().orEmpty()
                        if (!respLine.contains("200")) {
                            throw IllegalStateException("Secondary proxy refused tunnel: $respLine")
                        }
                    } else {
                        sock.connect(InetSocketAddress(InetAddress.getByAddress(initialIp.dstIpBytes), key.dstPort), 8000)
                    }

                    remoteSocket = sock
                    connectDoneAt = System.currentTimeMillis()

                    // Send SYN-ACK to client
                    sendTcpControl(PacketCodec.TCP_SYN or PacketCodec.TCP_ACK)
                    serverSeq = (serverSeq + 1) and 0xFFFFFFFFL

                    // Read server responses continuously
                    val inStream = sock.getInputStream()
                    val buf = ByteArray(1360)
                    while (!closed && isActive) {
                        val read = inStream.read(buf)
                        if (read < 0) break
                        if (read > 0) {
                            if (firstByteAt == 0L) firstByteAt = System.currentTimeMillis()
                            val chunk = buf.copyOfRange(0, read)
                            totalDownBytes += read
                            sendTcpData(chunk)
                            inspectServerBytes(chunk)
                        }
                    }

                    // Server closed cleanly -> send FIN|ACK
                    if (!closed) {
                        sendTcpControl(PacketCodec.TCP_FIN or PacketCodec.TCP_ACK)
                        serverSeq = (serverSeq + 1) and 0xFFFFFFFFL
                        finalizeRecord(isFailed = false, errorMsg = null)
                    }
                } catch (e: Exception) {
                    sendTcpControl(PacketCodec.TCP_RST or PacketCodec.TCP_ACK)
                    finalizeRecord(isFailed = true, errorMsg = e.message ?: "TCP connection error")
                } finally {
                    close()
                    tcpSessions.remove(key)
                }
            }
        }

        fun onClientData(seq: Long, data: ByteArray) {
            if (closed) return
            // Avoid duplicate retransmissions corrupting stream
            if (seq != clientSeq && clientStreamBuffer.size() > 0) {
                sendTcpControl(PacketCodec.TCP_ACK)
                return
            }
            clientSeq = (seq + data.size) and 0xFFFFFFFFL
            totalUpBytes += data.size
            sendTcpControl(PacketCodec.TCP_ACK)

            serviceScope.launch {
                val sock = remoteSocket ?: return@launch
                runCatching {
                    sock.getOutputStream().write(data)
                    sock.getOutputStream().flush()
                }.onFailure {
                    close()
                }
                inspectClientBytes(data)
            }
        }

        fun onClientFin(seq: Long) {
            if (closed) return
            clientSeq = (seq + 1) and 0xFFFFFFFFL
            sendTcpControl(PacketCodec.TCP_FIN or PacketCodec.TCP_ACK)
            serverSeq = (serverSeq + 1) and 0xFFFFFFFFL
            finalizeRecord(isFailed = false, errorMsg = null)
            close()
            tcpSessions.remove(key)
        }

        private fun inspectClientBytes(data: ByteArray) {
            if (clientStreamBuffer.size() < 262_144) {
                clientStreamBuffer.write(data)
            }
            if (inspectedClientHeader) {
                if (isHttpFlow) {
                    val req = HttpParser.parseHttpRequest(
                        clientStreamBuffer.toByteArray(),
                        defaultHost = "${key.dstIp}:${key.dstPort}",
                        scheme = "http"
                    )
                    if (req != null) {
                        parsedReq = req
                        emitOrUpdate(isPending = true, isUpdate = sequenceNumber != null)
                    }
                }
                return
            }

            val accumulated = clientStreamBuffer.toByteArray()
            if (HttpParser.looksLikeHttpRequest(accumulated)) {
                inspectedClientHeader = true
                isHttpFlow = true
                parsedReq = HttpParser.parseHttpRequest(
                    accumulated,
                    defaultHost = "${key.dstIp}:${key.dstPort}",
                    scheme = "http"
                )
                emitOrUpdate(isPending = true, isUpdate = false)
            } else if (accumulated.size >= 44 && (accumulated[0].toInt() and 0xFF) == 0x16) {
                inspectedClientHeader = true
                isTlsFlow = true
                val tlsInfo = PacketCodec.parseTlsClientHello(accumulated)
                detectedSni = tlsInfo?.sniHost
                detectedAlpn = tlsInfo?.alpnProtocols ?: emptyList()
                emitOrUpdate(isPending = true, isUpdate = false)
            }
        }

        private fun inspectServerBytes(data: ByteArray) {
            if (serverStreamBuffer.size() < 262_144) {
                serverStreamBuffer.write(data)
            }
            if (isHttpFlow) {
                val resp = HttpParser.parseHttpResponse(serverStreamBuffer.toByteArray())
                if (resp != null && resp.isComplete) {
                    emitOrUpdate(isPending = false, isUpdate = sequenceNumber != null, parsedResp = resp)
                }
            }
        }

        private fun finalizeRecord(isFailed: Boolean, errorMsg: String?) {
            val resp = if (isHttpFlow) HttpParser.parseHttpResponse(serverStreamBuffer.toByteArray()) else null
            if (sequenceNumber != null || totalUpBytes > 0 || isFailed) {
                emitOrUpdate(
                    isPending = false,
                    isUpdate = sequenceNumber != null,
                    parsedResp = resp,
                    isFailed = isFailed,
                    errorMsg = errorMsg
                )
            }
        }

        private fun emitOrUpdate(
            isPending: Boolean,
            isUpdate: Boolean,
            parsedResp: HttpParser.ParsedHttpResponse? = null,
            isFailed: Boolean = false,
            errorMsg: String? = null
        ) {
            val engine = DcsInspectorApp.instance.captureEngine
            if (engine.isPaused()) return

            val cachedDomain = engine.lookupCachedDomain(key.dstIp)
            val resolvedHost = parsedReq?.host ?: detectedSni ?: cachedDomain ?: key.dstIp
            val connectMs = (connectDoneAt - startedAt).coerceAtLeast(0L)
            val ttfbMs = if (firstByteAt > 0L) (firstByteAt - connectDoneAt).coerceAtLeast(0L) else 0L
            val totalMs = (System.currentTimeMillis() - startedAt).coerceAtLeast(0L)
            val timingStr = if (settings.enhancedModeEnabled && settings.enhancedTimingBreakdown) {
                "Connect: ${connectMs}ms | TTFB: ${ttfbMs}ms | Total: ${totalMs}ms"
            } else {
                "Total: ${totalMs}ms"
            }

            val connType = if (settings.secondaryProxyEnabled && settings.secondaryProxyHost.isNotBlank()) {
                "VPN + Secondary Proxy"
            } else {
                "VPN TUN"
            }

            val result = if (isHttpFlow && parsedReq != null) {
                val req = parsedReq!!
                val scheme = if (key.dstPort == 443) "https" else "http"
                val url = if (req.rawTarget.startsWith("http")) req.rawTarget else "$scheme://${req.host}${req.rawTarget}"
                engine.recordCapturedFlow(
                    requestId = requestId,
                    isUpdate = isUpdate,
                    isNewConnection = !isUpdate,
                    timestamp = startedAt,
                    responseTimestamp = if (!isPending) System.currentTimeMillis() else null,
                    durationMs = totalMs,
                    method = req.method,
                    protocol = "HTTP",
                    httpVersion = req.httpVersion,
                    rawUrl = url,
                    host = req.host,
                    path = req.path,
                    queryParams = req.queryParams,
                    statusCode = parsedResp?.statusCode ?: 0,
                    statusMessage = parsedResp?.statusMessage ?: if (isPending) "Pending" else "",
                    remoteAddress = key.dstIp,
                    remotePort = key.dstPort,
                    localPort = key.srcPort,
                    connectionType = connType,
                    attribution = attribution,
                    requestSize = totalUpBytes,
                    responseSize = totalDownBytes,
                    addedUpBytes = if (isUpdate) 0L else totalUpBytes,
                    addedDownBytes = if (isUpdate) totalDownBytes else 0L,
                    contentType = parsedResp?.contentType ?: req.contentType,
                    requestHeaders = req.headers,
                    responseHeaders = parsedResp?.headers ?: emptyMap(),
                    rawRequestBody = req.bodyText,
                    rawResponseBody = parsedResp?.bodyText,
                    rawRequestInfo = req.rawHeaderBlock,
                    rawResponseInfo = parsedResp?.rawHeaderBlock ?: "",
                    isTlsMetadataOnly = false,
                    isPending = isPending,
                    isFailed = isFailed,
                    errorMessage = errorMsg,
                    timingBreakdown = timingStr,
                    seqNumberOverride = sequenceNumber
                )
            } else {
                val alpnText = if (detectedAlpn.isNotEmpty()) detectedAlpn.joinToString(",") else "TLS"
                val isSslAllowlisted = settings.sslProxyingEnabled &&
                    settings.sslAllowlistDomains.any { resolvedHost.equals(it, true) || resolvedHost.endsWith(".$it", true) }
                val note = when {
                    isTlsFlow && !settings.sslProxyingEnabled ->
                        "Encrypted HTTPS/TLS connection (passthrough). Headers and body remain encrypted; metadata captured via SNI/DNS."
                    isTlsFlow && !isSslAllowlisted ->
                        "Domain '$resolvedHost' is not in your authorized SSL testing allowlist. Recorded as TLS metadata-only."
                    isTlsFlow ->
                        "Direct VPN TUN TLS passthrough preserves application pinning & Network Security Config. Use Local Proxy mode with your test CA for authorized domain inspection."
                    else -> "Raw TCP stream metadata ($totalUpBytes B up / $totalDownBytes B down)."
                }
                engine.recordCapturedFlow(
                    requestId = requestId,
                    isUpdate = isUpdate,
                    isNewConnection = !isUpdate,
                    timestamp = startedAt,
                    responseTimestamp = if (!isPending) System.currentTimeMillis() else null,
                    durationMs = totalMs,
                    method = if (isTlsFlow) "TLS" else "TCP",
                    protocol = if (isTlsFlow) "HTTPS" else "TCP",
                    httpVersion = alpnText,
                    rawUrl = if (isTlsFlow) "https://$resolvedHost:${key.dstPort}" else "tcp://$resolvedHost:${key.dstPort}",
                    host = resolvedHost,
                    path = if (isTlsFlow) "/[encrypted-tls]" else ":${key.dstPort}",
                    statusCode = if (isFailed) 0 else 200,
                    statusMessage = if (isFailed) "Failed" else if (isPending) "Active" else "Closed",
                    remoteAddress = key.dstIp,
                    remotePort = key.dstPort,
                    localPort = key.srcPort,
                    connectionType = connType,
                    attribution = attribution,
                    requestSize = totalUpBytes,
                    responseSize = totalDownBytes,
                    addedUpBytes = if (isUpdate) 0L else totalUpBytes,
                    addedDownBytes = if (isUpdate) totalDownBytes else 0L,
                    rawRequestInfo = "SNI: ${detectedSni ?: "Unavailable"} | ALPN: $alpnText | Encrypted Payload: $totalUpBytes bytes",
                    rawResponseInfo = "Encrypted TLS Response: $totalDownBytes bytes",
                    isTlsMetadataOnly = isTlsFlow,
                    isPending = isPending,
                    isFailed = isFailed,
                    errorMessage = errorMsg,
                    limitationNote = note,
                    timingBreakdown = timingStr,
                    seqNumberOverride = sequenceNumber
                )
            }
            if (sequenceNumber == null && result != null) {
                sequenceNumber = result.second
            }
        }

        private fun sendTcpControl(flags: Int) {
            synchronized(sendLock) {
                val pkt = PacketCodec.buildIpv4TcpPacket(
                    srcIpBytes = initialIp.dstIpBytes,
                    dstIpBytes = initialIp.srcIpBytes,
                    srcPort = key.dstPort,
                    dstPort = key.srcPort,
                    seqNumber = serverSeq,
                    ackNumber = clientSeq,
                    flags = flags,
                    ipId = ipIdGenerator.incrementAndGet()
                )
                tunWriteChannel.trySend(pkt)
            }
        }

        private fun sendTcpData(payload: ByteArray) {
            synchronized(sendLock) {
                val pkt = PacketCodec.buildIpv4TcpPacket(
                    srcIpBytes = initialIp.dstIpBytes,
                    dstIpBytes = initialIp.srcIpBytes,
                    srcPort = key.dstPort,
                    dstPort = key.srcPort,
                    seqNumber = serverSeq,
                    ackNumber = clientSeq,
                    flags = PacketCodec.TCP_PSH or PacketCodec.TCP_ACK,
                    ipId = ipIdGenerator.incrementAndGet(),
                    payload = payload
                )
                serverSeq = (serverSeq + payload.size) and 0xFFFFFFFFL
                tunWriteChannel.trySend(pkt)
            }
        }

        fun close() {
            closed = true
            runCatching { remoteSocket?.close() }
        }
    }

    private fun registerNetworkMonitor() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        if (networkCallback != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val caps = cm.getNetworkCapabilities(network)
                val transport = when {
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Cellular"
                    caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
                    else -> "Active Network"
                }
                DcsInspectorApp.instance.captureEngine.setNetworkStatus("VPN Active ($transport)")
            }

            override fun onLost(network: Network) {
                DcsInspectorApp.instance.captureEngine.setNetworkStatus("Network Lost — Waiting for reconnect")
            }
        }
        networkCallback = cb
        runCatching {
            cm.registerNetworkCallback(NetworkRequest.Builder().build(), cb)
        }
    }

    private fun tearDownTunnelOnly() {
        vpnJob?.cancel()
        tcpSessions.values.forEach { it.close() }
        tcpSessions.clear()
        runCatching { tunInterface?.close() }
        tunInterface = null
    }

    private fun stopVpnCapture() {
        tearDownTunnelOnly()
        networkCallback?.let { cb ->
            runCatching {
                (getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager)?.unregisterNetworkCallback(cb)
            }
        }
        networkCallback = null
        DcsInspectorApp.instance.captureEngine.setVpnState(running = false, networkStatus = "VPN Stopped")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        DcsInspectorApp.instance.captureEngine.setVpnState(
            running = false,
            networkStatus = "VPN Revoked",
            conflictMsg = "VPN connection was revoked by the system or replaced by another VPN app."
        )
        stopVpnCapture()
        super.onRevoke()
    }

    override fun onDestroy() {
        tearDownTunnelOnly()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun updateForegroundNotification(statusText: String) {
        val nm = getSystemService(android.app.NotificationManager::class.java) ?: return
        nm.notify(NOTIFICATION_ID, buildNotification(statusText))
    }

    private fun buildNotification(statusText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, DcsVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, DcsInspectorApp.CHANNEL_VPN)
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("DCS API Inspector • Local VPN")
            .setContentText(statusText)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 4101
        const val ACTION_START = "com.example.vpn.START"
        const val ACTION_STOP = "com.example.vpn.STOP"
        const val ACTION_PAUSE = "com.example.vpn.PAUSE"
        const val ACTION_RESUME = "com.example.vpn.RESUME"
        const val ACTION_RESTART = "com.example.vpn.RESTART"

        fun start(context: Context) {
            val intent = Intent(context, DcsVpnService::class.java).apply { action = ACTION_START }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun sendAction(context: Context, action: String) {
            val intent = Intent(context, DcsVpnService::class.java).apply { this.action = action }
            context.startService(intent)
        }
    }
}
