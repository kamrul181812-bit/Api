package com.example.browser

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.system.OsConstants
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

data class InstalledBrowser(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isDefault: Boolean,
    val isKnownBrowser: Boolean
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isBrowser: Boolean,
    val isSystemApp: Boolean
)

data class AppAttribution(
    val packageName: String?,
    val appName: String,
    val isBrowser: Boolean
)

class BrowserManager(private val context: Context) {

    private val pm: PackageManager = context.packageManager
    private val iconCache = ConcurrentHashMap<String, ImageBitmap>()
    private val knownBrowsers = setOf(
        "com.android.chrome",
        "com.chrome.beta",
        "com.chrome.dev",
        "com.chrome.canary",
        "org.mozilla.firefox",
        "org.mozilla.firefox_beta",
        "org.mozilla.fenix",
        "com.microsoft.emmx",
        "com.brave.browser",
        "com.opera.browser",
        "com.opera.mini.native",
        "com.sec.android.app.sbrowser",
        "com.duckduckgo.mobile.android",
        "com.vivaldi.browser",
        "org.chromium.webview_shell",
        "com.UCMobile.intl",
        "com.kiwibrowser.browser"
    )

    fun discoverInstalledBrowsers(): List<InstalledBrowser> {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        val flags = PackageManager.MATCH_ALL
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, flags)
        }

        val defaultResolve = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.resolveActivity(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        val defaultPkg = defaultResolve?.activityInfo?.packageName

        return resolved
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) return@mapNotNull null
                val appLabel = runCatching {
                    val appInfo = pm.getApplicationInfo(pkg, 0)
                    pm.getApplicationLabel(appInfo).toString()
                }.getOrElse { info.loadLabel(pm).toString() }

                val versionName = runCatching {
                    val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkg, 0)
                    }
                    pkgInfo.versionName ?: "Installed"
                }.getOrElse { "Installed" }

                InstalledBrowser(
                    packageName = pkg,
                    appName = appLabel,
                    versionName = versionName,
                    isDefault = pkg == defaultPkg,
                    isKnownBrowser = pkg in knownBrowsers || appLabel.contains("browser", ignoreCase = true)
                )
            }
            .distinctBy { it.packageName }
            .sortedWith(
                compareByDescending<InstalledBrowser> { it.isDefault }
                    .thenByDescending { it.isKnownBrowser }
                    .thenBy { it.appName.lowercase() }
            )
    }

    fun discoverLaunchableApps(browserPackages: Set<String>): List<InstalledAppInfo> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
        }

        return resolved
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) return@mapNotNull null
                val appInfo = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull()
                val label = appInfo?.let { pm.getApplicationLabel(it).toString() }
                    ?: info.loadLabel(pm).toString()
                val isSystem = appInfo != null && ((appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                InstalledAppInfo(
                    packageName = pkg,
                    appName = label,
                    isBrowser = pkg in browserPackages || pkg in knownBrowsers,
                    isSystemApp = isSystem
                )
            }
            .distinctBy { it.packageName }
            .sortedWith(
                compareByDescending<InstalledAppInfo> { it.isBrowser }
                    .thenBy { it.appName.lowercase() }
            )
    }

    fun getAppIcon(packageName: String?): ImageBitmap? {
        if (packageName.isNullOrBlank()) return null
        iconCache[packageName]?.let { return it }
        return runCatching {
            val drawable = pm.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(drawable).asImageBitmap()
            iconCache[packageName] = bitmap
            bitmap
        }.getOrNull()
    }

    fun launchBrowserWithUrl(packageName: String?, rawUrl: String): Result<String> {
        val normalized = normalizeUrl(rawUrl)
        val uri = Uri.parse(normalized)
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (!packageName.isNullOrBlank()) {
                setPackage(packageName)
            }
        }
        return try {
            context.startActivity(intent)
            Result.success(normalized)
        } catch (e: Exception) {
            // Fallback to chooser without explicit package if selected browser cannot handle intent
            if (!packageName.isNullOrBlank()) {
                runCatching {
                    val fallback = Intent(Intent.ACTION_VIEW, uri).apply {
                        addCategory(Intent.CATEGORY_BROWSABLE)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(fallback)
                    return Result.success(normalized)
                }
            }
            Result.failure(e)
        }
    }

    fun normalizeUrl(rawUrl: String): String {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) return "https://example.com"
        return if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            trimmed
        } else {
            "https://$trimmed"
        }
    }

    fun resolveUidForConnection(
        protocol: Int,
        localAddress: InetSocketAddress,
        remoteAddress: InetSocketAddress,
        fallbackBrowserPackage: String?,
        fallbackBrowserName: String?
    ): AppAttribution {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            if (cm != null) {
                val uid = runCatching {
                    cm.getConnectionOwnerUid(protocol, localAddress, remoteAddress)
                }.getOrDefault(Process.INVALID_UID)
                if (uid != Process.INVALID_UID && uid > 0) {
                    val pkgs = pm.getPackagesForUid(uid)
                    val pkg = pkgs?.firstOrNull()
                    if (pkg != null) {
                        val name = runCatching {
                            val appInfo = pm.getApplicationInfo(pkg, 0)
                            pm.getApplicationLabel(appInfo).toString()
                        }.getOrElse { pkg }
                        return AppAttribution(
                            packageName = pkg,
                            appName = name,
                            isBrowser = pkg in knownBrowsers || pkg == fallbackBrowserPackage
                        )
                    }
                }
            }
        }
        if (!fallbackBrowserPackage.isNullOrBlank()) {
            return AppAttribution(
                packageName = fallbackBrowserPackage,
                appName = fallbackBrowserName ?: fallbackBrowserPackage,
                isBrowser = true
            )
        }
        return AppAttribution(
            packageName = null,
            appName = if (protocol == OsConstants.IPPROTO_UDP) "Device UDP" else "Device Network",
            isBrowser = false
        )
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return Bitmap.createScaledBitmap(drawable.bitmap, 72, 72, true)
        }
        val width = drawable.intrinsicWidth.takeIf { it > 0 } ?: 72
        val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 72
        val bmp = Bitmap.createBitmap(width.coerceAtMost(96), height.coerceAtMost(96), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bmp
    }
}
