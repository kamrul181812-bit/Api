package com.example.classifier

enum class TrafficCategory(val label: String) {
    AUTH("Auth"),
    OTP("OTP / Verify"),
    API_JSON("JSON API"),
    DOCUMENT("Document"),
    STATIC_ASSET("Asset"),
    MEDIA("Media"),
    ANALYTICS("Telemetry"),
    TLS_METADATA("TLS Metadata"),
    DNS("DNS"),
    OTHER("Network")
}

data class AutoHighlightSettings(
    val highlightSuccess: Boolean = true,
    val highlightErrors: Boolean = true,
    val highlightRedirects: Boolean = true,
    val highlightJson: Boolean = true,
    val highlightAuthOtp: Boolean = true,
    val highlightSlow: Boolean = true,
    val slowThresholdMs: Long = 1200L,
    val highlightLarge: Boolean = true,
    val largeThresholdBytes: Long = 100 * 1024L
)

object DomainClassifier {

    private val authKeywords = listOf("login", "signin", "sign-in", "auth", "oauth", "token", "session", "logout", "register", "signup")
    private val otpKeywords = listOf("otp", "verify", "verification", "2fa", "mfa", "code", "challenge")
    private val analyticsDomains = listOf("google-analytics", "googletagmanager", "doubleclick", "mixpanel", "amplitude", "segment", "sentry", "crashlytics", "app-measurement")
    private val staticExtensions = listOf(".css", ".js", ".woff", ".woff2", ".ttf", ".svg", ".ico", ".map")
    private val mediaExtensions = listOf(".png", ".jpg", ".jpeg", ".webp", ".gif", ".mp4", ".m3u8", ".mp3", ".webm")

    fun classify(
        url: String,
        host: String,
        contentType: String?,
        protocol: String,
        isTlsMetadataOnly: Boolean
    ): TrafficCategory {
        val lowerUrl = url.lowercase()
        val lowerHost = host.lowercase()
        val lowerCt = contentType?.lowercase().orEmpty()

        if (protocol.equals("DNS", ignoreCase = true)) return TrafficCategory.DNS
        if (otpKeywords.any { lowerUrl.contains(it) }) return TrafficCategory.OTP
        if (authKeywords.any { lowerUrl.contains(it) }) return TrafficCategory.AUTH
        if (isTlsMetadataOnly) return TrafficCategory.TLS_METADATA
        if (lowerCt.contains("json")) return TrafficCategory.API_JSON
        if (analyticsDomains.any { lowerHost.contains(it) }) return TrafficCategory.ANALYTICS
        if (mediaExtensions.any { lowerUrl.substringBefore('?').endsWith(it) } || lowerCt.startsWith("image/") || lowerCt.startsWith("video/") || lowerCt.startsWith("audio/")) {
            return TrafficCategory.MEDIA
        }
        if (staticExtensions.any { lowerUrl.substringBefore('?').endsWith(it) }) return TrafficCategory.STATIC_ASSET
        if (lowerCt.contains("html") || lowerCt.contains("xml")) return TrafficCategory.DOCUMENT
        return TrafficCategory.OTHER
    }

    fun evaluateHighlights(
        statusCode: Int,
        isFailed: Boolean,
        category: TrafficCategory,
        contentType: String?,
        durationMs: Long,
        responseSize: Long,
        rules: AutoHighlightSettings
    ): List<String> {
        val tags = mutableListOf<String>()
        if (rules.highlightAuthOtp && (category == TrafficCategory.AUTH || category == TrafficCategory.OTP)) {
            tags.add(category.label)
        }
        if (rules.highlightErrors && (isFailed || statusCode >= 400)) {
            tags.add(if (isFailed) "Failed" else "HTTP $statusCode")
        } else if (rules.highlightRedirects && statusCode in 300..399) {
            tags.add("Redirect")
        } else if (rules.highlightSuccess && statusCode in 200..299) {
            tags.add("2xx OK")
        }
        if (rules.highlightJson && (contentType?.contains("json", ignoreCase = true) == true || category == TrafficCategory.API_JSON)) {
            tags.add("JSON")
        }
        if (rules.highlightSlow && durationMs >= rules.slowThresholdMs) {
            tags.add("Slow ${durationMs}ms")
        }
        if (rules.highlightLarge && responseSize >= rules.largeThresholdBytes) {
            tags.add("Large")
        }
        return tags
    }
}
